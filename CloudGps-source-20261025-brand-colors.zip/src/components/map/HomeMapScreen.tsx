"use client";
import { useEffect, useRef, useCallback, useState } from "react";
import type { Map as LeafletMap } from "leaflet";
import { useAppStore } from "@/store/useAppStore";
import { t } from "@/lib/translations";
import { MapComponent } from "./MapComponent";
import { PlaceDetailPanel } from "@/components/navigation/PlaceDetailPanel";
import { RoutePreviewPanel } from "@/components/navigation/RoutePreviewPanel";
import { ActiveNavigationPanel } from "@/components/navigation/ActiveNavigationPanel";
import { ReportsPanel } from "@/components/reports/ReportsPanel";
import { CreateReportPanel } from "@/components/reports/CreateReportPanel";
import { SettingsPanel } from "@/components/ui/SettingsPanel";
import { SavedPlacesPanel } from "@/components/ui/SavedPlacesPanel";
import { AboutPanel } from "@/components/ui/AboutPanel";
import { OfflineMapsPanel } from "@/components/ui/OfflineMapsPanel";
import { ProfilePanel } from "@/components/ui/ProfilePanel";
import { PrivacyPanel } from "@/components/ui/PrivacyPanel";
import { HelpPanel } from "@/components/ui/HelpPanel";
import { TripHistoryPanel } from "@/components/navigation/TripSummaryPanel";
import { WainLogo } from "@/components/ui/WainLogo";
import { Toaster } from "react-hot-toast";
import {
  Search, Navigation, AlertTriangle, Menu,
  X, ZoomIn, ZoomOut, Crosshair, Layers, Moon, Sun, Plus,
  Star, History, User, Settings, Bookmark, MapPin, WifiOff,
  ChevronLeft, Hospital, Fuel, Utensils, Pill, Landmark, Banknote,
  Hotel, ShoppingCart, Map,
} from "lucide-react";
import { IRAQ_GOVERNORATES } from "@/types";
import { useLocation } from "@/hooks/useLocation";
import type { Place } from "@/types";

export function HomeMapScreen() {
  const {
    language, theme, activePanel, isOnline, locationStatus,
    userLocation, mapCenter, trafficReports, navigation, isDarkMap, showReportsLayer,
    setActivePanel, setIsOnline, setPendingReportLocation, setMapCenter,
    setIsDarkMap, setShowReportsLayer, setTrafficReports,
    setSelectedPlace, setDestination, setOrigin,
  } = useAppStore();

  const mapRef = useRef<LeafletMap | null>(null);
  const searchRef = useRef<HTMLInputElement>(null);
  const lang = language;
  const dir = lang === "ar" ? "rtl" : "ltr";
  const isNav = navigation.status === "active" || navigation.status === "rerouting";

  const [searchOpen, setSearchOpen] = useState(false);
  const [searchValue, setSearchValue] = useState("");
  const [results, setResults] = useState<Place[]>([]);
  const [searching, setSearching] = useState(false);
  const [searchError, setSearchError] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [layersOpen, setLayersOpen] = useState(false);
  const [reportsFetchStatus, setReportsFetchStatus] = useState<"loading" | "success" | "error">("loading");

  useLocation();

  // Keep community incidents available on the map without requiring the reports panel to open.
  // Coarse coordinates avoid reloading the layer for every small GPS adjustment.
  const reportCenter = userLocation ?? mapCenter;
  const reportLat = Math.round(reportCenter.lat * 100) / 100;
  const reportLng = Math.round(reportCenter.lng * 100) / 100;
  const activeReportCount = trafficReports.filter(report => report.status === "active").length;
  useEffect(() => {
    let disposed = false;
    let controller: AbortController | null = null;

    const loadNearbyReports = async () => {
      if (!isOnline) {
        setReportsFetchStatus("error");
        return;
      }

      controller?.abort();
      controller = new AbortController();
      const params = new URLSearchParams({
        lat: String(reportLat), lng: String(reportLng), radius: "15",
      });

      try {
        const response = await fetch(`/api/reports/nearby?${params}`, { signal: controller.signal });
        if (!response.ok) throw new Error(`Reports request failed (${response.status})`);
        const data = await response.json();
        if (!disposed) {
          const localReports = useAppStore.getState().trafficReports.filter((report) => report.source === "local");
          setTrafficReports([...(data.reports ?? []), ...localReports]);
          setReportsFetchStatus("success");
        }
      } catch (error) {
        if (!disposed && !(error instanceof DOMException && error.name === "AbortError")) {
          setReportsFetchStatus("error");
        }
      }
    };

    void loadNearbyReports();
    const interval = window.setInterval(loadNearbyReports, 60_000);
    return () => {
      disposed = true;
      controller?.abort();
      window.clearInterval(interval);
    };
  }, [isOnline, reportLat, reportLng, setTrafficReports]);

  useEffect(() => {
    const on = () => setIsOnline(true);
    const off = () => setIsOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    setIsOnline(navigator.onLine);
    return () => { window.removeEventListener("online", on); window.removeEventListener("offline", off); };
  }, [setIsOnline]);

  // Search
  const searchTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const searchRequest = useRef<AbortController | null>(null);
  const searchSequence = useRef(0);
  function handleSearch(q: string) {
    setSearchValue(q);
    if (searchTimer.current) clearTimeout(searchTimer.current);
    searchRequest.current?.abort();
    const sequence = ++searchSequence.current;
    setSearchError(false);
    if (q.trim().length < 2) { setResults([]); setSearching(false); return; }
    setResults([]);
    setSearching(true);
    searchTimer.current = setTimeout(async () => {
      const controller = new AbortController();
      searchRequest.current = controller;
      try {
        const p = new URLSearchParams({ q: q.trim(), limit: "20" });
        if (userLocation) { p.set("lat", String(userLocation.lat)); p.set("lng", String(userLocation.lng)); }
        const r = await fetch(`/api/places/search?${p}`, { signal: controller.signal });
        if (!r.ok) throw new Error(`Search failed (${r.status})`);
        const d = await r.json();
        if (sequence === searchSequence.current) setResults(d.places ?? []);
      } catch (error) {
        if (sequence === searchSequence.current && !(error instanceof DOMException && error.name === "AbortError")) {
          setResults([]);
          setSearchError(true);
        }
      } finally {
        if (sequence === searchSequence.current) setSearching(false);
      }
    }, 700);
  }

  function selectPlace(p: Place) {
    setSelectedPlace(p);
    setDestination({ name: p.nameAr ?? p.name, location: { lat: p.lat, lng: p.lng } });
    mapRef.current?.setView([p.lat, p.lng], Math.max(mapRef.current.getZoom(), 15), { animate: true });
    setSearchOpen(false);
    setSearchValue("");
    setResults([]);
    setActivePanel("place");
  }

  // Map click
  const handleMapClick = useCallback(async (lat: number, lng: number) => {
    const panel = useAppStore.getState().activePanel;
    if (panel === "create-report") { setPendingReportLocation({ lat, lng }); return; }
    try {
      const res = await fetch(`/api/places/reverse?lat=${lat}&lng=${lng}`);
      const data = await res.json();
      useAppStore.getState().setSelectedPlace({
        id: `c_${lat}_${lng}`, name: data.nameEn ?? "Selected",
        nameAr: data.name ?? "موقع محدد", address: data.address,
        lat, lng, category: "place", source: "map_click",
      });
    } catch {
      useAppStore.getState().setSelectedPlace({ id: `c_${lat}_${lng}`, name: "Selected", nameAr: "موقع محدد", lat, lng });
    }
    setActivePanel("place");
  }, [setPendingReportLocation, setActivePanel]);

  const centerUser = useCallback(() => {
    const loc = useAppStore.getState().userLocation;
    if (mapRef.current && loc) {
      mapRef.current.setView([loc.lat, loc.lng], 17, { animate: true });
      setMapCenter(loc);
    }
  }, [setMapCenter]);

  function renderPanel() {
    switch (activePanel) {
      case "place": return <PlaceDetailPanel />;
      case "route-preview": return <RoutePreviewPanel />;
      case "reports": return <ReportsPanel />;
      case "create-report": return <CreateReportPanel />;
      case "settings": return <SettingsPanel />;
      case "saved": return <SavedPlacesPanel />;
      case "about": return <AboutPanel />;
      case "offline": return <OfflineMapsPanel />;
      case "profile": return <ProfilePanel />;
      case "privacy": return <PrivacyPanel />;
      case "help": return <HelpPanel />;
      case "trip-history": return <TripHistoryPanel />;
      default: return null;
    }
  }

  const hasPanel = activePanel !== "home" && activePanel !== "navigation";

  // CATS
  const cats = [
    { icon: Hospital, label: lang === "ar" ? "مستشفى" : "Hospital", q: "مستشفى" },
    { icon: Fuel, label: lang === "ar" ? "وقود" : "Fuel", q: "محطة وقود" },
    { icon: Utensils, label: lang === "ar" ? "مطعم" : "Food", q: "مطعم" },
    { icon: Pill, label: lang === "ar" ? "صيدلية" : "Pharmacy", q: "صيدلية" },
    { icon: Landmark, label: lang === "ar" ? "مسجد" : "Mosque", q: "مسجد" },
    { icon: Banknote, label: lang === "ar" ? "صراف" : "ATM", q: "صراف" },
    { icon: Hotel, label: lang === "ar" ? "فندق" : "Hotel", q: "فندق" },
    { icon: ShoppingCart, label: lang === "ar" ? "سوق" : "Market", q: "سوق" },
    { icon: Map, label: lang === "ar" ? "أحياء بغداد" : "Baghdad areas", q: "أحياء بغداد" },
  ];

  return (
    <div data-theme={theme} className={`relative w-full h-[100dvh] overflow-hidden bg-[#F7FAFF] ${theme === "dark" ? "theme-dark" : ""}`} dir={dir}>
      <Toaster position="top-center" />

      {/* ═══ MAP ═══ */}
      <div className="absolute inset-0 z-0">
        <MapComponent className="w-full h-full" onMapClick={handleMapClick}
          onMapReady={m => { mapRef.current = m; setTimeout(() => m.invalidateSize(), 300); setTimeout(() => m.invalidateSize(), 1000); }} />
      </div>

      {/* ═══ DESTINATION SEARCH ═══ */}
      {searchOpen && !isNav && (
        <div className="absolute inset-0 z-50 bg-[#F7FAFF] flex flex-col animate-fade-in md:inset-y-6 md:inset-x-auto md:left-1/2 md:w-[min(calc(100%-2rem),560px)] md:-translate-x-1/2 md:rounded-3xl md:shadow-2xl md:border md:border-[#D9E4F2]">
          {/* Search Header */}
          <div className="flex items-center gap-3 px-4 pt-4 pb-2 safe-top border-b border-[#F7FAFF]">
            <button onClick={() => { setSearchOpen(false); setSearchValue(""); setResults([]); }}
                    className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-[#F7FAFF] transition-colors active:scale-90 flex-shrink-0">
              <ChevronLeft size={22} color="#0B1F3A" strokeWidth={2} className={dir === "rtl" ? "rotate-180" : ""} />
            </button>
            <div className="flex-1 relative">
              <input ref={searchRef} autoFocus value={searchValue} onChange={e => handleSearch(e.target.value)}
                     placeholder={lang === "ar" ? "إلى أين تريد الذهاب؟" : "Where do you want to go?"}
                     className="w-full bg-[#F7FAFF] rounded-2xl px-4 py-3 text-[15px] font-bold outline-none placeholder:font-medium placeholder:text-[#61738B]" />
              {searchValue && (
                <button onClick={() => { setSearchValue(""); setResults([]); searchRef.current?.focus(); }}
                        className="absolute top-1/2 -translate-y-1/2 left-3 w-6 h-6 rounded-full bg-[#D9E4F2] flex items-center justify-center">
                  <X size={12} color="#0B1F3A" strokeWidth={3} />
                </button>
              )}
            </div>
          </div>

          {/* Categories */}
          {searchValue.length === 0 && (
            <div className="px-4 py-4">
              <p className="label-text mb-3">{lang === "ar" ? "تصفح حسب الفئة" : "BROWSE BY CATEGORY"}</p>
              <div className="grid grid-cols-4 gap-3">
                {cats.map(c => (
                  <button key={c.q} onClick={() => handleSearch(c.q)}
                          className="flex flex-col items-center gap-2 py-3 rounded-2xl bg-[#F7FAFF] border border-[#D9E4F2] hover:bg-[#0A6AD6]/5 transition-colors active:scale-95">
                    <c.icon size={22} color="#0A6AD6" strokeWidth={2} />
                    <span className="text-[12px] font-extrabold text-[#0B1F3A]">{c.label}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Loading */}
          {searching && (
            <div className="flex justify-center py-10">
              <div className="w-8 h-8 border-3 border-[#0A6AD6] border-t-transparent rounded-full animate-spin" />
            </div>
          )}

          {/* Results */}
            <div className="flex-1 overflow-y-auto">
            {results.map((p: any) => (
              <button key={p.id} onClick={() => selectPlace(p)}
                      className="flex items-center gap-4 w-full px-5 py-4 hover:bg-[#F7FAFF] border-b border-[#F7FAFF] transition-colors active:bg-[#0A6AD6]/5"
                      dir="rtl">
                <div className="w-11 h-11 rounded-2xl bg-[#0A6AD6]/8 flex items-center justify-center flex-shrink-0">
                  <MapPin size={20} color="#0A6AD6" strokeWidth={2} />
                </div>
                <div className="flex-1 min-w-0 text-right">
                  <p className="font-extrabold text-[15px] text-[#0B1F3A] truncate leading-snug">{p.nameAr || p.name}</p>
                  {p.address && <p className="text-[12px] text-[#61738B] font-medium truncate mt-1">{p.address.split(",").slice(0,3).join("، ")}</p>}
                </div>
              </button>
            ))}
            {searchValue.length >= 2 && !searching && results.length === 0 && (
              <div className="py-16 text-center">
                <p className="text-4xl mb-3">{searchError ? "⚠️" : "🔍"}</p>
                <p className="text-[15px] font-bold text-[#61738B]">
                  {searchError
                    ? (lang === "ar" ? "تعذر الاتصال بخدمة البحث" : "Search is temporarily unavailable")
                    : (lang === "ar" ? "لا توجد نتائج" : "No results found")}
                </p>
                <p className="text-[13px] text-[#61738B] mt-1">
                  {searchError
                    ? (lang === "ar" ? "تحقق من الاتصال ثم أعد المحاولة" : "Check your connection and try again")
                    : (lang === "ar" ? "جرّب اسماً أو فئة أخرى" : "Try another name or category")}
                </p>
                {searchError && <button onClick={() => handleSearch(searchValue)} className="mt-4 rounded-xl bg-[#0A6AD6] px-4 py-2 text-sm font-bold text-white">{lang === "ar" ? "إعادة المحاولة" : "Try again"}</button>}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ═══ WAIN MENU ═══ */}
      {menuOpen && !isNav && (
        <div className="absolute inset-0 z-50 flex" onClick={() => setMenuOpen(false)}>
          <div className="w-72 h-full bg-[#F7FAFF] shadow-2xl flex flex-col animate-fade-in"
               style={{ [dir === "rtl" ? "right" : "left"]: 0 }}
               onClick={e => e.stopPropagation()}>
            {/* Header */}
            <div className="bg-[#0A6AD6] px-5 pt-10 pb-6 safe-top">
              <div className="mb-4 flex justify-center">
                <WainLogo
                  showText
                  className="w-full max-w-[232px] rounded-[18px] bg-[#F7FAFF] p-1.5 shadow-sm"
                />
              </div>
              <p className="text-center text-[12px] font-bold text-white/75">
                {lang === "ar" ? "الملاحة المجتمعية في العراق" : "Community navigation in Iraq"}
              </p>
            </div>
            {/* Items */}
            <div className="flex-1 overflow-y-auto py-2">
              <SideItem icon={<Bookmark size={20} strokeWidth={2}/>} label={lang==="ar"?"المفضلة":"Favorites"} onClick={() => { setMenuOpen(false); setActivePanel("saved"); }} />
              <SideItem icon={<History size={20} strokeWidth={2}/>} label={lang==="ar"?"رحلاتي":"My Trips"} onClick={() => { setMenuOpen(false); setActivePanel("trip-history"); }} />
              <SideItem icon={<AlertTriangle size={20} strokeWidth={2}/>} label={lang==="ar"?"البلاغات":"Reports"} accent onClick={() => { setMenuOpen(false); setActivePanel("reports"); }} />
              <div className="h-px bg-[#F7FAFF] mx-5 my-2" />
              <SideItem icon={<User size={20} strokeWidth={2}/>} label={lang==="ar"?"ملفي":"Profile"} onClick={() => { setMenuOpen(false); setActivePanel("profile"); }} />
              <SideItem icon={<Settings size={20} strokeWidth={2}/>} label={lang==="ar"?"الإعدادات":"Settings"} onClick={() => { setMenuOpen(false); setActivePanel("settings"); }} />
            </div>
            <div className="px-5 py-4 border-t border-[#F7FAFF]">
              <p className="label-text text-[9px] text-center">CloudGps v1.0 — صُنع في العراق 🇮🇶</p>
            </div>
          </div>
        </div>
      )}

      {/* ═══ TOP BAR ═══ */}
      {!isNav && !searchOpen && (
        <div className="absolute top-0 left-0 right-0 z-20 px-4 safe-top">
          <div className="mx-auto flex max-w-[620px] items-center gap-3">
            <button onClick={() => setMenuOpen(true)}
                    aria-label={lang === "ar" ? "القائمة" : "Menu"}
                    className="w-12 h-12 rounded-full glass-heavy flex items-center justify-center active:scale-90 transition-transform flex-shrink-0">
              <Menu size={21} color="#0B1F3A" strokeWidth={2.2} />
            </button>
            <button onClick={() => { setSearchOpen(true); setTimeout(() => searchRef.current?.focus(), 100); }}
                    aria-label={lang === "ar" ? "ابحث عن وجهة" : "Search for a destination"}
                    className="flex-1 h-12 glass-heavy rounded-full flex items-center gap-3 px-5 active:scale-[0.99] transition-transform">
              <Search size={19} color="#61738B" strokeWidth={2.2} />
              <span className="text-[15px] font-extrabold text-[#61738B]">{lang === "ar" ? "إلى أين؟" : "Where to?"}</span>
            </button>
          </div>

          {/* Offline */}
          {!isOnline && (
            <div className="mt-2 flex items-center gap-2 px-4 py-2 rounded-2xl bg-amber-500/90">
              <WifiOff size={14} color="white" strokeWidth={2} />
              <span className="text-[12px] text-white font-bold">{t("offlineMsg", lang)}</span>
            </div>
          )}
        </div>
      )}

      {/* ═══ RIGHT SIDE CONTROLS ═══ */}
      {!isNav && !searchOpen && (
        <div className="absolute z-20 flex flex-col gap-3"
             style={{ bottom: hasPanel ? "55%" : "150px", [dir === "rtl" ? "left" : "right"]: 14, transition: "bottom 0.3s" }}>
          <div className="hidden sm:flex flex-col overflow-hidden glass rounded-2xl shadow-md">
            <button onClick={() => mapRef.current?.zoomIn()} aria-label={lang === "ar" ? "تكبير الخريطة" : "Zoom in"} className="w-11 h-10 flex items-center justify-center hover:bg-black/5 transition-colors">
              <ZoomIn size={19} color="#0B1F3A" strokeWidth={2} />
            </button>
            <div className="h-px bg-black/10 mx-2" />
            <button onClick={() => mapRef.current?.zoomOut()} aria-label={lang === "ar" ? "تصغير الخريطة" : "Zoom out"} className="w-11 h-10 flex items-center justify-center hover:bg-black/5 transition-colors">
              <ZoomOut size={19} color="#0B1F3A" strokeWidth={2} />
            </button>
          </div>
          <button onClick={centerUser} aria-label={lang === "ar" ? "موقعي" : "My location"} className="w-11 h-11 glass rounded-full shadow-md flex items-center justify-center active:scale-90 transition-transform">
            <Crosshair size={20} color={locationStatus==="success"?"#0A6AD6":"#61738B"} strokeWidth={2} />
          </button>
          <button onClick={() => setLayersOpen(!layersOpen)} aria-label={lang === "ar" ? "طبقات الخريطة" : "Map layers"} className={`w-11 h-11 rounded-full shadow-md flex items-center justify-center active:scale-90 transition-transform ${layersOpen?"bg-[#0A6AD6]":"glass"}`}>
            <Layers size={20} color={layersOpen?"white":"#0B1F3A"} strokeWidth={2} />
          </button>
        </div>
      )}

      {/* Layers popup */}
      {layersOpen && !isNav && (
        <div className="absolute z-30 glass-heavy rounded-2xl p-3 w-48 shadow-2xl animate-fade-in"
             style={{ bottom: hasPanel ? "60%" : "180px", [dir === "rtl" ? "left" : "right"]: 70 }}>
          <p className="label-text mb-2 px-1">{lang === "ar" ? "الطبقات" : "LAYERS"}</p>
          <button onClick={() => setIsDarkMap(!isDarkMap)} className="flex items-center gap-3 w-full px-2 py-2.5 rounded-xl hover:bg-black/5 transition-colors" dir="rtl">
            {isDarkMap ? <Sun size={18} color="#0A6AD6" strokeWidth={2}/> : <Moon size={18} color="#0A6AD6" strokeWidth={2}/>}
            <span className="text-[13px] font-bold text-[#0B1F3A] flex-1 text-right">{isDarkMap?(lang==="ar"?"نهاري":"Day"):(lang==="ar"?"ليلي":"Night")}</span>
          </button>
          <button onClick={() => setShowReportsLayer(!showReportsLayer)} className="flex items-center gap-3 w-full px-2 py-2.5 rounded-xl hover:bg-black/5 transition-colors" dir="rtl">
            <AlertTriangle size={18} color={showReportsLayer?"#D62828":"#61738B"} strokeWidth={2}/>
            <span className="text-[13px] font-bold flex-1 text-right" style={{color:showReportsLayer?"#D62828":"#61738B"}}>{lang==="ar"?"البلاغات":"Reports"}</span>
          </button>
          {reportsFetchStatus !== "success" && (
            <p className="mt-1 rounded-xl bg-amber-500/10 px-3 py-2 text-[11px] font-semibold text-amber-700" dir={dir}>
              {reportsFetchStatus === "loading"
                ? (lang === "ar" ? "جارٍ تحديث البلاغات القريبة…" : "Updating nearby reports…")
                : (lang === "ar" ? "بيانات البلاغات غير متاحة الآن" : "Road report data is unavailable")}
            </p>
          )}
        </div>
      )}

      {/* ═══ MAP ACTIONS ═══ */}
      {!isNav && !searchOpen && activePanel === "home" && (
        <div className="absolute bottom-0 left-0 right-0 z-20 safe-bottom px-4 pointer-events-none">
          <div className="mx-auto flex max-w-[620px] items-center gap-3 pb-2 pointer-events-auto" dir={dir}>
            <button onClick={() => setActivePanel("create-report")}
                    aria-label={lang === "ar" ? "إضافة بلاغ طريق" : "Report a road issue"}
                    className="w-14 h-14 flex-shrink-0 rounded-full bg-[#D62828] text-white shadow-xl flex items-center justify-center active:scale-90 transition-transform border-4 border-white/85">
              <Plus size={25} strokeWidth={2.8} />
            </button>
            <button onClick={() => {
              if (!useAppStore.getState().destination) {
                setSearchOpen(true);
                window.setTimeout(() => searchRef.current?.focus(), 100);
                return;
              }
              setActivePanel("route-preview");
            }}
                    className="flex-1 min-w-0 glass-heavy rounded-[24px] shadow-xl px-4 py-3 flex items-center gap-3 text-start active:scale-[0.99] transition-transform">
              <span className="w-10 h-10 rounded-full bg-[#0A6AD6]/10 flex items-center justify-center flex-shrink-0">
                <MapPin size={19} color="#0A6AD6" strokeWidth={2.2} />
              </span>
              <span className="flex-1 min-w-0">
                <span className="block text-[14px] font-black text-[#0B1F3A] truncate">
                  {lang === "ar" ? "خطط لرحلتك" : "Plan your trip"}
                </span>
                <span className="block text-[11px] font-semibold text-[#61738B] truncate">
                  {reportsFetchStatus === "success" && activeReportCount > 0
                    ? (lang === "ar"
                      ? `بلاغات قريبة منك: ${activeReportCount}`
                      : `${activeReportCount} nearby road reports`)
                    : (lang === "ar" ? "اختر وجهة لعرض المسار" : "Choose a destination to see your route")}
                </span>
              </span>
              <span className="flex items-center gap-2 rounded-full bg-[#0A6AD6] px-4 py-2.5 text-white flex-shrink-0">
                <Navigation size={17} strokeWidth={2.4} />
                <span className="text-[12px] font-extrabold">{lang === "ar" ? "مسار" : "Route"}</span>
              </span>
            </button>
          </div>
        </div>
      )}

      {/* ═══ PANELS ═══ */}
      {hasPanel && (
        <>
          <div className="absolute inset-0 z-30 bg-black/15" onClick={() => setActivePanel("home")} />
          <div className={`absolute bottom-0 left-0 right-0 z-40 max-h-[85%] overflow-hidden animate-slide-up ${activePanel === "settings" ? "flex justify-center" : ""}`}>
            <div className={`w-full max-h-full ${activePanel === "settings" ? "max-w-[560px]" : ""}`}>{renderPanel()}</div>
          </div>
        </>
      )}

      {/* Navigation */}
      {isNav && (
        <div className="absolute bottom-0 left-0 right-0 z-40"><ActiveNavigationPanel /></div>
      )}
    </div>
  );
}

function SideItem({ icon, label, onClick, accent }: {
  icon: React.ReactNode; label: string; onClick: () => void; accent?: boolean;
}) {
  return (
    <button onClick={onClick}
            className="flex items-center gap-4 w-full px-5 py-3.5 hover:bg-[#F7FAFF] transition-colors active:bg-[#0A6AD6]/5" dir="rtl">
      <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
           style={{ background: accent ? "rgba(214,40,40,0.08)" : "rgba(10,106,214,0.06)", color: accent ? "#D62828" : "#0A6AD6" }}>
        {icon}
      </div>
      <span className="font-extrabold text-[15px] text-[#0B1F3A]">{label}</span>
    </button>
  );
}
