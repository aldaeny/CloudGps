"use client";
import { useMemo, useState } from "react";
import {
  X, Trash2, WifiOff, Info,
  CheckCircle, AlertCircle, Map
} from "lucide-react";
import { useAppStore } from "@/store/useAppStore";
import { t } from "@/lib/translations";
import { IRAQ_GOVERNORATES } from "@/types";
import { waenToast } from "@/lib/toast";

interface RegionInfo {
  id: string;
  name: string;
  nameAr: string;
  minLat: number; minLng: number;
  maxLat: number; maxLng: number;
  estimatedMb: number;
}

const REGIONS: RegionInfo[] = [
  { id:"baghdad",  nameAr:"بغداد",          name:"Baghdad",
    minLat:33.1, minLng:44.1, maxLat:33.5, maxLng:44.7, estimatedMb:280 },
  { id:"basra",    nameAr:"البصرة",          name:"Basra",
    minLat:30.3, minLng:47.5, maxLat:30.8, maxLng:48.1, estimatedMb:160 },
  { id:"mosul",    nameAr:"نينوى - الموصل", name:"Nineveh - Mosul",
    minLat:36.1, minLng:42.9, maxLat:36.6, maxLng:43.4, estimatedMb:140 },
  { id:"erbil",    nameAr:"أربيل",           name:"Erbil",
    minLat:35.9, minLng:43.7, maxLat:36.5, maxLng:44.3, estimatedMb:120 },
  { id:"najaf",    nameAr:"النجف",           name:"Najaf",
    minLat:31.7, minLng:44.0, maxLat:32.2, maxLng:44.6, estimatedMb:90  },
  { id:"karbala",  nameAr:"كربلاء",          name:"Karbala",
    minLat:32.4, minLng:43.8, maxLat:32.9, maxLng:44.2, estimatedMb:85  },
  { id:"kirkuk",   nameAr:"كركوك",           name:"Kirkuk",
    minLat:35.3, minLng:44.2, maxLat:35.7, maxLng:44.6, estimatedMb:80  },
  { id:"sulaymaniyah", nameAr:"السليمانية", name:"Sulaymaniyah",
    minLat:35.4, minLng:45.3, maxLat:35.8, maxLng:45.7, estimatedMb:75  },
];

type DownloadStatus = "none" | "queued" | "downloading" | "done" | "error";

interface RegionState {
  status: DownloadStatus;
  progress: number;
  dbId?: number;
}

export function OfflineMapsPanel() {
  const { language, setActivePanel } = useAppStore();
  const lang = language;
  const dir  = lang === "ar" ? "rtl" : "ltr";

  const [regions, setRegions] = useState<Record<string, RegionState>>(
    () => {
      if (typeof window === "undefined") return {};
      try {
        const saved = localStorage.getItem("waen_offline_regions");
        const parsed = saved ? JSON.parse(saved) as Record<string, RegionState> : {};
        // Older versions marked metadata as downloaded without caching map tiles.
        return Object.fromEntries(Object.entries(parsed).filter(([, state]) => state.status !== "done"));
      } catch { return {}; }
    }
  );

  const totalMb = useMemo(() => Object.entries(regions)
      .filter(([,v]) => v.status === "done")
      .reduce((sum, [k]) => {
        const r = REGIONS.find(r => r.id === k);
        return sum + (r?.estimatedMb ?? 0);
      }, 0), [regions]);

  function saveRegions(next: Record<string, RegionState>) {
    setRegions(next);
    try { localStorage.setItem("waen_offline_regions", JSON.stringify(next)); } catch {}
  }

  function downloadRegion(region: RegionInfo) {
    waenToast.info(lang === "ar"
      ? `تنزيل خرائط ${region.nameAr} دون اتصال غير متاح في هذه النسخة`
      : `Offline downloads for ${region.name} are not available in this version`);
  }

  function deleteRegion(region: RegionInfo) {
    const next = { ...regions };
    delete next[region.id];
    saveRegions(next);
    waenToast.info(lang === "ar"
      ? `تم حذف خريطة ${region.nameAr}`
      : `${region.name} map deleted`);
  }

  return (
    <div className="bg-[#F7FAFF] rounded-t-3xl shadow-2xl max-h-[88vh] flex flex-col" dir={dir}>
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-[#D9E4F2] flex-shrink-0">
        <div>
          <h2 className="text-lg font-black text-[#0B1F3A]" style={{ fontFamily:"'Tajawal',sans-serif" }}>
            {t("offlineMaps", lang)}
          </h2>
          <p className="text-xs text-[#61738B] mt-0.5" style={{ fontFamily:"'Tajawal',sans-serif" }}>
            {t("storageUsed", lang)}: {totalMb} MB
          </p>
        </div>
        <button onClick={() => setActivePanel("settings")}
                className="p-2 rounded-full hover:bg-[#F7FAFF]">
          <X size={20} color="#61738B" />
        </button>
      </div>

      {/* Note */}
      <div className="mx-4 mt-3 bg-amber-50 border border-amber-200 rounded-2xl p-3 flex gap-2 flex-shrink-0">
        <Info size={14} color="#92400E" className="flex-shrink-0 mt-0.5" />
        <p className="text-xs text-amber-800" style={{ fontFamily:"'Tajawal',sans-serif" }}>
          {t("offlineNote", lang)} — {lang === "ar"
            ? "التوجيه دون إنترنت يتطلب تثبيت محرك OSRM المحلي (متاح في نسخة المنصة الكاملة)."
            : "Offline routing requires a local OSRM engine (available in the full platform build)."}
        </p>
      </div>

      {/* Regions list */}
      <div className="overflow-y-auto flex-1 p-4 space-y-3 scrollbar-thin">
        {REGIONS.map(region => {
          const state = regions[region.id] ?? { status: "none", progress: 0 };
          return (
            <RegionCard
              key={region.id}
              region={region}
              state={state}
              lang={lang}
              onDownload={() => downloadRegion(region)}
              onDelete={() => deleteRegion(region)}
            />
          );
        })}
      </div>

      <div className="safe-bottom" />
    </div>
  );
}

function RegionCard({
  region, state, lang, onDownload, onDelete
}: {
  region: RegionInfo;
  state: RegionState;
  lang: "ar" | "en";
  onDownload: () => void;
  onDelete: () => void;
}) {
  const name = lang === "ar" ? region.nameAr : region.name;

  return (
    <div className="card p-4">
      <div className="flex items-center gap-3" dir={lang === "ar" ? "rtl" : "ltr"}>
        <div className="w-11 h-11 rounded-2xl bg-[#0A6AD6]/10 flex items-center justify-center flex-shrink-0">
          <Map size={20} color="#0A6AD6" />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <p className="font-bold text-[#0B1F3A]" style={{ fontFamily:"'Tajawal',sans-serif" }}>
              {name}
            </p>
            {state.status === "done" && (
              <span className="badge badge-green text-[10px]">
                <CheckCircle size={9} className="mr-0.5" />
                {t("downloaded", lang)}
              </span>
            )}
            {state.status === "error" && (
              <span className="badge badge-red text-[10px]">
                <AlertCircle size={9} className="mr-0.5" />
                خطأ
              </span>
            )}
          </div>
          <p className="text-xs text-[#61738B] mt-0.5" style={{ fontFamily:"'Tajawal',sans-serif" }}>
            ~{region.estimatedMb} MB
          </p>

          {/* Progress bar */}
          {state.status === "downloading" && (
            <div className="mt-2">
              <div className="nav-progress">
                <div className="nav-progress-fill" style={{ width:`${state.progress}%` }} />
              </div>
              <p className="text-xs text-[#61738B] mt-1" style={{ fontFamily:"'Tajawal',sans-serif" }}>
                {t("downloading", lang)}… {state.progress}%
              </p>
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2 flex-shrink-0">
          {state.status === "done" ? (
            <button onClick={onDelete}
                    className="p-2 hover:bg-red-50 rounded-xl transition-colors">
              <Trash2 size={18} color="#D62828" />
            </button>
          ) : state.status === "downloading" ? (
            <div className="w-6 h-6 border-2 border-[#0A6AD6] border-t-transparent rounded-full animate-spin" />
          ) : (
            <button onClick={onDownload} disabled
                    className="flex items-center gap-1.5 bg-[#D9E4F2] text-[#61738B] text-xs px-3 py-2 rounded-xl cursor-not-allowed">
              <WifiOff size={14} />
              <span style={{ fontFamily:"'Tajawal',sans-serif" }}>
                {lang === "ar" ? "غير متاح" : "Unavailable"}
              </span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
