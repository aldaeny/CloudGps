"use client";
import { useState } from "react";
import { X, ChevronDown, MessageCircle, Mail, Bug, Star, BookOpen } from "lucide-react";
import { useAppStore } from "@/store/useAppStore";
import { t } from "@/lib/translations";

interface HelpTopic { icon: string; title: string; content: string; }

export function HelpPanel() {
  const { language, setActivePanel } = useAppStore();
  const lang = language;
  const dir  = lang === "ar" ? "rtl" : "ltr";
  const [open, setOpen] = useState<number | null>(null);

  const topics: HelpTopic[] = lang === "ar" ? [
    { icon:"🗺️", title:"كيف أبدأ الملاحة؟",
      content:"ابحث عن وجهتك في شريط البحث، اضغط على النتيجة، ثم اضغط 'بدء الملاحة'. ستظهر الخريطة مع المسار وتعليمات المنعطفات الصوتية تلقائياً." },
    { icon:"📍", title:"كيف أبلّغ عن حادث أو ازدحام؟",
      content:"اضغط على زر + الأحمر على الخريطة، اختر نوع البلاغ، تأكد من صحة الموقع، ثم اضغط 'إرسال البلاغ'. يُرجى الإبلاغ فقط عند التوقف في مكان آمن." },
    { icon:"⭐", title:"كيف أحفظ مكاناً في المفضلة؟",
      content:"اضغط على أي مكان على الخريطة، اضغط على اسمه في البطاقة السفلية، ثم اختر 'إضافة للمفضلة' أو 'تعيين كمنزل' أو 'تعيين كعمل'." },
    { icon:"🔊", title:"كيف أتحكم في الصوت؟",
      content:"أثناء الملاحة، اضغط على زر السماعة لكتم الصوت أو تشغيله. يمكنك أيضاً التحكم في الصوت من قائمة الإعدادات." },
    { icon:"📶", title:"ماذا يحدث إذا انقطع الإنترنت؟",
      content:"تستمر الملاحة الحالية والخريطة تعمل بشكل محدود. البحث والبلاغات الجديدة تحتاج إنترنت. لتحميل الخرائط مسبقاً، اذهب إلى الإعدادات > الخرائط المحفوظة." },
    { icon:"🔄", title:"الخريطة لا تتحرك معي أثناء القيادة؟",
      content:"تأكد من منح صلاحية الموقع دائماً وليس 'مرة واحدة فقط'. إذا توقف GPS، ستظهر رسالة تطلب منك إعادة تفعيله." },
    { icon:"🗂️", title:"كيف أغيّر اللغة؟",
      content:"اذهب إلى الإعدادات > اللغة، اختر العربية أو الإنجليزية. ستتغير الواجهة فوراً دون الحاجة لإعادة تشغيل التطبيق." },
  ] : [
    { icon:"🗺️", title:"How do I start navigation?",
      content:"Search for your destination in the search bar, tap the result, then tap 'Start Navigation'. The map will show the route with turn-by-turn voice guidance automatically." },
    { icon:"📍", title:"How do I report an accident or congestion?",
      content:"Tap the red + button on the map, choose the report type, verify the location, then tap 'Submit Report'. Please only report when stopped safely." },
    { icon:"⭐", title:"How do I save a place to favorites?",
      content:"Tap anywhere on the map, tap the name in the bottom card, then choose 'Add to Favorites', 'Set as Home', or 'Set as Work'." },
    { icon:"🔊", title:"How do I control voice navigation?",
      content:"During navigation, tap the speaker icon to mute or unmute. You can also control sound from the Settings menu." },
    { icon:"📶", title:"What happens if I lose internet?",
      content:"Current navigation and the map continue with limited functionality. Search and new reports require internet. To pre-download maps, go to Settings > Offline Maps." },
    { icon:"🔄", title:"The map doesn't follow me while driving?",
      content:"Make sure you've granted 'Always' location permission, not 'Once only'. If GPS stops, a message will prompt you to re-enable it." },
    { icon:"🗂️", title:"How do I change the language?",
      content:"Go to Settings > Language, choose Arabic or English. The interface will change immediately without restarting the app." },
  ];

  return (
    <div className="bg-[#F7FAFF] rounded-t-3xl shadow-2xl max-h-[88vh] flex flex-col" dir={dir}>
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-[#D9E4F2] flex-shrink-0">
        <h2 className="text-lg font-black text-[#0B1F3A]" style={{ fontFamily:"'Tajawal',sans-serif" }}>
          {t("help", lang)}
        </h2>
        <button onClick={() => setActivePanel("settings")}
                className="p-2 rounded-full hover:bg-[#F7FAFF]">
          <X size={20} color="#61738B" />
        </button>
      </div>

      <div className="overflow-y-auto flex-1 scrollbar-thin">
        {/* Topics */}
        <div className="px-5 py-4 space-y-2">
          <p className="text-xs font-bold text-[#61738B] uppercase tracking-wider mb-3"
             style={{ fontFamily:"'Montserrat',sans-serif" }}>
            {lang === "ar" ? "أسئلة شائعة" : "Frequently Asked Questions"}
          </p>
          {topics.map((topic, i) => (
            <div key={i} className="card overflow-hidden">
              <button
                className="flex items-center gap-3 w-full px-4 py-3"
                dir={dir}
                onClick={() => setOpen(open === i ? null : i)}
              >
                <span className="text-xl flex-shrink-0">{topic.icon}</span>
                <span className="flex-1 font-bold text-sm text-[#0B1F3A] text-right"
                      style={{ fontFamily:"'Tajawal',sans-serif" }}>
                  {topic.title}
                </span>
                <ChevronDown size={16} color="#61738B"
                             style={{ transform: open === i ? "rotate(180deg)" : "none",
                                      transition:"transform 0.2s", flexShrink:0 }} />
              </button>
              {open === i && (
                <div className="px-4 pb-4 border-t border-[#D9E4F2]">
                  <p className="text-sm text-[#61738B] mt-3 leading-relaxed"
                     style={{ fontFamily:"'Tajawal',sans-serif" }}>
                    {topic.content}
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Contact */}
        <div className="px-5 pb-6">
          <p className="text-xs font-bold text-[#61738B] uppercase tracking-wider mb-3"
             style={{ fontFamily:"'Montserrat',sans-serif" }}>
            {t("contactUs", lang)}
          </p>
          <div className="space-y-2">
            <a href="mailto:aldaeny60@gmail.com" className="block rounded-2xl focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#0A6AD6]">
              <ContactRow icon={<Mail size={18} color="#0A6AD6" />}
                          label="aldaeny60@gmail.com"
                          sublabel={lang === "ar" ? "البريد الإلكتروني" : "Email"} />
            </a>
            <ContactRow icon={<Bug size={18} color="#D62828" />}
                        label={t("reportBug", lang)}
                        sublabel={lang === "ar" ? "الإبلاغ عن مشكلة تقنية" : "Report a technical issue"} />
            <ContactRow icon={<Star size={18} color="#F59E0B" />}
                        label={t("rateApp", lang)}
                        sublabel={lang === "ar" ? "قيّم تجربتك معنا" : "Rate your experience"} />
          </div>
        </div>
      </div>
      <div className="safe-bottom" />
    </div>
  );
}

function ContactRow({ icon, label, sublabel }: {
  icon: React.ReactNode; label: string; sublabel: string;
}) {
  return (
    <div className="flex items-center gap-3 bg-[#F7FAFF] rounded-2xl p-3">
      <div className="w-10 h-10 rounded-xl bg-[#F7FAFF] flex items-center justify-center flex-shrink-0 shadow-sm">
        {icon}
      </div>
      <div>
        <p className="font-bold text-sm text-[#0B1F3A]" style={{ fontFamily:"'Tajawal',sans-serif" }}>
          {label}
        </p>
        <p className="text-xs text-[#61738B]" style={{ fontFamily:"'Tajawal',sans-serif" }}>
          {sublabel}
        </p>
      </div>
    </div>
  );
}
