"use client";
import { useState } from "react";
import { X, MapPin, Send, CheckCircle } from "lucide-react";
import { useAppStore } from "@/store/useAppStore";
import { t } from "@/lib/translations";
import type { ReportType } from "@/types";
import { REPORT_TYPE_LABELS } from "@/types";
import { getSessionId } from "@/lib/utils";

const REPORT_TYPES = Object.entries(REPORT_TYPE_LABELS).filter(
  ([key]) => key !== "cleared"
) as [ReportType, (typeof REPORT_TYPE_LABELS)[ReportType]][];

export function CreateReportPanel() {
  const {
    language,
    userLocation,
    pendingReportLocation,
    setActivePanel,
    setPendingReportLocation,
    addTrafficReport,
  } = useAppStore();

  const lang = language;
  const dir = lang === "ar" ? "rtl" : "ltr";

  const [selectedType, setSelectedType] = useState<ReportType | null>(null);
  const [description, setDescription] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [savedLocally, setSavedLocally] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const reportLoc = pendingReportLocation ?? userLocation;

  async function handleSubmit() {
    if (!selectedType || !reportLoc) return;

    setSubmitting(true);
    setError(null);

    try {
      const sessionId = getSessionId();
      const res = await fetch("/api/reports", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: selectedType,
          lat: reportLoc.lat,
          lng: reportLoc.lng,
          description,
          sessionId,
        }),
      });

      const data = await res.json().catch(() => ({}));
      if (!res.ok && res.status < 500) throw new Error(data.error ?? t("serverError", lang));
      const localOnly = !res.ok;

      // Add to local store optimistically
      addTrafficReport({
        id: data.id ?? Date.now(),
        type: selectedType,
        lat: reportLoc.lat,
        lng: reportLoc.lng,
        description,
        source: localOnly ? "local" : "community",
        status: "active",
        confidence: 0.5,
        confirmations: 0,
        denials: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        expiresAt: data.expiresAt ?? new Date(Date.now() + 4 * 60 * 60 * 1000).toISOString(),
        reviewStatus: "pending",
      });

      setSavedLocally(localOnly);
      setSuccess(true);
      setTimeout(() => {
        setActivePanel("home");
        setPendingReportLocation(null);
      }, 2000);
    } catch (err) {
      setError(err instanceof Error ? err.message : t("serverError", lang));
    } finally {
      setSubmitting(false);
    }
  }

  if (success) {
    return (
      <div className="bg-[#F7FAFF] rounded-t-3xl shadow-2xl p-8 text-center">
        <CheckCircle size={56} color="#10B981" className="mx-auto mb-4" />
        <h2
          className="text-xl font-bold text-[#0B1F3A] mb-2"
          style={{ fontFamily: "'Tajawal', sans-serif" }}
        >
          {t("reportSent", lang)}
        </h2>
        <p
          className="text-[#61738B]"
          style={{ fontFamily: "'Tajawal', sans-serif" }}
        >
          {savedLocally
            ? (lang === "ar" ? "حُفظ البلاغ على هذا الجهاز فقط لعدم اتصال قاعدة البيانات." : "Saved on this device only because the database is unavailable.")
            : "شكراً لمساهمتك في تحسين حركة المرور"}
        </p>
      </div>
    );
  }

  return (
    <div className="bg-[#F7FAFF] rounded-t-3xl shadow-2xl pb-8" dir={dir}>
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-[#D9E4F2]">
        <h2
          className="text-lg font-bold text-[#0B1F3A]"
          style={{ fontFamily: "'Tajawal', sans-serif" }}
        >
          {t("newReport", lang)}
        </h2>
        <button
          onClick={() => {
            setActivePanel("home");
            setPendingReportLocation(null);
          }}
          className="p-2 rounded-full hover:bg-[#F7FAFF] transition-colors"
        >
          <X size={20} color="#61738B" />
        </button>
      </div>

      <div className="px-5 pt-4 space-y-4">
        {/* Location */}
        <div className="flex items-center gap-2 bg-[#F7FAFF] rounded-xl p-3">
          <MapPin size={16} color="#D62828" />
          <div className="flex-1">
            <p className="text-xs text-[#61738B]" style={{ fontFamily: "'Tajawal', sans-serif" }}>
              {t("reportLocation", lang)}
            </p>
            {reportLoc ? (
              <p className="text-sm text-[#0B1F3A]" style={{ fontFamily: "'Tajawal', sans-serif" }}>
                {reportLoc.lat.toFixed(4)}, {reportLoc.lng.toFixed(4)}
              </p>
            ) : (
              <p className="text-sm text-[#D62828]" style={{ fontFamily: "'Tajawal', sans-serif" }}>
                {t("locationError", lang)}
              </p>
            )}
          </div>
        </div>

        {/* Report Type Selection */}
        <div>
          <p
            className="text-sm font-bold text-[#0B1F3A] mb-3"
            style={{ fontFamily: "'Tajawal', sans-serif" }}
          >
            {t("reportType", lang)}
          </p>
          <div className="grid grid-cols-3 gap-2">
            {REPORT_TYPES.map(([key, info]) => (
              <button
                key={key}
                onClick={() => setSelectedType(key)}
                className={`flex flex-col items-center gap-1 p-3 rounded-2xl border-2 transition-all ${
                  selectedType === key
                    ? "border-[#0A6AD6] bg-[#0A6AD6]/5"
                    : "border-[#D9E4F2] hover:border-[#61738B]"
                }`}
              >
                <span className="text-2xl">{info.icon}</span>
                <span
                  className="text-xs text-center leading-tight"
                  style={{
                    fontFamily: "'Tajawal', sans-serif",
                    color: selectedType === key ? "#0A6AD6" : "#0B1F3A",
                    fontWeight: selectedType === key ? "bold" : "normal",
                  }}
                >
                  {lang === "ar" ? info.ar : info.en}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Optional description */}
        <div>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value.slice(0, 300))}
            placeholder={lang === "ar" ? "وصف اختياري..." : "Optional description..."}
            className="w-full bg-[#F7FAFF] rounded-xl p-3 text-sm text-[#0B1F3A] outline-none resize-none h-20 placeholder-[#61738B]"
            style={{ fontFamily: "'Tajawal', sans-serif", direction: "rtl" }}
            dir="rtl"
            maxLength={300}
          />
          <p className="text-xs text-[#61738B] mt-1 text-end">
            {description.length}/300
          </p>
        </div>

        {/* Error */}
        {error && (
          <p className="text-red-500 text-sm" style={{ fontFamily: "'Tajawal', sans-serif" }}>
            {error}
          </p>
        )}

        {/* Safety notice */}
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-3">
          <p className="text-xs text-amber-700" style={{ fontFamily: "'Tajawal', sans-serif" }}>
            ⚠️ لا تستخدم هاتفك أثناء القيادة. أرسل البلاغات عند التوقف في مكان آمن فقط.
          </p>
        </div>

        {/* Submit */}
        <button
          onClick={handleSubmit}
          disabled={!selectedType || !reportLoc || submitting}
          className="w-full bg-[#D62828] text-white py-4 rounded-2xl font-bold text-lg flex items-center justify-center gap-2 shadow-lg hover:bg-red-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          style={{ fontFamily: "'Tajawal', sans-serif" }}
        >
          {submitting ? (
            <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin" />
          ) : (
            <>
              <Send size={20} />
              {t("submitReport", lang)}
            </>
          )}
        </button>
      </div>
    </div>
  );
}
