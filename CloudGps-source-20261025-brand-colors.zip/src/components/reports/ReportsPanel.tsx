"use client";
import { useEffect, useState, useCallback } from "react";
import {
  AlertTriangle, X, ThumbsUp, CheckCircle,
  Clock, RefreshCw, MapPin, Plus
} from "lucide-react";
import { useAppStore } from "@/store/useAppStore";
import { t } from "@/lib/translations";
import type { TrafficReport } from "@/types";
import { REPORT_TYPE_LABELS } from "@/types";
import { getSessionId } from "@/lib/utils";
import { waenToast } from "@/lib/toast";

export function ReportsPanel() {
  const {
    language, userLocation, trafficReports,
    setTrafficReports, setActivePanel,
  } = useAppStore();

  const [loading, setLoading]   = useState(false);
  const [error,   setError]     = useState<string | null>(null);
  const [lastFetch, setLastFetch] = useState<string | null>(null);
  const lang = language;
  const dir  = lang === "ar" ? "rtl" : "ltr";

  const fetchReports = useCallback(async () => {
    const loc = userLocation ?? { lat: 33.3152, lng: 44.3661 };
    setLoading(true); setError(null);
    try {
      const params = new URLSearchParams({
        lat: String(loc.lat), lng: String(loc.lng), radius: "15",
        ...(lastFetch ? { since: lastFetch } : {}),
      });
      const res  = await fetch(`/api/reports/nearby?${params}`);
      const data = await res.json();
      const localReports = useAppStore.getState().trafficReports.filter((report) => report.source === "local");
      setTrafficReports([...(data.reports ?? []), ...localReports]);
      setLastFetch(data.timestamp ?? new Date().toISOString());
    } catch {
      setError(t("networkError", lang));
    } finally { setLoading(false); }
  }, [userLocation, lang, lastFetch, setTrafficReports]);

  useEffect(() => {
    const timeout = window.setTimeout(() => { void fetchReports(); }, 0);
    return () => window.clearTimeout(timeout);
  }, [fetchReports]);

  async function handleConfirm(reportId: number, type: "confirm" | "resolve" | "deny") {
    const localReport = trafficReports.find((report) => report.id === reportId && report.source === "local");
    if (localReport) {
      setTrafficReports(trafficReports.map((report) => report.id !== reportId ? report : {
        ...report,
        status: type === "resolve" ? "resolved" : report.status,
        confirmations: report.confirmations + (type === "confirm" ? 1 : 0),
        denials: report.denials + (type === "deny" ? 1 : 0),
      }));
      waenToast.success(lang === "ar" ? "تم تحديث البلاغ على هذا الجهاز" : "Updated on this device");
      return;
    }
    const sid = getSessionId();
    try {
      const res = await fetch(`/api/reports/${reportId}/confirm`, {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body: JSON.stringify({ sessionId:sid, type }),
      });
      if (res.ok) {
        waenToast.success(
          type==="resolve"
            ? (lang==="ar"?"تم تسجيل انتهاء الحادثة":"Incident marked as resolved")
            : (lang==="ar"?"تم تأكيد البلاغ":"Report confirmed")
        );
        fetchReports();
      }
    } catch { waenToast.error(t("serverError", lang)); }
  }

  /* Auto-refresh every 60s */
  useEffect(() => {
    const id = setInterval(fetchReports, 60_000);
    return () => clearInterval(id);
  }, [fetchReports]);

  const activeReports = trafficReports.filter(r => r.status === "active");
  const typeGroups = activeReports.reduce<Record<string, number>>((acc, r) => {
    acc[r.type] = (acc[r.type] ?? 0) + 1; return acc;
  }, {});

  return (
    <div className="bg-[#F7FAFF] rounded-t-3xl shadow-2xl max-h-[82vh] flex flex-col" dir={dir}>
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-[#D9E4F2] flex-shrink-0">
        <div>
          <h2 className="text-lg font-black text-[#0B1F3A]" style={{ fontFamily:"'Tajawal',sans-serif" }}>
            {t("nearbyReports", lang)}
          </h2>
          <p className="text-xs text-[#61738B] mt-0.5" style={{ fontFamily:"'Tajawal',sans-serif" }}>
            {lang==="ar"
              ? `${activeReports.length} بلاغ نشط في منطقتك`
              : `${activeReports.length} active reports nearby`}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={fetchReports} disabled={loading}
                  className="p-2 hover:bg-[#F7FAFF] rounded-xl transition-colors">
            <RefreshCw size={16} color="#61738B"
                       className={loading ? "animate-spin" : ""} />
          </button>
          <button onClick={() => setActivePanel("create-report")}
                  className="flex items-center gap-1.5 bg-[#D62828] text-white text-xs px-3 py-2 rounded-xl font-bold hover:bg-red-700 transition-colors"
                  style={{ fontFamily:"'Tajawal',sans-serif" }}>
            <Plus size={13} />
            {t("newReport", lang)}
          </button>
          <button onClick={() => setActivePanel("home")}
                  className="p-2 rounded-full hover:bg-[#F7FAFF]">
            <X size={20} color="#61738B" />
          </button>
        </div>
      </div>

      {/* Type summary chips */}
      {Object.entries(typeGroups).length > 0 && (
        <div className="flex gap-2 px-5 py-3 overflow-x-auto scrollbar-hide border-b border-[#D9E4F2] flex-shrink-0">
          {Object.entries(typeGroups).map(([type, count]) => {
            const info = REPORT_TYPE_LABELS[type as keyof typeof REPORT_TYPE_LABELS];
            if (!info) return null;
            return (
              <div key={type}
                   className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl flex-shrink-0 text-xs font-bold"
                   style={{ background: info.color+"18", color: info.color }}>
                <span>{info.icon}</span>
                <span style={{ fontFamily:"'Tajawal',sans-serif" }}>
                  {lang==="ar"?info.ar:info.en}
                </span>
                <span className="bg-[#F7FAFF] rounded-full px-1.5 py-0.5 text-[10px]">{count}</span>
              </div>
            );
          })}
        </div>
      )}

      {/* Content */}
      <div className="overflow-y-auto flex-1 scrollbar-thin">
        {loading && !trafficReports.length && (
          <div className="space-y-3 p-5">
            {[1,2,3].map(i => <div key={i} className="skeleton h-20 rounded-2xl" />)}
          </div>
        )}

        {error && !loading && (
          <div className="px-5 py-6 text-center">
            <p className="text-[#D62828] mb-3" style={{ fontFamily:"'Tajawal',sans-serif" }}>{error}</p>
            <button onClick={fetchReports}
                    className="btn btn-secondary text-sm px-6 py-2">
              {t("tryAgain", lang)}
            </button>
          </div>
        )}

        {!loading && !error && activeReports.length === 0 && (
          <div className="flex flex-col items-center py-12 px-4">
            <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mb-3">
              <CheckCircle size={32} color="#10B981" />
            </div>
            <p className="text-lg font-black text-[#0B1F3A] mb-1"
               style={{ fontFamily:"'Tajawal',sans-serif" }}>
              {lang==="ar"?"الطرق سليمة!":"Roads are clear!"}
            </p>
            <p className="text-sm text-[#61738B] text-center"
               style={{ fontFamily:"'Tajawal',sans-serif" }}>
              {lang==="ar"?"لا توجد بلاغات نشطة في منطقتك حالياً":"No active reports in your area"}
            </p>
          </div>
        )}

        {activeReports.map(report => (
          <ReportCard key={report.id} report={report} lang={lang} dir={dir} onAction={handleConfirm} />
        ))}
      </div>

      <div className="safe-bottom" />
    </div>
  );
}

function ReportCard({ report, lang, dir, onAction }: {
  report: TrafficReport;
  lang: "ar" | "en";
  dir: string;
  onAction: (id: number, type: "confirm" | "resolve" | "deny") => void;
}) {
  const info = REPORT_TYPE_LABELS[report.type as keyof typeof REPORT_TYPE_LABELS];
  if (!info) return null;

  const ageStr = new Date(report.createdAt).toLocaleTimeString(lang === "ar" ? "ar-IQ" : "en-GB", {
    hour: "2-digit", minute: "2-digit",
  });

  const trustLevel = report.confidence > 0.75 ? "high"
    : report.confidence > 0.5 ? "medium" : "low";

  return (
    <div className="px-5 py-4 border-b border-[#D9E4F2] last:border-0" dir={dir}>
      <div className="flex items-start gap-3">
        {/* Icon */}
        <div className="w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0 text-2xl"
             style={{ background: info.color+"18" }}>
          {info.icon}
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap mb-1">
            <span className="font-black text-sm" style={{ color:info.color, fontFamily:"'Tajawal',sans-serif" }}>
              {lang==="ar"?info.ar:info.en}
            </span>
            {trustLevel === "high" && (
              <span className="badge badge-green text-[10px]">✓ مؤكد</span>
            )}
            {trustLevel === "low" && (
              <span className="badge badge-gray text-[10px]">غير مؤكد</span>
            )}
          </div>

          {report.description && (
            <p className="text-xs text-[#0B1F3A] mb-1 line-clamp-2"
               style={{ fontFamily:"'Tajawal',sans-serif" }}>
              {report.description}
            </p>
          )}

          <div className="flex items-center gap-3 text-[11px] text-[#61738B] mb-2">
            <span className="flex items-center gap-1" style={{ fontFamily:"'Tajawal',sans-serif" }}>
              <Clock size={10}/>{ageStr}
            </span>
            <span style={{ fontFamily:"'Tajawal',sans-serif" }}>
              {report.confirmations} {lang==="ar"?"تأكيد":"confirmations"}
            </span>
            <span className="badge badge-gray text-[9px]">{t("reportedBy", lang)}</span>
          </div>

          {/* Trust bar */}
          <div className="flex items-center gap-2 mb-3">
            <div className="flex-1 h-1 bg-[#D9E4F2] rounded-full overflow-hidden">
              <div className="h-full rounded-full transition-all"
                   style={{ width:`${Math.round(report.confidence*100)}%`,
                            background: report.confidence > 0.7 ? "#10B981" : report.confidence > 0.5 ? "#F59E0B" : "#D62828" }} />
            </div>
            <span className="text-[10px] text-[#61738B]">{Math.round(report.confidence*100)}%</span>
          </div>

          {/* Actions */}
          <div className="flex gap-2">
            <button onClick={() => onAction(report.id, "confirm")}
                    className="flex items-center gap-1 text-xs text-[#0A6AD6] bg-[#0A6AD6]/10 px-3 py-1.5 rounded-xl hover:bg-[#0A6AD6]/20 transition-colors font-bold"
                    style={{ fontFamily:"'Tajawal',sans-serif" }}>
              <ThumbsUp size={11}/>{t("confirmReport", lang)}
            </button>
            <button onClick={() => onAction(report.id, "resolve")}
                    className="flex items-center gap-1 text-xs text-[#61738B] bg-[#F7FAFF] px-3 py-1.5 rounded-xl hover:bg-[#D9E4F2] transition-colors"
                    style={{ fontFamily:"'Tajawal',sans-serif" }}>
              <CheckCircle size={11}/>{t("reportResolved", lang)}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
