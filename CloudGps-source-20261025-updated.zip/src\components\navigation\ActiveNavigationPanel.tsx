"use client";
import { useEffect } from "react";
import {
  Volume2, VolumeX, X, Navigation, Clock, MapPin,
  ChevronLeft, ChevronRight, AlertTriangle
} from "lucide-react";
import { useAppStore } from "@/store/useAppStore";
import { t } from "@/lib/translations";
import { formatDistance, formatDuration, formatETA } from "@/lib/utils";
import { useNavigationEngine } from "@/hooks/useNavigationEngine";

/* ── Maneuver arrow icon ── */
function ManeuverArrow({ type, size = 28 }: { type: string; size?: number }) {
  const map: Record<string, string> = {
    "turn-left":       "↰",  "turn-sharp left":  "⬅",
    "turn-right":      "↱",  "turn-sharp right": "➡",
    "turn-slight left":"↖",  "turn-slight right":"↗",
    "continue":        "⬆",  "straight":         "⬆",
    "arrive":          "📍", "depart":           "🚗",
    "roundabout":      "🔄", "merge":            "↗",
    "uturn":           "↩",  "fork":             "⬆",
  };
  const key = Object.keys(map).find(k => type?.toLowerCase().includes(k)) ?? "straight";
  return <span style={{ fontSize: size }}>{map[key]}</span>;
}

/* ── Speed indicator ── */
function SpeedBadge({ speedKmh }: { speedKmh: number }) {
  const color =
    speedKmh > 80 ? "#D62828" :
    speedKmh > 50 ? "#F97316" : "#0A6AD6";
  return (
    <div className="flex flex-col items-center justify-center w-14 h-14 rounded-2xl border-2"
         style={{ borderColor: color, background: color + "15" }}>
      <span className="font-black text-lg leading-none" style={{ color, fontFamily: "'Montserrat',sans-serif" }}>
        {Math.round(speedKmh)}
      </span>
      <span className="text-[9px] font-bold" style={{ color, fontFamily: "'Montserrat',sans-serif" }}>km/h</span>
    </div>
  );
}

export function ActiveNavigationPanel() {
  const {
    language, navigation, userLocation, voiceMuted, destination,
    setNavigation, setVoiceMuted, setActivePanel,
  } = useAppStore();
  const lang = language;
  const dir  = lang === "ar" ? "rtl" : "ltr";
  const { speak, stopNavigation } = useNavigationEngine();

  /* announce on mount */
  useEffect(() => {
    if (navigation.status === "active" && navigation.route) {
      const step = navigation.route.steps[0];
      if (step) {
        setTimeout(() => speak(
          lang === "ar"
            ? `بدأت الملاحة. ${step.instructionAr}، بعد ${formatDistance(step.distance, "ar")}`
            : `Navigation started. ${step.instruction}, in ${formatDistance(step.distance, "en")}`
        , true), 800);
      }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ── Arrived screen ── */
  if (navigation.status === "arrived") {
    return (
      <div className="bottom-sheet animate-slide-up" dir={dir}>
        <div className="flex flex-col items-center py-8 px-6 text-center">
          <div className="w-20 h-20 rounded-full bg-emerald-100 flex items-center justify-center mb-4">
            <span className="text-4xl">🎉</span>
          </div>
          <h2 className="text-2xl font-black text-[#0B1F3A] mb-1"
              style={{ fontFamily:"'Tajawal',sans-serif" }}>
            {t("arrived", lang)}
          </h2>
          {destination && (
            <p className="text-[#657570] mb-6" style={{ fontFamily:"'Tajawal',sans-serif" }}>
              {destination.name}
            </p>
          )}
          {navigation.route && (
            <div className="flex gap-6 mb-6">
              <div className="text-center">
                <p className="text-2xl font-black text-[#0A6AD6]"
                   style={{ fontFamily:"'Tajawal',sans-serif" }}>
                  {formatDistance(navigation.route.distance, lang)}
                </p>
                <p className="text-xs text-[#657570]" style={{ fontFamily:"'Tajawal',sans-serif" }}>
                  {t("distance", lang)}
                </p>
              </div>
              <div className="w-px bg-[#DADFD7]" />
              <div className="text-center">
                <p className="text-2xl font-black text-[#0A6AD6]"
                   style={{ fontFamily:"'Tajawal',sans-serif" }}>
                  {formatDuration(navigation.route.duration, lang)}
                </p>
                <p className="text-xs text-[#657570]" style={{ fontFamily:"'Tajawal',sans-serif" }}>
                  {t("duration", lang)}
                </p>
              </div>
            </div>
          )}
          <button onClick={stopNavigation}
                  className="btn btn-primary w-full text-lg"
                  style={{ fontFamily:"'Tajawal',sans-serif" }}>
            {t("done", lang)}
          </button>
        </div>
      </div>
    );
  }

  if (navigation.status === "idle") return null;

  const currentStep = navigation.route?.steps[navigation.currentStepIndex];
  const nextStep    = navigation.route?.steps[(navigation.currentStepIndex ?? 0) + 1];
  const totalDist   = navigation.route?.distance ?? 1;
  const progress    = Math.max(0, Math.min(100,
    (1 - navigation.distanceRemaining / totalDist) * 100
  ));

  return (
    <div className="bottom-sheet animate-slide-up" dir={dir}
         style={{ background:"#0B1F3A" }}>

      {/* ── Rerouting banner ── */}
      {navigation.status === "rerouting" && (
        <div className="bg-[#D62828] rounded-t-3xl text-center py-2 px-4">
          <div className="flex items-center justify-center gap-2">
            <div className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
            <span className="text-white text-sm font-bold" style={{ fontFamily:"'Tajawal',sans-serif" }}>
              {t("recalculating", lang)}
            </span>
          </div>
        </div>
      )}

      {/* ── Off-route warning ── */}
      {navigation.isOffRoute && navigation.status !== "rerouting" && (
        <div className="bg-amber-500 rounded-t-3xl text-center py-2 px-4">
          <p className="text-white text-sm font-bold" style={{ fontFamily:"'Tajawal',sans-serif" }}>
            ⚠️ {t("offRoute", lang)}
          </p>
        </div>
      )}

      {/* ── Progress bar ── */}
      <div className="nav-progress mx-4 mt-3">
        <div className="nav-progress-fill" style={{ width:`${progress}%` }} />
      </div>

      {/* ── Main instruction ── */}
      {currentStep && (
        <div className="flex items-center gap-4 px-5 pt-4 pb-2">
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center flex-shrink-0"
               style={{ background:"#0A6AD6" }}>
            <ManeuverArrow type={currentStep.maneuver} size={26} />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xl font-black text-white leading-tight"
               style={{ fontFamily:"'Tajawal',sans-serif" }}>
              {lang === "ar" ? currentStep.instructionAr : currentStep.instruction}
            </p>
            {currentStep.name && (
              <p className="text-[#657570] text-sm mt-0.5" style={{ fontFamily:"'Tajawal',sans-serif" }}>
                {currentStep.name}
              </p>
            )}
          </div>
          <div className="flex-shrink-0 text-right">
            <p className="text-2xl font-black" style={{ color:"#4ADE80", fontFamily:"'Montserrat',sans-serif" }}>
              {formatDistance(navigation.distanceToNextStep, lang)}
            </p>
          </div>
        </div>
      )}

      {/* ── Street name & next step ── */}
      <div className="px-5 pb-3 space-y-2">
        {navigation.currentStreetName && (
          <div className="flex items-center gap-2 bg-white/8 rounded-xl px-3 py-2">
            <Navigation size={13} color="#657570" />
            <span className="text-sm text-white/75" style={{ fontFamily:"'Tajawal',sans-serif" }}>
              {navigation.currentStreetName}
            </span>
          </div>
        )}
        {nextStep && (
          <div className="flex items-center gap-2 bg-white/5 rounded-xl px-3 py-1.5">
            <span className="text-xs text-[#657570]" style={{ fontFamily:"'Tajawal',sans-serif" }}>
              {t("then", lang)}:
            </span>
            <span className="text-xs text-white/60 flex-1" style={{ fontFamily:"'Tajawal',sans-serif" }}>
              {lang === "ar" ? nextStep.instructionAr : nextStep.instruction}
            </span>
          </div>
        )}
      </div>

      {/* ── Minimal Bottom Stats Card ── */}
      <div className="absolute bottom-6 left-4 right-4 z-50">
        <div className="bg-[#0B1F3A] rounded-3xl p-4 flex items-center justify-between shadow-2xl border border-white/10">
          
          <div className="flex flex-col gap-0.5">
            <div className="flex items-center gap-2">
              <span className="text-xl font-black text-white" style={{ fontFamily:"'Tajawal',sans-serif" }}>
                {formatDuration(navigation.timeRemaining, lang)}
              </span>
              <span className="text-[#657570] font-bold text-sm">/</span>
              <span className="text-sm font-bold text-[#657570]" style={{ fontFamily:"'Tajawal',sans-serif" }}>
                {formatDistance(navigation.distanceRemaining, lang)}
              </span>
            </div>
            <p className="text-xs text-[#0A6AD6] font-bold tracking-wider uppercase" style={{ fontFamily:"'Montserrat',sans-serif" }}>
              ETA {navigation.eta ? formatETA(navigation.timeRemaining) : "--:--"}
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button onClick={() => setVoiceMuted(!voiceMuted)}
                    className="w-12 h-12 rounded-full flex items-center justify-center transition-all"
                    style={{ background: voiceMuted ? "#D62828" : "#1a2f2e" }}>
              {voiceMuted
                ? <VolumeX size={20} color="white" />
                : <Volume2 size={20} color="white" />}
            </button>
            <button onClick={stopNavigation}
                    className="w-12 h-12 rounded-full flex items-center justify-center bg-[#D62828] shadow-lg">
              <X size={22} color="white" />
            </button>
          </div>

        </div>
      </div>
    </div>
  );
}
