"use client";
import { useState, useEffect } from "react";
import {
  X, User, MapPin, Navigation, Clock, Star,
  LogOut, Trash2, Download, Edit2, ChevronRight,
  Shield, Award
} from "lucide-react";
import { useAppStore } from "@/store/useAppStore";
import { t } from "@/lib/translations";
import { formatDistance, getSessionId } from "@/lib/utils";
import { WainLogoCompact } from "./WainLogo";

interface Stats {
  totalTrips: number;
  totalDistanceKm: number;
  savedPlacesCount: number;
  reportsCount: number;
}

export function ProfilePanel() {
  const {
    language, savedPlaces, recentDestinations,
    setActivePanel, clearRecentDestinations,
  } = useAppStore();
  const lang = language;
  const dir  = lang === "ar" ? "rtl" : "ltr";

  const [stats, setStats] = useState<Stats>({
    totalTrips: 0, totalDistanceKm: 0,
    savedPlacesCount: savedPlaces.length,
    reportsCount: 0,
  });
  const [editName, setEditName] = useState(false);
  const [displayName, setDisplayName] = useState(
    () => typeof window !== "undefined"
      ? (localStorage.getItem("waen_display_name") ?? "")
      : ""
  );

  useEffect(() => {
    const sid = getSessionId();
    fetch(`/api/trips?sessionId=${sid}&limit=100`)
      .then(r => r.json())
      .then(data => {
        const trips = data.trips ?? [];
        const dist = trips.reduce((s: number, t: { distanceKm?: number }) => s + (t.distanceKm ?? 0), 0);
        setStats(prev => ({
          ...prev,
          totalTrips: trips.length,
          totalDistanceKm: dist,
          savedPlacesCount: savedPlaces.length,
        }));
      })
      .catch(() => {});
  }, [savedPlaces.length]);

  function saveName() {
    localStorage.setItem("waen_display_name", displayName);
    setEditName(false);
  }

  return (
    <div className="bg-[#F5F5EE] rounded-t-3xl shadow-2xl max-h-[88vh] flex flex-col" dir={dir}>
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-[#DADFD7] flex-shrink-0">
        <h2 className="text-lg font-black text-[#0B1F3A]" style={{ fontFamily:"'Tajawal',sans-serif" }}>
          {t("profile", lang)}
        </h2>
        <button onClick={() => setActivePanel("home")}
                className="p-2 rounded-full hover:bg-[#F5F5EE]">
          <X size={20} color="#657570" />
        </button>
      </div>

      <div className="overflow-y-auto flex-1 scrollbar-thin">
        {/* Avatar + Name */}
        <div className="flex flex-col items-center py-8 px-5 bg-gradient-to-b from-[#0A6AD6]/5 to-white">
          <div className="w-20 h-20 rounded-full bg-[#0A6AD6] flex items-center justify-center mb-3 shadow-lg">
            <User size={36} color="white" />
          </div>
          {editName ? (
            <div className="flex items-center gap-2 mt-1 w-full max-w-xs">
              <input
                value={displayName}
                onChange={e => setDisplayName(e.target.value)}
                onKeyDown={e => e.key === "Enter" && saveName()}
                className="waen-input flex-1 text-center"
                placeholder={lang === "ar" ? "اسمك..." : "Your name..."}
                dir={lang === "ar" ? "rtl" : "ltr"}
                autoFocus
              />
              <button onClick={saveName}
                      className="btn btn-primary px-4 py-3 text-sm rounded-xl">
                {t("save", lang)}
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <p className="text-xl font-black text-[#0B1F3A]"
                 style={{ fontFamily:"'Tajawal',sans-serif" }}>
                {displayName || (lang === "ar" ? "مستخدم السحاب" : "CloudGps user")}
              </p>
              <button onClick={() => setEditName(true)}>
                <Edit2 size={14} color="#657570" />
              </button>
            </div>
          )}
          <p className="text-sm text-[#657570] mt-1" style={{ fontFamily:"'Tajawal',sans-serif" }}>
            {lang === "ar" ? "مستخدم مجهول • بدون حساب" : "Guest user • No account"}
          </p>

          {/* Badges */}
          <div className="flex gap-2 mt-3">
            <span className="badge badge-green">
              <Award size={10} className="me-1" />
              {lang === "ar" ? "سائق عراقي" : "Iraqi Driver"}
            </span>
            {stats.totalTrips >= 10 && (
              <span className="badge badge-orange">
                🏆 {lang === "ar" ? "مستكشف" : "Explorer"}
              </span>
            )}
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-3 px-5 mb-4">
          <StatCard
            icon={<Navigation size={20} color="#0A6AD6" />}
            value={String(stats.totalTrips)}
            label={t("totalTrips", lang)}
            lang={lang}
          />
          <StatCard
            icon={<MapPin size={20} color="#D62828" />}
            value={`${stats.totalDistanceKm.toFixed(0)} كم`}
            label={t("totalDistance", lang)}
            lang={lang}
          />
          <StatCard
            icon={<Star size={20} color="#F59E0B" />}
            value={String(savedPlaces.length)}
            label={t("savedPlaces", lang)}
            lang={lang}
          />
          <StatCard
            icon={<Clock size={20} color="#6366F1" />}
            value={String(recentDestinations.length)}
            label={t("recentDestinations", lang)}
            lang={lang}
          />
        </div>

        {/* Actions */}
        <div className="px-5 space-y-2 pb-6">
          <SectionTitle title={lang === "ar" ? "إعدادات الحساب" : "Account Settings"} />

          <ActionRow
            icon={<Shield size={18} color="#0A6AD6" />}
            label={t("privacy", lang)}
            onClick={() => setActivePanel("settings")}
            lang={lang}
          />
          <ActionRow
            icon={<Download size={18} color="#0A6AD6" />}
            label={t("exportData", lang)}
            onClick={() => {
              const data = {
                savedPlaces: useAppStore.getState().savedPlaces,
                recentDestinations: useAppStore.getState().recentDestinations,
                exportedAt: new Date().toISOString(),
              };
              const blob = new Blob([JSON.stringify(data, null, 2)], { type:"application/json" });
              const url = URL.createObjectURL(blob);
              const a = document.createElement("a");
              a.href = url; a.download = "waen-data.json"; a.click();
              URL.revokeObjectURL(url);
            }}
            lang={lang}
          />
          <ActionRow
            icon={<Trash2 size={18} color="#D62828" />}
            label={t("clearHistory", lang)}
            onClick={() => { clearRecentDestinations(); }}
            danger
            lang={lang}
          />
        </div>

        {/* Sign-in prompt */}
        <div className="mx-5 mb-6 bg-gradient-to-r from-[#0A6AD6] to-[#074BA4] rounded-2xl p-4 text-white">
          <div className="flex items-center gap-3 mb-3">
            <WainLogoCompact size={32} />
            <div>
              <p className="font-bold text-sm" style={{ fontFamily:"'Tajawal',sans-serif" }}>
                {lang === "ar" ? "سجّل للمزامنة بين أجهزتك" : "Sign in to sync across devices"}
              </p>
              <p className="text-white/60 text-xs" style={{ fontFamily:"'Tajawal',sans-serif" }}>
                {lang === "ar" ? "قريباً في الإصدار القادم" : "Coming in the next release"}
              </p>
            </div>
          </div>
          <button disabled
                  className="w-full bg-white/20 text-white py-2.5 rounded-xl text-sm font-bold opacity-50 cursor-not-allowed"
                  style={{ fontFamily:"'Tajawal',sans-serif" }}>
            {t("createAccount", lang)} — {lang === "ar" ? "قريباً" : "Coming Soon"}
          </button>
        </div>
      </div>
      <div className="safe-bottom" />
    </div>
  );
}

function StatCard({ icon, value, label, lang }: {
  icon: React.ReactNode; value: string; label: string; lang: "ar" | "en";
}) {
  return (
    <div className="card p-4 text-center">
      <div className="flex justify-center mb-2">{icon}</div>
      <p className="text-xl font-black text-[#0B1F3A]"
         style={{ fontFamily:"'Montserrat',sans-serif" }}>
        {value}
      </p>
      <p className="text-xs text-[#657570] mt-0.5" style={{ fontFamily:"'Tajawal',sans-serif" }}>
        {label}
      </p>
    </div>
  );
}

function SectionTitle({ title }: { title: string }) {
  return (
    <p className="text-xs font-bold text-[#657570] uppercase tracking-wider px-1 pt-2"
       style={{ fontFamily:"'Montserrat',sans-serif" }}>
      {title}
    </p>
  );
}

function ActionRow({ icon, label, onClick, danger, lang }: {
  icon: React.ReactNode; label: string;
  onClick: () => void; danger?: boolean; lang: "ar" | "en";
}) {
  return (
    <button onClick={onClick}
            className="flex items-center gap-3 w-full px-4 py-3 rounded-2xl hover:bg-[#F5F5EE] transition-colors"
            dir={lang === "ar" ? "rtl" : "ltr"}>
      {icon}
      <span className="flex-1 text-sm text-right"
            style={{ fontFamily:"'Tajawal',sans-serif", color: danger ? "#D62828" : "#0B1F3A" }}>
        {label}
      </span>
      <ChevronRight size={16} color="#657570"
                   className={lang === "ar" ? "rotate-180" : ""} />
    </button>
  );
}
