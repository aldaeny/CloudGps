"use client";
import { useCallback, useEffect, useState } from "react";
import { X, Clock, MapPin, Navigation, Trash2, RefreshCw } from "lucide-react";
import { useAppStore } from "@/store/useAppStore";
import { t } from "@/lib/translations";
import { formatDistance, formatDuration, getSessionId } from "@/lib/utils";

interface Trip {
  id: number;
  originName?: string;
  destName?: string;
  distanceKm?: number;
  durationMin?: number;
  startedAt: string;
  completedAt?: string;
  status?: string;
}

export function TripHistoryPanel() {
  const { language, setActivePanel, setDestination, setOrigin, userLocation, recentDestinations } = useAppStore();
  const lang = language;
  const dir  = lang === "ar" ? "rtl" : "ltr";

  const [trips, setTrips] = useState<Trip[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleting, setDeleting] = useState(false);

  const fetchTrips = useCallback(async () => {
    try {
      const sid = getSessionId();
      const res = await fetch(`/api/trips?sessionId=${sid}&limit=20`);
      if (!res.ok) throw new Error("Could not load trips");
      const data = await res.json();
      const serverTrips = data.trips ?? [];
      setTrips(serverTrips.length ? serverTrips : recentDestinations.map((recent, index) => ({
        id: -index - 1,
        destName: recent.name,
        startedAt: recent.visitedAt,
        status: "local",
      })));
    } catch {
      setTrips(recentDestinations.map((recent, index) => ({
        id: -index - 1,
        destName: recent.name,
        startedAt: recent.visitedAt,
        status: "local",
      })));
    }
    finally { setLoading(false); }
  }, [recentDestinations]);

  useEffect(() => {
    const timeout = window.setTimeout(() => { void fetchTrips(); }, 0);
    return () => window.clearTimeout(timeout);
  }, [fetchTrips]);

  async function clearHistory() {
    setDeleting(true);
    try {
      const sid = getSessionId();
      const response = await fetch(`/api/trips?sessionId=${sid}`, { method: "DELETE" });
      if (!response.ok) throw new Error("Could not clear server history");
      setTrips([]);
    } catch {
      setTrips([]);
    } finally {
      useAppStore.getState().clearRecentDestinations();
      setDeleting(false);
    }
  }

  function navigateAgain(trip: Trip) {
    if (!trip.destName) return;
    // We don't have exact coords from history — use recent destinations store
    const recent = useAppStore.getState().recentDestinations;
    const match = recent.find(r => r.name === trip.destName);
    if (match) {
      setDestination({ name: match.name, location: match.location });
      if (userLocation) setOrigin({ name: t("myLocation", lang), location: userLocation });
      setActivePanel("route-preview");
    }
  }

  return (
    <div className="bg-[#F5F5EE] rounded-t-3xl shadow-2xl max-h-[80vh] flex flex-col" dir={dir}>
      <div className="flex items-center justify-between px-5 py-4 border-b border-[#DADFD7] flex-shrink-0">
        <h2 className="text-lg font-black text-[#0B1F3A]" style={{ fontFamily:"'Tajawal',sans-serif" }}>
          {t("recentDestinations", lang)}
        </h2>
        <div className="flex items-center gap-2">
          {trips.length > 0 && (
            <button onClick={clearHistory} disabled={deleting}
                    className="flex items-center gap-1 text-xs text-[#D62828] bg-red-50 px-3 py-1.5 rounded-xl hover:bg-red-100 transition-colors">
              <Trash2 size={12} />
              <span style={{ fontFamily:"'Tajawal',sans-serif" }}>{t("clearHistory", lang)}</span>
            </button>
          )}
          <button onClick={() => setActivePanel("home")}
                  className="p-2 rounded-full hover:bg-[#F5F5EE] transition-colors">
            <X size={20} color="#657570" />
          </button>
        </div>
      </div>

      <div className="overflow-y-auto flex-1 scrollbar-thin">
        {loading && (
          <div className="space-y-3 p-5">
            {[1,2,3].map(i => (
              <div key={i} className="skeleton h-16 rounded-2xl" />
            ))}
          </div>
        )}

        {!loading && trips.length === 0 && (
          <div className="flex flex-col items-center py-14 px-4">
            <div className="text-6xl mb-4">🗺️</div>
            <p className="text-lg font-bold text-[#0B1F3A] mb-1"
               style={{ fontFamily:"'Tajawal',sans-serif" }}>
              {lang === "ar" ? "لا توجد رحلات سابقة" : "No trip history"}
            </p>
            <p className="text-sm text-[#657570] text-center"
               style={{ fontFamily:"'Tajawal',sans-serif" }}>
              {lang === "ar" ? "ستظهر رحلاتك هنا بعد أول ملاحة" : "Your trips will appear here"}
            </p>
          </div>
        )}

        {!loading && trips.map(trip => (
          <div key={trip.id}
               className="flex items-center gap-3 px-5 py-4 border-b border-[#DADFD7] last:border-0 hover:bg-[#F5F5EE] transition-colors">
            <div className="w-10 h-10 rounded-2xl bg-[#0A6AD6]/10 flex items-center justify-center flex-shrink-0">
              <Navigation size={18} color="#0A6AD6" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-bold text-sm text-[#0B1F3A] truncate"
                 style={{ fontFamily:"'Tajawal',sans-serif" }}>
                {trip.destName ?? (lang === "ar" ? "وجهة غير معروفة" : "Unknown destination")}
              </p>
              <div className="flex items-center gap-3 mt-0.5">
                {trip.distanceKm && (
                  <span className="text-xs text-[#657570] flex items-center gap-1"
                        style={{ fontFamily:"'Tajawal',sans-serif" }}>
                    <MapPin size={10} />
                    {trip.distanceKm.toFixed(1)} كم
                  </span>
                )}
                {trip.durationMin && (
                  <span className="text-xs text-[#657570] flex items-center gap-1"
                        style={{ fontFamily:"'Tajawal',sans-serif" }}>
                    <Clock size={10} />
                    {Math.round(trip.durationMin)} د
                  </span>
                )}
                <span className="text-xs text-[#657570]" style={{ fontFamily:"'Tajawal',sans-serif" }}>
                  {new Date(trip.startedAt).toLocaleDateString(lang === "ar" ? "ar-IQ" : "en-GB")}
                </span>
              </div>
            </div>
            <button onClick={() => navigateAgain(trip)}
                    className="p-2 hover:bg-[#DADFD7] rounded-xl transition-colors flex-shrink-0">
              <RefreshCw size={16} color="#0A6AD6" />
            </button>
          </div>
        ))}
      </div>
      <div className="safe-bottom" />
    </div>
  );
}
