"use client";
import { useEffect, useRef, useState, useCallback } from "react";
import type { Map as LeafletMap, Marker, Polyline, CircleMarker, Circle } from "leaflet";
import { useAppStore } from "@/store/useAppStore";
import { REPORT_TYPE_LABELS } from "@/types";

interface MapComponentProps {
  onMapClick?: (lat: number, lng: number) => void;
  onMapReady?: (map: LeafletMap) => void;
  className?: string;
}

export function MapComponent({ onMapClick, onMapReady, className }: MapComponentProps) {
  const mapDivRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<LeafletMap | null>(null);
  const userMarkerRef = useRef<Marker | null>(null);
  const userCircleRef = useRef<Circle | null>(null);
  const destMarkerRef = useRef<Marker | null>(null);
  const routeLineRef = useRef<Polyline | null>(null);
  const routeCasingRef = useRef<Polyline | null>(null);
  const altLinesRef = useRef<Polyline[]>([]);
  const altCasingsRef = useRef<Polyline[]>([]);
  const reportMarkersRef = useRef<CircleMarker[]>([]);
  const leafletRef = useRef<typeof import("leaflet") | null>(null);
  const [mapError, setMapError] = useState<string | null>(null);
  const [ready, setReady] = useState(false);

  const {
    userLocation, locationAccuracy, mapCenter, mapZoom, isDarkMap,
    destination, routes, selectedRouteIndex, trafficReports,
    showReportsLayer, navigation, setMapCenter, setMapZoom,
  } = useAppStore();

  /* ── Helper: get tile URL ── */
  // Use the public OSM tiles for both themes. The previous dark Carto URL now
  // returns an API-key-required tile, which made the night map look broken.
  const getTileUrl = useCallback(() =>
    "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
  , []);

  /* ── Init ── */
  useEffect(() => {
    if (!mapDivRef.current || mapRef.current) return;
    let cancelled = false;

    (async () => {
      try {
        const L = await import("leaflet");
        if (cancelled || !mapDivRef.current) return;
        leafletRef.current = L;

        // Fix marker icons
        delete (L.Icon.Default.prototype as any)._getIconUrl;
        L.Icon.Default.mergeOptions({
          iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
          iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
          shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
        });

        const map = L.map(mapDivRef.current, {
          center: [mapCenter.lat, mapCenter.lng],
          zoom: mapZoom,
          zoomControl: false,
          attributionControl: true,
        });

        L.tileLayer(getTileUrl(), {
          attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
          maxZoom: 19,
          subdomains: ["a","b","c"],
        }).addTo(map);

        map.on("moveend", () => {
          const c = map.getCenter();
          setMapCenter({ lat: c.lat, lng: c.lng });
          setMapZoom(map.getZoom());
        });

        map.on("click", (e) => {
          onMapClick?.(e.latlng.lat, e.latlng.lng);
        });

        // Force a resize after mount so tiles load correctly
        setTimeout(() => map.invalidateSize(), 200);
        setTimeout(() => map.invalidateSize(), 600);

        mapRef.current = map;
        setReady(true);
        onMapReady?.(map);

      } catch (err) {
        console.error("Map init failed:", err);
        setMapError("تعذّر تحميل الخريطة");
      }
    })();

    return () => {
      cancelled = true;
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ── User marker ── */
  useEffect(() => {
    const map = mapRef.current;
    const L = leafletRef.current;
    if (!map || !L || !ready) return;

    if (userMarkerRef.current) { map.removeLayer(userMarkerRef.current); userMarkerRef.current = null; }
    if (userCircleRef.current) { map.removeLayer(userCircleRef.current); userCircleRef.current = null; }
    if (!userLocation) return;

    // Accuracy circle
    if (locationAccuracy && locationAccuracy < 500) {
      userCircleRef.current = L.circle([userLocation.lat, userLocation.lng], {
        radius: locationAccuracy,
        color: "#0A6AD6", fillColor: "#0A6AD6",
        fillOpacity: 0.07, weight: 1, opacity: 0.25,
      }).addTo(map);
    }

    // User dot
    const icon = L.divIcon({
      html: `<div style="width:22px;height:22px;background:#0A6AD6;border:3px solid white;border-radius:50%;box-shadow:0 2px 10px rgba(10,106,214,0.5)">
        <div style="position:absolute;inset:5px;background:white;border-radius:50%"></div>
      </div>`,
      className: "",
      iconSize: [22, 22],
      iconAnchor: [11, 11],
    });

    userMarkerRef.current = L.marker([userLocation.lat, userLocation.lng], {
      icon, zIndexOffset: 1000,
    }).addTo(map);
  }, [userLocation, locationAccuracy, ready]);

  /* ── Destination marker ── */
  useEffect(() => {
    const map = mapRef.current;
    const L = leafletRef.current;
    if (!map || !L || !ready) return;

    if (destMarkerRef.current) { map.removeLayer(destMarkerRef.current); destMarkerRef.current = null; }
    if (!destination) return;

    const icon = L.divIcon({
      html: `<div style="width:32px;height:42px">
        <svg viewBox="0 0 32 42" fill="none"><path d="M16 0C7.16 0 0 7.16 0 16C0 28 16 42 16 42C16 42 32 28 32 16C32 7.16 24.84 0 16 0Z" fill="#D62828"/><circle cx="16" cy="16" r="8" fill="white"/><circle cx="16" cy="16" r="4" fill="#D62828"/></svg>
      </div>`,
      className: "",
      iconSize: [32, 42],
      iconAnchor: [16, 42],
    });

    destMarkerRef.current = L.marker(
      [destination.location.lat, destination.location.lng],
      { icon, zIndexOffset: 900 }
    ).bindPopup(`<b style="font-family:'Tajawal',sans-serif">${destination.name}</b>`).addTo(map);
  }, [destination, ready]);

  /* ── Routes ── */
  useEffect(() => {
    const map = mapRef.current;
    const L = leafletRef.current;
    if (!map || !L || !ready) return;

    if (routeLineRef.current) { map.removeLayer(routeLineRef.current); routeLineRef.current = null; }
    if (routeCasingRef.current) { map.removeLayer(routeCasingRef.current); routeCasingRef.current = null; }
    altLinesRef.current.forEach(l => map.removeLayer(l));
    altLinesRef.current = [];
    altCasingsRef.current.forEach(l => map.removeLayer(l));
    altCasingsRef.current = [];

    if (!routes.length) return;

    routes.forEach((route, idx) => {
      const selected = idx === selectedRouteIndex;
      const coords = route.geometry.map(p => [p.lat, p.lng] as [number, number]);
      const casing = L.polyline(coords, {
        color: isDarkMap ? "#152622" : "#F5F5EE",
        weight: selected ? 12 : 8,
        opacity: selected ? 0.98 : 0.72,
        lineCap: "round",
        lineJoin: "round",
      }).addTo(map);
      const line = L.polyline(coords, {
        color: selected
          ? (isDarkMap ? "#57CDB5" : "#087765")
          : (isDarkMap ? "#A8BDB6" : "#7B8C86"),
        weight: selected ? 7 : 4,
        opacity: selected ? 0.98 : 0.68,
        lineCap: "round",
        lineJoin: "round",
      }).addTo(map);

      if (selected) {
        routeLineRef.current = line;
        routeCasingRef.current = casing;
        try { map.fitBounds(line.getBounds(), { padding: [80, 80] }); } catch {}
      } else {
        altLinesRef.current.push(line);
        altCasingsRef.current.push(casing);
      }
    });
  }, [routes, selectedRouteIndex, isDarkMap, ready]);

  /* ── Report markers ── */
  useEffect(() => {
    const map = mapRef.current;
    const L = leafletRef.current;
    if (!map || !L || !ready) return;

    reportMarkersRef.current.forEach(m => map.removeLayer(m));
    reportMarkersRef.current = [];
    if (!showReportsLayer) return;

    trafficReports.forEach(report => {
      const info = REPORT_TYPE_LABELS[report.type as keyof typeof REPORT_TYPE_LABELS];
      if (!info) return;
      const m = L.circleMarker([report.lat, report.lng], {
        radius: 10, fillColor: info.color, color: "white",
        weight: 2, fillOpacity: 0.88,
      }).bindPopup(`
        <div dir="rtl" style="font-family:'Tajawal',sans-serif;text-align:right;min-width:120px">
          <b style="color:${info.color}">${info.icon} ${info.ar}</b><br/>
          <small style="color:#657570">${report.confirmations} تأكيد</small>
        </div>
      `).addTo(map);
      reportMarkersRef.current.push(m);
    });
  }, [trafficReports, showReportsLayer, ready]);

  /* ── Follow user during navigation ── */
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !ready || !userLocation) return;
    if (navigation.status !== "active" && navigation.status !== "rerouting") return;
    map.setView([userLocation.lat, userLocation.lng], Math.max(map.getZoom(), 16), {
      animate: true, duration: 0.5,
    });
  }, [userLocation, navigation.status, ready]);

  /* ── Error state ── */
  if (mapError) {
    return (
      <div className={`flex flex-col items-center justify-center bg-[#F5F5EE] ${className}`}>
        <div className="text-6xl mb-4">🗺️</div>
        <p className="text-[#0B1F3A] font-black text-lg mb-2 font-arabic">{mapError}</p>
        <button onClick={() => window.location.reload()}
                className="btn btn-primary mt-2 px-8">
          إعادة المحاولة
        </button>
      </div>
    );
  }

  return (
    <div data-map-theme={isDarkMap ? "dark" : "light"} className={`relative ${className}`} style={{ width:"100%", height:"100%" }}>
      <div
        ref={mapDivRef}
        style={{ width:"100%", height:"100%", position:"absolute", top:0, left:0, right:0, bottom:0 }}
      />
      {!ready && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#F5F5EE] z-10">
          <div className="flex flex-col items-center gap-3">
            <div className="w-12 h-12 border-4 border-[#0A6AD6] border-t-transparent rounded-full animate-spin" />
            <p className="text-[#0A6AD6] font-black font-arabic text-sm">
              جاري تحميل الخريطة…
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
