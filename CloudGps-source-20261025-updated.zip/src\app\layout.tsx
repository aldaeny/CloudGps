import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "السحاب | CloudGps — دليلك في كل طريق",
  description: "السحاب CloudGps تطبيق خرائط وملاحة للعراق: ابحث عن الأماكن، خطط لرحلتك، وتابع تنبيهات الطريق.",
  keywords: ["السحاب","CloudGps","خرائط","ملاحة","العراق","بغداد","navigation","Iraq","maps","GPS","traffic"],
  authors: [{ name: "CloudGps" }],
  manifest: "/manifest.json",
  icons: {
    icon: [
      { url: "/cloudgps-icon-192.png", sizes: "192x192", type: "image/png" },
      { url: "/cloudgps-icon-512.png", sizes: "512x512", type: "image/png" },
    ],
    apple: "/cloudgps-icon-512.png",
  },
  openGraph: {
    title: "السحاب | CloudGps",
    description: "دليلك في كل طريق — خرائط وملاحة ذكية في العراق",
    siteName: "السحاب | CloudGps",
    images: [{ url: "/cloudgps-lockup.png", width: 692, height: 215, alt: "شعار السحاب CloudGps" }],
    locale: "ar_IQ",
    type: "website",
  },
  twitter: {
    card: "summary",
    title: "السحاب | CloudGps",
    description: "دليلك في كل طريق — خرائط وملاحة ذكية في العراق",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  themeColor: "#0A6AD6",
  colorScheme: "light dark",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        {/* Leaflet CSS — must load before map renders */}
        <link
          rel="stylesheet"
          href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
          crossOrigin="anonymous"
        />
        {/* Arabic font */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Tajawal:wght@200;300;400;500;700;800;900&family=Noto+Sans+Arabic:wght@400;500;600;700;800;900&family=Montserrat:wght@300;400;500;600;700;800;900&display=swap"
          rel="stylesheet"
        />
        {/* PWA meta */}
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="apple-mobile-web-app-title" content="السحاب" />
        <meta name="application-name" content="CloudGps" />
        {/* Prevent phone number detection */}
        <meta name="format-detection" content="telephone=no" />
      </head>
      <body
        style={{
          fontFamily: "'Tajawal','Noto Sans Arabic',sans-serif",
          background: "#F5F5EE",
          overscrollBehavior: "none",
        }}
      >
        {children}
      </body>
    </html>
  );
}
