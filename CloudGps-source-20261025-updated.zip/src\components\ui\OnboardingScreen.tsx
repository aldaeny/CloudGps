"use client";
import { useState } from "react";
import { WainLogo } from "./WainLogo";
import { useAppStore } from "@/store/useAppStore";
import { t } from "@/lib/translations";
import { ChevronRight, ChevronLeft } from "lucide-react";

const slides = [
  {
    titleKey: "onboarding1Title" as const,
    descKey: "onboarding1Desc" as const,
    emoji: "🗺️",
    bg: "from-[#0A6AD6] to-[#0B1F3A]",
  },
  {
    titleKey: "onboarding2Title" as const,
    descKey: "onboarding2Desc" as const,
    emoji: "🧭",
    bg: "from-[#0B1F3A] to-[#0A6AD6]",
  },
  {
    titleKey: "onboarding3Title" as const,
    descKey: "onboarding3Desc" as const,
    emoji: "🚗",
    bg: "from-[#D62828] to-[#0A6AD6]",
  },
];

export function OnboardingScreen() {
  const { language, setLanguage, setHasSeenOnboarding } = useAppStore();
  const [currentSlide, setCurrentSlide] = useState(0);
  const [showLangSelect, setShowLangSelect] = useState(true);

  const lang = language;
  const dir = lang === "ar" ? "rtl" : "ltr";

  function handleFinish() {
    setHasSeenOnboarding(true);
  }

  function handleNext() {
    if (currentSlide < slides.length - 1) {
      setCurrentSlide((s) => s + 1);
    } else {
      handleFinish();
    }
  }

  function handlePrev() {
    if (currentSlide > 0) setCurrentSlide((s) => s - 1);
  }

  if (showLangSelect) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#0A6AD6] to-[#0B1F3A] flex flex-col items-center justify-center p-8">
        {/* Logo */}
        <div className="mb-12 text-center">
          <WainLogo size={100} variant="dark" className="justify-center mb-6" />
          <p className="text-white/60 text-sm mt-2" style={{ fontFamily: "'Tajawal', sans-serif" }}>
            معاً… لرحلة أسهل
          </p>
          <p className="text-white/60 text-sm mt-1" style={{ fontFamily: "'Montserrat', sans-serif" }}>
            Together… for an easier journey
          </p>
        </div>

        {/* Language Selection */}
        <div className="w-full max-w-xs">
          <p className="text-white text-center mb-6" style={{ fontFamily: "'Tajawal', sans-serif" }}>
            اختر اللغة / Choose Language
          </p>
          <div className="space-y-3">
            <button
              onClick={() => { setLanguage("ar"); setShowLangSelect(false); }}
              className={`w-full py-4 rounded-2xl font-bold text-lg transition-all border-2 ${
                language === "ar"
                  ? "bg-[#F5F5EE] text-[#0A6AD6] border-white"
                  : "bg-transparent text-white border-white/30 hover:border-white/60"
              }`}
              style={{ fontFamily: "'Tajawal', sans-serif" }}
            >
              العربية 🇮🇶
            </button>
            <button
              onClick={() => { setLanguage("en"); setShowLangSelect(false); }}
              className={`w-full py-4 rounded-2xl font-bold text-lg transition-all border-2 ${
                language === "en"
                  ? "bg-[#F5F5EE] text-[#0A6AD6] border-white"
                  : "bg-transparent text-white border-white/30 hover:border-white/60"
              }`}
              style={{ fontFamily: "'Montserrat', sans-serif" }}
            >
              English
            </button>
          </div>
        </div>
      </div>
    );
  }

  const slide = slides[currentSlide];

  return (
    <div
      className={`min-h-screen bg-gradient-to-br ${slide?.bg ?? "from-[#0A6AD6] to-[#0B1F3A]"} flex flex-col transition-all duration-500`}
      dir={dir}
    >
      {/* Skip button */}
      <div className={`flex ${lang === "ar" ? "justify-start" : "justify-end"} p-6`}>
        <button
          onClick={handleFinish}
          className="text-white/60 text-sm"
          style={{ fontFamily: "'Tajawal', sans-serif" }}
        >
          {t("skip", lang)}
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col items-center justify-center px-8 text-center">
        <div className="text-8xl mb-8 animate-bounce">{slide?.emoji}</div>
        <h2
          className="text-3xl font-bold text-white mb-4"
          style={{ fontFamily: "'Tajawal', sans-serif" }}
        >
          {t(slide?.titleKey ?? "onboarding1Title", lang)}
        </h2>
        <p
          className="text-white/70 text-lg leading-relaxed max-w-sm"
          style={{ fontFamily: "'Tajawal', sans-serif" }}
        >
          {t(slide?.descKey ?? "onboarding1Desc", lang)}
        </p>
      </div>

      {/* Navigation dots */}
      <div className="flex justify-center gap-2 mb-6">
        {slides.map((_, i) => (
          <button
            key={i}
            onClick={() => setCurrentSlide(i)}
            className={`h-2 rounded-full transition-all ${
              i === currentSlide ? "bg-[#F5F5EE] w-8" : "bg-white/30 w-2"
            }`}
          />
        ))}
      </div>

      {/* Bottom navigation */}
      <div className={`flex items-center justify-between px-8 pb-12`}>
        <button
          onClick={handlePrev}
          className={`p-4 rounded-2xl bg-white/10 hover:bg-white/20 transition-colors ${
            currentSlide === 0 ? "opacity-0 pointer-events-none" : ""
          }`}
        >
          {lang === "ar" ? (
            <ChevronRight size={24} color="white" />
          ) : (
            <ChevronLeft size={24} color="white" />
          )}
        </button>

        {currentSlide === slides.length - 1 ? (
          <button
            onClick={handleFinish}
            className="bg-[#F5F5EE] text-[#0A6AD6] px-10 py-4 rounded-2xl font-bold text-lg hover:bg-[#F5F5EE] transition-colors shadow-xl"
            style={{ fontFamily: "'Tajawal', sans-serif" }}
          >
            {t("getStarted", lang)}
          </button>
        ) : (
          <button
            onClick={handleNext}
            className="bg-[#F5F5EE] text-[#0A6AD6] px-8 py-4 rounded-2xl font-bold hover:bg-[#F5F5EE] transition-colors shadow-xl flex items-center gap-2"
            style={{ fontFamily: "'Tajawal', sans-serif" }}
          >
            {t("next", lang)}
            {lang === "ar" ? (
              <ChevronLeft size={20} color="#0A6AD6" />
            ) : (
              <ChevronRight size={20} color="#0A6AD6" />
            )}
          </button>
        )}
      </div>
    </div>
  );
}
