"use client";
import { useEffect } from "react";
import {
  Navigation, Clock, MapPin, X, ArrowLeftRight, Car
} from "lucide-react";
import { useAppStore } from "@/store/useAppStore";
import { t } from "@/lib/translations";
import { formatDistance, formatDuration, formatETA, getSessionId } from "@/lib/utils";
import { cn } from "@/lib/utils";
import { waenToast } from "@/lib/toast";
import type { RouteProfile } from "@/types";

const ROUTE_PROFILE: RouteProfile = "car";

export function RoutePreviewPanel() {
  const {
    language, origin, destination, routes, selectedRouteIndex,
    isCalculatingRoute, routeError, userLocation,
    setActivePanel, setRoutes, setSelectedRouteIndex,
    setIsCalculatingRoute, setRouteError, setNavigation,
    addRecentDestination, setOrigin, setDestination,
  } = useAppStore();

  const lang = language;
  const dir  = lang === "ar" ? "rtl" : "ltr";
  const selectedRoute = routes[selectedRouteIndex];

  useEffect(() => {
    if (origin && destination) calculateRoute(ROUTE_PROFILE);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [origin?.location.lat, origin?.location.lng, destination?.location.lat, destination?.location.lng]);

  async function calculateRoute(profile: RouteProfile = ROUTE_PROFILE) {
    if (!origin || !destination) return;
    setIsCalculatingRoute(true);
    setRouteError(null);

    try {
      const params = new URLSearchParams({
        originLat: String(origin.location.lat),
        originLng: String(origin.location.lng),
        destLat:   String(destination.location.lat),
        destLng:   String(destination.location.lng),
        alternatives: "true",
        profile,
      });
      const res  = await fetch(`/api/routing?${params}`);
      const data = await res.json();

      if (!res.ok || data.error) {
        setRouteError(data.error ?? t("routingError", lang));
        setRoutes([]);
        return;
      }
      setRoutes(data.routes ?? []);
      setSelectedRouteIndex(0);
    } catch {
      setRouteError(t("routingError", lang));
    } finally {
      setIsCalculatingRoute(false);
    }
  }

  async function handleStartNavigation() {
    if (!selectedRoute || !destination) return;

    addRecentDestination({ name: destination.name, location: destination.location });

    // Save trip to DB
    try {
      const sid = getSessionId();
      await fetch("/api/trips", {
        method: "POST",
        headers: { "Content-Type":"application/json" },
        body: JSON.stringify({
          sessionId: sid,
          originName: origin?.name ?? t("myLocation", lang),
          originLat:  origin?.location.lat,
          originLng:  origin?.location.lng,
          destName:   destination.name,
          destLat:    destination.location.lat,
          destLng:    destination.location.lng,
          distanceKm: selectedRoute.distance / 1000,
          durationMin: selectedRoute.duration / 60,
          status: "started",
        }),
      });
    } catch { /* non-critical */ }

    setNavigation({
      status: "active",
      route: selectedRoute,
      currentStepIndex: 0,
      distanceToNextStep: selectedRoute.steps[0]?.distance ?? 0,
      distanceRemaining: selectedRoute.distance,
      timeRemaining: selectedRoute.duration,
      currentStreetName: selectedRoute.steps[0]?.name ?? "",
      isOffRoute: false,
      eta: new Date(Date.now() + selectedRoute.duration * 1000),
    });
    setActivePanel("navigation");
  }

  function handleSwap() {
    const nd = origin  ? { name: origin.name,       location: origin.location } : null;
    const no = destination ? { name: destination.name, location: destination.location } : null;
    setOrigin(no);
    setDestination(nd);
  }

  return (
    <div className="bg-[#F5F5EE] rounded-t-3xl shadow-2xl pb-2" dir={dir}>
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-[#DADFD7]">
        <h2 className="text-lg font-black text-[#0B1F3A]" style={{ fontFamily:"'Tajawal',sans-serif" }}>
          {t("routes", lang)}
        </h2>
        <button onClick={() => { setRoutes([]); setActivePanel("home"); }}
                className="p-2 rounded-full hover:bg-[#F5F5EE]">
          <X size={20} color="#657570" />
        </button>
      </div>

      {/* Origin → Destination */}
      <div className="px-5 py-3 bg-[#F5F5EE] mx-4 mt-3 rounded-2xl">
        <div className="flex items-center gap-2 mb-2" dir={dir}>
          <div className="w-3 h-3 rounded-full bg-[#0A6AD6] flex-shrink-0" />
          <p className="text-sm text-[#0B1F3A] flex-1 truncate"
             style={{ fontFamily:"'Tajawal',sans-serif" }}>
            {origin?.name ?? t("myLocation", lang)}
          </p>
        </div>
        <div className="flex items-center gap-2" dir={dir}>
          <MapPin size={13} color="#D62828" className="flex-shrink-0" />
          <p className="text-sm font-bold text-[#0B1F3A] flex-1 truncate"
             style={{ fontFamily:"'Tajawal',sans-serif" }}>
            {destination?.name ?? t("destination", lang)}
          </p>
          <button onClick={handleSwap} className="p-1.5 hover:bg-[#DADFD7] rounded-lg transition-colors">
            <ArrowLeftRight size={13} color="#657570" />
          </button>
        </div>
      </div>

      {/* Profile selector */}
      <div className="px-5 pt-3">
        <div className="inline-flex items-center gap-2 px-3 py-2 rounded-xl border border-[#DADFD7] bg-[#F5F5EE] text-xs font-bold text-[#0A6AD6]">
          <Car size={16} />
          {lang === "ar" ? "بالسيارة" : "Driving"}
        </div>
      </div>

      {/* Loading */}
      {isCalculatingRoute && (
        <div className="flex flex-col items-center py-8 gap-3">
          <div className="w-10 h-10 border-4 border-[#0A6AD6] border-t-transparent rounded-full animate-spin" />
          <p className="text-[#657570] text-sm" style={{ fontFamily:"'Tajawal',sans-serif" }}>
            {t("recalculating", lang)}
          </p>
        </div>
      )}

      {/* Error */}
      {routeError && !isCalculatingRoute && (
        <div className="bg-red-50 border border-red-200 rounded-2xl mx-5 mt-3 p-4">
          <p className="text-red-600 text-sm mb-2" style={{ fontFamily:"'Tajawal',sans-serif" }}>
            {routeError}
          </p>
          <button onClick={() => calculateRoute("car")}
                  className="text-[#0A6AD6] text-sm font-bold underline"
                  style={{ fontFamily:"'Tajawal',sans-serif" }}>
            {t("tryAgain", lang)}
          </button>
        </div>
      )}

      {/* Routes */}
      {!isCalculatingRoute && routes.length > 0 && (
        <div className="px-5 pt-3 space-y-2 max-h-52 overflow-y-auto scrollbar-thin">
          {routes.map((route, idx) => (
            <button key={route.id}
                    onClick={() => setSelectedRouteIndex(idx)}
                    className={cn(
                      "w-full flex items-center gap-4 p-4 rounded-2xl border-2 transition-all",
                      idx === selectedRouteIndex
                        ? "border-[#0A6AD6] bg-[#0A6AD6]/5"
                        : "border-[#DADFD7] hover:border-[#657570]"
                    )}
                    dir={dir}>
              <div className={cn("w-4 h-4 rounded-full border-2 flex-shrink-0",
                idx===selectedRouteIndex?"border-[#0A6AD6] bg-[#0A6AD6]":"border-[#DADFD7]")} />
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1 flex-wrap">
                  {idx === 0 && (
                    <span className="badge badge-green text-[10px]">{t("fastest", lang)}</span>
                  )}
                  {idx > 0 && (
                    <span className="badge badge-gray text-[10px]">
                      {t("alternativeRoutes", lang)} {idx}
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-4">
                  <span className="flex items-center gap-1 text-sm font-black text-[#0B1F3A]"
                        style={{ fontFamily:"'Tajawal',sans-serif" }}>
                    <Clock size={13} color="#657570" />
                    {formatDuration(route.duration, lang)}
                  </span>
                  <span className="flex items-center gap-1 text-sm text-[#657570]"
                        style={{ fontFamily:"'Tajawal',sans-serif" }}>
                    <MapPin size={13} color="#657570" />
                    {formatDistance(route.distance, lang)}
                  </span>
                  {idx === selectedRouteIndex && (
                    <span className="text-xs text-[#657570]"
                          style={{ fontFamily:"'Tajawal',sans-serif" }}>
                      ETA: {formatETA(route.duration)}
                    </span>
                  )}
                </div>
              </div>
            </button>
          ))}
        </div>
      )}

      {/* Start button */}
      {selectedRoute && (
        <div className="px-5 pt-3 pb-5">
          <button onClick={handleStartNavigation}
                  className="btn btn-primary w-full text-lg">
            <Navigation size={22} />
            {t("startNavigation", lang)}
          </button>
        </div>
      )}
    </div>
  );
}
