"use client";
import { X, Shield, FileText, Mail, Bug, ExternalLink } from "lucide-react";
import { useAppStore } from "@/store/useAppStore";
import { t } from "@/lib/translations";
import { WainLogo } from "./WainLogo";

export function AboutPanel() {
  const { language, setActivePanel } = useAppStore();
  const lang = language;
  const dir = lang === "ar" ? "rtl" : "ltr";

  return (
    <div className="bg-[#F5F5EE] rounded-t-3xl shadow-2xl pb-10 max-h-[85vh] overflow-y-auto" dir={dir}>
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-[#DADFD7]">
        <h2 className="text-lg font-bold text-[#0B1F3A]" style={{ fontFamily: "'Tajawal', sans-serif" }}>
          {t("aboutApp", lang)}
        </h2>
        <button onClick={() => setActivePanel("settings")} className="p-2 rounded-full hover:bg-[#F5F5EE]">
          <X size={20} color="#657570" />
        </button>
      </div>

      {/* Logo & App Info */}
      <div className="flex flex-col items-center py-8 px-5 bg-gradient-to-b from-[#0A6AD6] to-[#074BA4]">
        <WainLogo size={80} variant="dark" showText className="mb-4" />
        <p className="text-white/80 text-sm text-center" style={{ fontFamily: "'Tajawal', sans-serif" }}>
          {t("appSlogan", lang)}
        </p>
        <div className="mt-3 bg-white/10 rounded-xl px-4 py-2">
          <p className="text-white text-xs font-bold" style={{ fontFamily: "'Montserrat', sans-serif" }}>
            Version 1.0.0
          </p>
        </div>
      </div>

      {/* Description */}
      <div className="px-5 py-4 border-b border-[#DADFD7]">
        <p className="text-sm text-[#0B1F3A] leading-relaxed" style={{ fontFamily: "'Tajawal', sans-serif" }}>
          {lang === "ar"
            ? "السحاب CloudGps هو تطبيق خرائط وملاحة جغرافية ذكي مخصص للعراق. يوفر خرائط تفاعلية، وبحثاً عن الأماكن، وتوجيهاً صوتياً عربياً، وتنبيهات مرورية مجتمعية."
            : "CloudGps is a maps and navigation app designed for Iraq, with interactive maps, place search, Arabic voice guidance, and community traffic alerts."}
        </p>
      </div>

      {/* Links */}
      <div className="px-5 py-2">
        <LinkRow
          icon={<Shield size={18} color="#0A6AD6" />}
          label={t("privacyPolicy", lang)}
          lang={lang}
        />
        <LinkRow
          icon={<FileText size={18} color="#0A6AD6" />}
          label={t("termsOfService", lang)}
          lang={lang}
        />
        <LinkRow
          icon={<Mail size={18} color="#0A6AD6" />}
          label={t("contactUs", lang)}
          lang={lang}
        />
        <LinkRow
          icon={<Bug size={18} color="#0A6AD6" />}
          label={t("reportBug", lang)}
          lang={lang}
        />
      </div>

      {/* Attribution */}
      <div className="px-5 py-4 bg-[#F5F5EE] mx-4 rounded-2xl mt-4">
        <p className="text-xs font-bold text-[#0B1F3A] mb-2" style={{ fontFamily: "'Tajawal', sans-serif" }}>
          {lang === "ar" ? "مصادر البيانات" : "Data Sources"}
        </p>
        <p className="text-xs text-[#657570]" style={{ fontFamily: "'Tajawal', sans-serif" }}>
          • {lang === "ar" ? "بيانات الخرائط: OpenStreetMap" : "Map data: OpenStreetMap"} ©{" "}
          <a href="https://www.openstreetmap.org/copyright" className="text-[#0A6AD6] underline">
            OpenStreetMap contributors
          </a>
        </p>
        <p className="text-xs text-[#657570] mt-1" style={{ fontFamily: "'Tajawal', sans-serif" }}>
          • {lang === "ar" ? "التوجيه: OSRM (Open Source Routing Machine)" : "Routing: OSRM (Open Source Routing Machine)"}
        </p>
        <p className="text-xs text-[#657570] mt-1" style={{ fontFamily: "'Tajawal', sans-serif" }}>
          • {lang === "ar" ? "البلاط: OpenStreetMap / CartoDB" : "Tiles: OpenStreetMap / CartoDB"}
        </p>
      </div>

      <div className="text-center py-6">
        <p className="text-lg" style={{ fontFamily: "'Tajawal', sans-serif" }}>
          {t("madeInIraq", lang)}
        </p>
        <p className="text-xs text-[#657570] mt-1" style={{ fontFamily: "'Tajawal', sans-serif" }}>
          {lang === "ar" ? "معاً… لرحلة أسهل" : "Together… for an easier journey"}
        </p>
      </div>
    </div>
  );
}

function LinkRow({ icon, label, lang }: { icon: React.ReactNode; label: string; lang: "ar" | "en" }) {
  return (
    <button
      className="flex items-center gap-3 w-full px-2 py-3 hover:bg-[#F5F5EE] rounded-xl transition-colors"
      dir={lang === "ar" ? "rtl" : "ltr"}
    >
      {icon}
      <span className="flex-1 text-sm text-[#0B1F3A] text-right" style={{ fontFamily: "'Tajawal', sans-serif" }}>
        {label}
      </span>
      <ExternalLink size={14} color="#657570" />
    </button>
  );
}
