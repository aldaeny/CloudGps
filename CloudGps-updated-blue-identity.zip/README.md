# Waen | وُيـن
## نظام عراقي متكامل للخرائط والملاحة الذكية

> **معاً… لرحلة أسهل** — Together… for an easier journey

---

## نظرة عامة

**وُيـن** هو تطبيق خرائط وملاحة جغرافية ذكي مخصص للعراق. يوفر:

- 🗺️ خرائط تفاعلية حقيقية تغطي جميع المحافظات العراقية
- 🧭 ملاحة ذكية مع تعليمات صوتية عربية
- 🚗 بلاغات مرورية مجتمعية في الوقت الفعلي
- 📍 تحديد موقع GPS دقيق
- 🌙 وضع ليلي ونهاري
- 📡 دعم جزئي للاستخدام دون إنترنت

---

## المتطلبات

- Node.js 18+
- PostgreSQL 14+ (مع امتداد PostGIS للإنتاج)
- npm 8+

---

## بدء التشغيل

```bash
# 1. نسخ متغيرات البيئة
cp .env.example .env

# 2. تعديل قيم .env حسب إعدادك

# 3. تثبيت الاعتماديات
npm install

# 4. تطبيق مخطط قاعدة البيانات
npx drizzle-kit push

# 5. تشغيل بيئة التطوير
npm run dev

# 6. فتح المتصفح على http://localhost:3000
```

---

## بنية المشروع

```
src/
├── app/
│   ├── api/
│   │   ├── health/          # فحص صحة الخادم
│   │   ├── places/          # البحث والترميز الجغرافي العكسي
│   │   ├── routing/         # حساب المسارات (OSRM)
│   │   ├── reports/         # البلاغات المرورية
│   │   ├── saved-places/    # الأماكن المحفوظة
│   │   └── trips/           # سجل الرحلات
│   ├── layout.tsx
│   ├── page.tsx
│   └── globals.css
├── components/
│   ├── map/                 # مكونات الخريطة
│   ├── navigation/          # مكونات الملاحة
│   ├── reports/             # مكونات البلاغات
│   ├── search/              # مكونات البحث
│   └── ui/                  # مكونات واجهة المستخدم
├── db/
│   ├── index.ts             # اتصال قاعدة البيانات
│   └── schema.ts            # مخطط Drizzle ORM
├── lib/
│   ├── translations.ts      # نظام الترجمة (عربي/إنجليزي)
│   └── utils.ts             # أدوات مساعدة
├── store/
│   └── useAppStore.ts       # إدارة الحالة (Zustand)
└── types/
    └── index.ts             # تعريفات TypeScript
```

---

## الخدمات الخارجية المستخدمة

| الخدمة | الوظيفة | الحالة | الحدود |
|--------|---------|--------|---------|
| OpenStreetMap | بيانات الخرائط | مجاني | يجب الالتزام بسياسة الاستخدام |
| Nominatim (OSM) | Geocoding | مجاني | حد 1 طلب/ثانية للإنتاج |
| OSRM Demo | التوجيه | مجاني للتطوير | **غير مناسب للإنتاج** |
| CartoDB Tiles | بلاط الخريطة (ليلي) | مجاني | 75k طلب/شهر |

### للإنتاج يجب:
1. **OSRM**: نشر نسخة خاصة مع بيانات العراق من OpenStreetMap
2. **Nominatim**: استخدام Nominatim خاص أو خدمة مدفوعة (Geocodio, LocationIQ)
3. **بلاط الخرائط**: MapTiler / Mapbox / TomTom (مدفوع)
4. **Redis**: للتخزين المؤقت وحدود الطلبات

---

## API Endpoints

| الطريقة | المسار | الوصف |
|---------|---------|--------|
| GET | /api/health | فحص صحة الخادم |
| GET | /api/places/search?q= | البحث عن الأماكن |
| GET | /api/places/reverse?lat=&lng= | الترميز الجغرافي العكسي |
| GET | /api/routing?originLat=...&destLat= | حساب المسار |
| GET | /api/reports?lat=&lng= | البلاغات القريبة |
| POST | /api/reports | إنشاء بلاغ |
| POST | /api/reports/:id/confirm | تأكيد/رفض/حل بلاغ |
| GET/POST | /api/saved-places | الأماكن المحفوظة |
| DELETE | /api/saved-places/:id | حذف مكان محفوظ |
| GET/POST/DELETE | /api/trips | سجل الرحلات |

---

## المعمارية التقنية

- **Frontend**: Next.js 16 (App Router) + React 19
- **State Management**: Zustand (مع persistent storage)
- **Database ORM**: Drizzle ORM
- **Database**: PostgreSQL
- **Maps**: Leaflet.js + OpenStreetMap
- **Routing**: OSRM (Open Source Routing Machine)
- **Geocoding**: Nominatim (OpenStreetMap)
- **Styling**: Tailwind CSS v4
- **Language**: TypeScript

---

## الخصوصية والأمان

- لا يتم تخزين تاريخ المسار بشكل تفصيلي دون حاجة
- البلاغات مجهولة (بدون اسم المستخدم)
- حدود معدل الطلبات للبلاغات (10 بلاغات/ساعة/جلسة)
- التحقق من الإحداثيات (يجب أن تكون داخل العراق)
- اكتشاف البلاغات المكررة
- HTTPS إلزامي في الإنتاج

---

## الخطوات التالية للإنتاج

1. **OSRM محلي**: تحميل بيانات العراق وإعداد محرك توجيه خاص
2. **مزود خرائط مدفوع**: للاستخدام التجاري (MapTiler/Mapbox)
3. **Redis**: للتخزين المؤقت وتحسين الأداء
4. **نظام مصادقة**: (اختياري) لمزامنة البيانات بين الأجهزة
5. **PostGIS**: تفعيل الاستعلامات الجغرافية المتقدمة
6. **إشعارات**: WebSocket للتحديثات الحية
7. **تطبيق موبايل**: React Native أو Capacitor للنشر على iOS/Android

---

## الترخيص

جميع بيانات الخرائط محكومة بشروط ترخيص OpenStreetMap (ODbL).
يجب الإشارة إلى المصدر في كل مكان تُستخدم فيه البيانات.

---

*وُيـن — صُنع في العراق 🇮🇶*
