"use client";
import { create } from "zustand";
import { persist } from "zustand/middleware";
import type {
  Language,
  Theme,
  LatLng,
  Place,
  Route,
  NavigationState,
  TrafficReport,
  SavedPlace,
} from "@/types";

interface AppStore {
  // Language & Theme
  language: Language;
  theme: Theme;
  setLanguage: (lang: Language) => void;
  setTheme: (theme: Theme) => void;

  // Onboarding
  hasSeenOnboarding: boolean;
  setHasSeenOnboarding: (val: boolean) => void;

  // Online status
  isOnline: boolean;
  setIsOnline: (val: boolean) => void;

  // Active screen/panel
  activePanel: "home" | "search" | "place" | "route-preview" | "navigation" | "reports" | "saved" | "settings" | "offline" | "profile" | "about" | "create-report" | "privacy" | "help" | "trip-history";
  setActivePanel: (panel: AppStore["activePanel"]) => void;

  // Location
  userLocation: LatLng | null;
  locationStatus: "idle" | "loading" | "success" | "error" | "denied";
  locationAccuracy: number | null;
  setUserLocation: (loc: LatLng | null, accuracy?: number) => void;
  setLocationStatus: (status: AppStore["locationStatus"]) => void;

  // Map state
  mapCenter: LatLng;
  mapZoom: number;
  isDarkMap: boolean;
  showTrafficLayer: boolean;
  showReportsLayer: boolean;
  setMapCenter: (center: LatLng) => void;
  setMapZoom: (zoom: number) => void;
  setIsDarkMap: (val: boolean) => void;
  setShowTrafficLayer: (val: boolean) => void;
  setShowReportsLayer: (val: boolean) => void;

  // Search
  searchQuery: string;
  searchResults: Place[];
  isSearching: boolean;
  setSearchQuery: (q: string) => void;
  setSearchResults: (results: Place[]) => void;
  setIsSearching: (val: boolean) => void;

  // Selected place
  selectedPlace: Place | null;
  setSelectedPlace: (place: Place | null) => void;

  // Origin / Destination
  origin: { name: string; location: LatLng } | null;
  destination: { name: string; location: LatLng } | null;
  setOrigin: (origin: AppStore["origin"]) => void;
  setDestination: (dest: AppStore["destination"]) => void;

  // Routes
  routes: Route[];
  selectedRouteIndex: number;
  isCalculatingRoute: boolean;
  routeError: string | null;
  setRoutes: (routes: Route[]) => void;
  setSelectedRouteIndex: (i: number) => void;
  setIsCalculatingRoute: (val: boolean) => void;
  setRouteError: (err: string | null) => void;

  // Navigation
  navigation: NavigationState;
  setNavigation: (nav: Partial<NavigationState>) => void;
  resetNavigation: () => void;

  // Traffic reports
  trafficReports: TrafficReport[];
  setTrafficReports: (reports: TrafficReport[]) => void;
  addTrafficReport: (report: TrafficReport) => void;

  // Saved places
  savedPlaces: SavedPlace[];
  setSavedPlaces: (places: SavedPlace[]) => void;
  addSavedPlace: (place: SavedPlace) => void;
  removeSavedPlace: (id: number) => void;

  // Recent destinations
  recentDestinations: Array<{ name: string; location: LatLng; visitedAt: string }>;
  addRecentDestination: (dest: { name: string; location: LatLng }) => void;
  clearRecentDestinations: () => void;

  // Voice
  voiceMuted: boolean;
  setVoiceMuted: (val: boolean) => void;

  // Report creation
  pendingReportLocation: LatLng | null;
  setPendingReportLocation: (loc: LatLng | null) => void;
}

const defaultNavigation: NavigationState = {
  status: "idle",
  route: null,
  currentStepIndex: 0,
  distanceToNextStep: 0,
  distanceRemaining: 0,
  timeRemaining: 0,
  currentStreetName: "",
  isOffRoute: false,
  voiceMuted: false,
  eta: null,
};

export const useAppStore = create<AppStore>()(
  persist(
    (set, get) => ({
      // Language & Theme
      language: "ar",
      theme: "light",
      setLanguage: (lang) => set({ language: lang }),
      setTheme: (theme) => set({ theme }),

      // Onboarding
      hasSeenOnboarding: false,
      setHasSeenOnboarding: (val) => set({ hasSeenOnboarding: val }),

      // Online
      isOnline: true,
      setIsOnline: (val) => set({ isOnline: val }),

      // Active panel
      activePanel: "home",
      setActivePanel: (panel) => set({ activePanel: panel }),

      // Location
      userLocation: null,
      locationStatus: "idle",
      locationAccuracy: null,
      setUserLocation: (loc, accuracy) =>
        set({ userLocation: loc, locationStatus: loc ? "success" : "error", locationAccuracy: accuracy ?? null }),
      setLocationStatus: (status) => set({ locationStatus: status }),

      // Map state
      mapCenter: { lat: 33.3152, lng: 44.3661 }, // Baghdad
      mapZoom: 12,
      isDarkMap: false,
      showTrafficLayer: true,
      showReportsLayer: true,
      setMapCenter: (center) => set({ mapCenter: center }),
      setMapZoom: (zoom) => set({ mapZoom: zoom }),
      setIsDarkMap: (val) => set({ isDarkMap: val }),
      setShowTrafficLayer: (val) => set({ showTrafficLayer: val }),
      setShowReportsLayer: (val) => set({ showReportsLayer: val }),

      // Search
      searchQuery: "",
      searchResults: [],
      isSearching: false,
      setSearchQuery: (q) => set({ searchQuery: q }),
      setSearchResults: (results) => set({ searchResults: results }),
      setIsSearching: (val) => set({ isSearching: val }),

      // Selected place
      selectedPlace: null,
      setSelectedPlace: (place) => set({ selectedPlace: place }),

      // Origin / Destination
      origin: null,
      destination: null,
      setOrigin: (origin) => set({ origin }),
      setDestination: (dest) => set({ destination: dest }),

      // Routes
      routes: [],
      selectedRouteIndex: 0,
      isCalculatingRoute: false,
      routeError: null,
      setRoutes: (routes) => set({ routes }),
      setSelectedRouteIndex: (i) => set({ selectedRouteIndex: i }),
      setIsCalculatingRoute: (val) => set({ isCalculatingRoute: val }),
      setRouteError: (err) => set({ routeError: err }),

      // Navigation
      navigation: defaultNavigation,
      setNavigation: (nav) =>
        set((state) => ({ navigation: { ...state.navigation, ...nav } })),
      resetNavigation: () => set({ navigation: defaultNavigation }),

      // Traffic reports
      trafficReports: [],
      setTrafficReports: (reports) => set({ trafficReports: reports }),
      addTrafficReport: (report) =>
        set((state) => ({ trafficReports: [report, ...state.trafficReports] })),

      // Saved places
      savedPlaces: [],
      setSavedPlaces: (places) => set({ savedPlaces: places }),
      addSavedPlace: (place) =>
        set((state) => ({ savedPlaces: [...state.savedPlaces, place] })),
      removeSavedPlace: (id) =>
        set((state) => ({ savedPlaces: state.savedPlaces.filter((p) => p.id !== id) })),

      // Recent destinations
      recentDestinations: [],
      addRecentDestination: (dest) => {
        const existing = get().recentDestinations;
        const filtered = existing.filter(
          (d) => !(d.location.lat === dest.location.lat && d.location.lng === dest.location.lng)
        );
        set({
          recentDestinations: [
            { ...dest, visitedAt: new Date().toISOString() },
            ...filtered,
          ].slice(0, 10),
        });
      },
      clearRecentDestinations: () => set({ recentDestinations: [] }),

      // Voice
      voiceMuted: false,
      setVoiceMuted: (val) => set({ voiceMuted: val }),

      // Report creation
      pendingReportLocation: null,
      setPendingReportLocation: (loc) => set({ pendingReportLocation: loc }),
    }),
    {
      name: "waen-app-store",
      partialize: (state) => ({
        language: state.language,
        theme: state.theme,
        hasSeenOnboarding: state.hasSeenOnboarding,
        savedPlaces: state.savedPlaces,
        recentDestinations: state.recentDestinations,
        trafficReports: state.trafficReports.filter((report) => report.source === "local").slice(0, 100),
        voiceMuted: state.voiceMuted,
        mapCenter: state.mapCenter,
        mapZoom: state.mapZoom,
        isDarkMap: state.isDarkMap,
      }),
    }
  )
);
