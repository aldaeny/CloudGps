import {
  pgTable,
  serial,
  text,
  varchar,
  real,
  boolean,
  timestamp,
  integer,
  jsonb,
  index,
} from "drizzle-orm/pg-core";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  displayName: varchar("display_name", { length: 100 }),
  email: varchar("email", { length: 255 }).unique(),
  passwordHash: text("password_hash"),
  preferredLanguage: varchar("preferred_language", { length: 10 }).default("ar"),
  theme: varchar("theme", { length: 20 }).default("light"),
  privacyPreferences: jsonb("privacy_preferences").default({}),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Saved places table
export const savedPlaces = pgTable(
  "saved_places",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }),
    name: varchar("name", { length: 200 }).notNull(),
    nameAr: varchar("name_ar", { length: 200 }),
    address: text("address"),
    latitude: real("latitude").notNull(),
    longitude: real("longitude").notNull(),
    category: varchar("category", { length: 50 }).default("custom"),
    icon: varchar("icon", { length: 50 }),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => [index("saved_places_user_idx").on(table.userId)]
);

// Recent destinations table
export const recentDestinations = pgTable(
  "recent_destinations",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }),
    sessionId: varchar("session_id", { length: 100 }),
    originName: text("origin_name"),
    originLat: real("origin_lat"),
    originLng: real("origin_lng"),
    destName: text("dest_name").notNull(),
    destLat: real("dest_lat").notNull(),
    destLng: real("dest_lng").notNull(),
    visitedAt: timestamp("visited_at").defaultNow().notNull(),
  },
  (table) => [index("recent_dest_user_idx").on(table.userId)]
);

// Trips table
export const trips = pgTable(
  "trips",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
    sessionId: varchar("session_id", { length: 100 }),
    originName: text("origin_name"),
    originLat: real("origin_lat"),
    originLng: real("origin_lng"),
    destName: text("dest_name"),
    destLat: real("dest_lat"),
    destLng: real("dest_lng"),
    distanceKm: real("distance_km"),
    durationMin: real("duration_min"),
    startedAt: timestamp("started_at").defaultNow().notNull(),
    completedAt: timestamp("completed_at"),
    status: varchar("status", { length: 20 }).default("started"),
  },
  (table) => [index("trips_user_idx").on(table.userId)]
);

// Traffic reports table
export const trafficReports = pgTable(
  "traffic_reports",
  {
    id: serial("id").primaryKey(),
    type: varchar("type", { length: 50 }).notNull(),
    latitude: real("latitude").notNull(),
    longitude: real("longitude").notNull(),
    description: text("description"),
    descriptionAr: text("description_ar"),
    source: varchar("source", { length: 50 }).default("community"),
    status: varchar("status", { length: 30 }).default("active"),
    confidence: real("confidence").default(0.5),
    confirmations: integer("confirmations").default(0),
    denials: integer("denials").default(0),
    reporterSession: varchar("reporter_session", { length: 100 }),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
    expiresAt: timestamp("expires_at"),
    reviewStatus: varchar("review_status", { length: 30 }).default("pending"),
  },
  (table) => [
    index("traffic_reports_location_idx").on(table.latitude, table.longitude),
    index("traffic_reports_status_idx").on(table.status),
  ]
);

// Report confirmations
export const reportConfirmations = pgTable("report_confirmations", {
  id: serial("id").primaryKey(),
  reportId: integer("report_id")
    .references(() => trafficReports.id, { onDelete: "cascade" })
    .notNull(),
  confirmationType: varchar("confirmation_type", { length: 20 }).notNull(),
  sessionId: varchar("session_id", { length: 100 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Places / POI table
export const places = pgTable(
  "places",
  {
    id: serial("id").primaryKey(),
    name: text("name").notNull(),
    nameAr: text("name_ar"),
    alternateNames: jsonb("alternate_names").default([]),
    category: varchar("category", { length: 100 }),
    subcategory: varchar("subcategory", { length: 100 }),
    latitude: real("latitude").notNull(),
    longitude: real("longitude").notNull(),
    address: text("address"),
    addressAr: text("address_ar"),
    city: varchar("city", { length: 100 }),
    governorate: varchar("governorate", { length: 100 }),
    source: varchar("source", { length: 50 }).default("osm"),
    osmId: varchar("osm_id", { length: 50 }),
    phone: varchar("phone", { length: 30 }),
    website: text("website"),
    openingHours: text("opening_hours"),
    verified: boolean("verified").default(false),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => [
    index("places_location_idx").on(table.latitude, table.longitude),
    index("places_category_idx").on(table.category),
    index("places_city_idx").on(table.city),
  ]
);

// Offline map regions
export const offlineMapRegions = pgTable("offline_map_regions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }),
  sessionId: varchar("session_id", { length: 100 }),
  regionName: varchar("region_name", { length: 100 }).notNull(),
  minLat: real("min_lat").notNull(),
  minLng: real("min_lng").notNull(),
  maxLat: real("max_lat").notNull(),
  maxLng: real("max_lng").notNull(),
  minZoom: integer("min_zoom").default(8),
  maxZoom: integer("max_zoom").default(16),
  sizeMb: real("size_mb"),
  status: varchar("status", { length: 20 }).default("pending"),
  metadata: jsonb("metadata").default({}),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Notification preferences
export const notificationPreferences = pgTable("notification_preferences", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .references(() => users.id, { onDelete: "cascade" })
    .unique(),
  trafficAlerts: boolean("traffic_alerts").default(true),
  communityReports: boolean("community_reports").default(true),
  soundEnabled: boolean("sound_enabled").default(true),
  language: varchar("language", { length: 10 }).default("ar"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});
