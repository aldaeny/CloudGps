import { CloudGpsLandingPage } from "@/components/ui/CloudGpsLandingPage";

export default function HomePage() {
  return <CloudGpsLandingPage />;
}
