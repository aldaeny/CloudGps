import { NextRequest, NextResponse } from "next/server";

const NOMINATIM_BASE = "https://nominatim.openstreetmap.org";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const lat = searchParams.get("lat");
  const lng = searchParams.get("lng");

  if (!lat || !lng) {
    return NextResponse.json({ error: "lat and lng required" }, { status: 400 });
  }

  const latNum = parseFloat(lat);
  const lngNum = parseFloat(lng);

  // Basic coordinate validation for Iraq region
  if (latNum < 29 || latNum > 38 || lngNum < 38 || lngNum > 49) {
    // Still allow — user might be outside Iraq
  }

  try {
    const params = new URLSearchParams({
      lat,
      lon: lng,
      format: "json",
      addressdetails: "1",
      namedetails: "1",
      "accept-language": "ar,en",
    });

    const response = await fetch(
      `${NOMINATIM_BASE}/reverse?${params.toString()}`,
      {
        headers: {
          "User-Agent": "CloudGpsApp/1.0 (aldaeny60@gmail.com)",
        },
        next: { revalidate: 30 },
      }
    );

    if (!response.ok) {
      throw new Error(`Nominatim reverse error: ${response.status}`);
    }

    const data = (await response.json()) as Record<string, unknown>;

    if (data.error) {
      return NextResponse.json({ name: "موقع محدد", nameEn: "Selected Location", address: "" });
    }

    const address = data.address as Record<string, string> | undefined;
    const namedetails = data.namedetails as Record<string, string> | undefined;

    return NextResponse.json({
      name:
        namedetails?.["name:ar"] ??
        namedetails?.name ??
        (data.display_name as string)?.split(",")[0] ??
        "موقع محدد",
      nameEn:
        namedetails?.["name:en"] ??
        namedetails?.name ??
        (data.display_name as string)?.split(",")[0] ??
        "Selected Location",
      address: data.display_name ?? "",
      city: address?.city ?? address?.town ?? address?.village ?? "",
      governorate: address?.state ?? "",
      road: address?.road ?? "",
      neighbourhood: address?.neighbourhood ?? address?.suburb ?? "",
    });
  } catch (error) {
    console.error("Reverse geocoding error:", error);
    return NextResponse.json({ name: "موقع محدد", nameEn: "Selected Location", address: "" });
  }
}
