import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { places } from "@/db/schema";

// Seed essential Iraqi places for offline search
const SEED_PLACES = [
  // Baghdad
  { name:"Baghdad International Airport", nameAr:"مطار بغداد الدولي", category:"airport", lat:33.2625, lng:44.2346, city:"Baghdad", governorate:"بغداد" },
  { name:"University of Baghdad", nameAr:"جامعة بغداد", category:"university", lat:33.2764, lng:44.3906, city:"Baghdad", governorate:"بغداد" },
  { name:"Al-Kindi Teaching Hospital", nameAr:"مستشفى الكندي التعليمي", category:"hospital", lat:33.3603, lng:44.4003, city:"Baghdad", governorate:"بغداد" },
  { name:"Baghdad Medical City", nameAr:"مدينة الطب بغداد", category:"hospital", lat:33.3481, lng:44.3972, city:"Baghdad", governorate:"بغداد" },
  { name:"Al-Zawraa Park", nameAr:"حديقة الزوراء", category:"park", lat:33.3233, lng:44.3764, city:"Baghdad", governorate:"بغداد" },
  { name:"Al-Mutanabi Street", nameAr:"شارع المتنبي", category:"landmark", lat:33.3382, lng:44.3879, city:"Baghdad", governorate:"بغداد" },
  { name:"Baghdad Tower", nameAr:"برج بغداد", category:"landmark", lat:33.3142, lng:44.3669, city:"Baghdad", governorate:"بغداد" },
  { name:"Al-Rasheed Street", nameAr:"شارع الرشيد", category:"landmark", lat:33.3392, lng:44.3917, city:"Baghdad", governorate:"بغداد" },
  { name:"Karrada District", nameAr:"منطقة الكرادة", category:"district", lat:33.3014, lng:44.3972, city:"Baghdad", governorate:"بغداد" },
  { name:"Kadhimiya Shrine", nameAr:"مرقد الكاظمية", category:"religious", lat:33.3819, lng:44.3367, city:"Baghdad", governorate:"بغداد" },
  { name:"Sadr City", nameAr:"مدينة الصدر", category:"district", lat:33.3692, lng:44.4289, city:"Baghdad", governorate:"بغداد" },
  { name:"Al-Mansour District", nameAr:"منطقة المنصور", category:"district", lat:33.3214, lng:44.3519, city:"Baghdad", governorate:"بغداد" },
  { name:"Tahrir Square Baghdad", nameAr:"ساحة التحرير بغداد", category:"landmark", lat:33.3361, lng:44.3972, city:"Baghdad", governorate:"بغداد" },
  { name:"Green Zone", nameAr:"المنطقة الخضراء", category:"district", lat:33.3097, lng:44.3811, city:"Baghdad", governorate:"بغداد" },
  // Basra
  { name:"Basra International Airport", nameAr:"مطار البصرة الدولي", category:"airport", lat:30.5497, lng:47.6622, city:"Basra", governorate:"البصرة" },
  { name:"Shatt al-Arab", nameAr:"شط العرب", category:"landmark", lat:30.5208, lng:47.8175, city:"Basra", governorate:"البصرة" },
  { name:"University of Basra", nameAr:"جامعة البصرة", category:"university", lat:30.4878, lng:47.7839, city:"Basra", governorate:"البصرة" },
  // Mosul
  { name:"Mosul Old City", nameAr:"الموصل القديمة", category:"landmark", lat:36.3406, lng:43.1217, city:"Mosul", governorate:"نينوى" },
  { name:"Mosul University", nameAr:"جامعة الموصل", category:"university", lat:36.3756, lng:43.1581, city:"Mosul", governorate:"نينوى" },
  // Najaf
  { name:"Imam Ali Shrine", nameAr:"مرقد الإمام علي", category:"religious", lat:31.9966, lng:44.3152, city:"Najaf", governorate:"النجف" },
  { name:"Wadi Al-Salam Cemetery", nameAr:"مقبرة وادي السلام", category:"landmark", lat:32.0017, lng:44.3117, city:"Najaf", governorate:"النجف" },
  // Karbala
  { name:"Imam Hussein Shrine", nameAr:"مرقد الإمام الحسين", category:"religious", lat:32.6161, lng:44.0264, city:"Karbala", governorate:"كربلاء" },
  { name:"Abbas Shrine", nameAr:"مرقد العباس", category:"religious", lat:32.6150, lng:44.0256, city:"Karbala", governorate:"كربلاء" },
  // Erbil
  { name:"Erbil Citadel", nameAr:"قلعة أربيل", category:"landmark", lat:36.1911, lng:44.0091, city:"Erbil", governorate:"أربيل" },
  { name:"Erbil International Airport", nameAr:"مطار أربيل الدولي", category:"airport", lat:36.2375, lng:43.9631, city:"Erbil", governorate:"أربيل" },
];

export async function POST(req: NextRequest) {
  // Simple auth check — only enforce in production with ADMIN_KEY set
  const auth = req.headers.get("x-admin-key");
  if (process.env.NODE_ENV === "production" && process.env.ADMIN_KEY && auth !== process.env.ADMIN_KEY) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    let inserted = 0;
    for (const p of SEED_PLACES) {
      await db.insert(places).values({
        name: p.name,
        nameAr: p.nameAr,
        category: p.category,
        latitude: p.lat,
        longitude: p.lng,
        city: p.city,
        governorate: p.governorate,
        source: "curated",
        verified: true,
      }).onConflictDoNothing();
      inserted++;
    }
    return NextResponse.json({ success: true, inserted, total: SEED_PLACES.length });
  } catch (error) {
    console.error("Seed error:", error);
    return NextResponse.json({ error: "Seed failed" }, { status: 500 });
  }
}
