import { NextRequest, NextResponse } from "next/server";

const NOMINATIM_BASE = "https://nominatim.openstreetmap.org";

type SearchPlace = {
  id: number | string;
  name: string;
  nameAr: string;
  address: string;
  city: string;
  governorate: string;
  category: string;
  lat: number;
  lng: number;
  source: string;
  verified: boolean;
  searchAliases?: string[];
};

const BAGHDAD_AREA_ROWS: Array<[nameAr: string, name: string, lat: number, lng: number]> = [
  ["المنصور", "Mansour", 33.315, 44.355], ["الحارثية", "Harithiya", 33.325, 44.365],
  ["اليرموك", "Yarmouk", 33.292, 44.321], ["الداودي", "Dawudi", 33.309, 44.338],
  ["الجامعة", "Al-Jamiaa", 33.314, 44.325], ["الإسكان", "Iskan", 33.350, 44.326],
  ["العدل", "Adl", 33.365, 44.305], ["الخضراء", "Khadra", 33.332, 44.300],
  ["العامرية", "Amiriya", 33.302, 44.270], ["الغزالية", "Ghazaliya", 33.344, 44.260],
  ["القادسية", "Qadisiyah", 33.280, 44.326], ["حي العامل", "Hay Al-Amil", 33.271, 44.302],
  ["البياع", "Bayaa", 33.265, 44.337], ["السيدية", "Saydiya", 33.256, 44.351],
  ["الدورة", "Dora", 33.230, 44.374], ["أبو دشير", "Abu Dsher", 33.206, 44.350],
  ["حي الجهاد", "Hay Al-Jihad", 33.260, 44.270], ["الرسالة", "Risala", 33.270, 44.291],
  ["حي الإعلام", "Hay Al-Ilam", 33.277, 44.314], ["حي التراث", "Hay Al-Turath", 33.272, 44.322],
  ["حي الصحة", "Hay Al-Sihha", 33.248, 44.329], ["حي الفرات", "Hay Al-Furat", 33.245, 44.300],
  ["الشرطة الرابعة", "Fourth Police District", 33.250, 44.286], ["الكرادة داخل", "Karrada Dakhil", 33.306, 44.419],
  ["الكرادة خارج", "Karrada Kharij", 33.315, 44.417], ["الجادرية", "Jadriya", 33.276, 44.379],
  ["العرصات", "Arasat", 33.297, 44.407], ["المسبح", "Masbah", 33.299, 44.412],
  ["أبو نواس", "Abu Nuwas", 33.309, 44.414], ["السعدون", "Saadoun", 33.319, 44.415],
  ["باب الشرقي", "Bab Al-Sharqi", 33.329, 44.421], ["الشورجة", "Shorja", 33.344, 44.398],
  ["باب المعظم", "Bab Al-Muadham", 33.348, 44.390], ["الكفاح", "Al-Kifah", 33.341, 44.407],
  ["باب الشيخ", "Bab Al-Sheikh", 33.338, 44.414], ["الصدرية", "Sadria", 33.336, 44.409],
  ["الوزيرية", "Waziriya", 33.364, 44.391], ["العطيفية", "Atiifiya", 33.363, 44.373],
  ["الكاظمية", "Kadhimiya", 33.381, 44.343], ["الأعظمية", "Adhamiyah", 33.372, 44.382],
  ["الصليخ", "Sulaikh", 33.397, 44.382], ["الكريعات", "Kriat", 33.400, 44.368],
  ["الطالبية", "Talbiya", 33.387, 44.423], ["الشعب", "Shaab", 33.402, 44.432],
  ["حي تونس", "Hay Tunis", 33.398, 44.406], ["القاهرة", "Cairo District", 33.395, 44.414],
  ["شارع فلسطين", "Palestine Street", 33.355, 44.428], ["زيونة", "Zayouna", 33.329, 44.451],
  ["الغدير", "Ghadir", 33.329, 44.464], ["بغداد الجديدة", "New Baghdad", 33.335, 44.465],
  ["البلديات", "Baladiyat", 33.371, 44.480], ["مدينة الصدر", "Sadr City", 33.435, 44.454],
  ["الحبيبية", "Habibiya", 33.413, 44.471], ["حي أور", "Hay Ur", 33.437, 44.433],
  ["المشتل", "Mashtal", 33.352, 44.467], ["الأمين", "Al-Amin", 33.320, 44.467],
  ["الفضيلية", "Fudhaliya", 33.355, 44.479], ["الزعفرانية", "Zafaraniya", 33.235, 44.476],
  ["سبع قصور", "Sabaa Qusur", 33.478, 44.438], ["الراشدية", "Rashidiya", 33.515, 44.427],
  ["حي النصر", "Hay Al-Nasr", 33.405, 44.456], ["الرصافة", "Rusafa", 33.340, 44.415],
  ["الكرخ", "Karkh", 33.334, 44.366], ["العلاوي", "Allawi", 33.335, 44.365],
  ["شارع حيفا", "Haifa Street", 33.338, 44.380], ["المأمون", "Mamoun", 33.306, 44.345],
  ["العلوية", "Alwiya", 33.315, 44.425], ["البتاوين", "Bataween", 33.320, 44.420],
  ["أبو غريب", "Abu Ghraib", 33.305, 44.185], ["التاجي", "Taji", 33.525, 44.320],
  ["الطارمية", "Tarmiya", 33.670, 44.380], ["المحمودية", "Mahmudiya", 33.050, 44.360],
  ["المدائن", "Mada'in", 33.100, 44.580], ["النهروان", "Nahrawan", 33.360, 44.720],
  ["اليوسفية", "Yusufiya", 33.220, 44.320], ["سلمان باك", "Salman Pak", 33.070, 44.550],
];

const CURATED_BAGHDAD_AREAS: SearchPlace[] = BAGHDAD_AREA_ROWS.map(([nameAr, name, lat, lng], index) => ({
  id: `baghdad-area-${index + 1}`,
  name,
  nameAr,
  address: "مركز المنطقة التقريبي، بغداد، العراق",
  city: "بغداد",
  governorate: "بغداد",
  category: "neighbourhood",
  lat,
  lng,
  source: "curated",
  verified: false,
}));

function normalizeSearchText(value: string) {
  return value
    .toLocaleLowerCase("ar-IQ")
    .replace(/[\u064B-\u065F\u0670\u0640]/g, "")
    .replace(/[أإآ]/g, "ا")
    .replace(/ة/g, "ه")
    .replace(/ى/g, "ي")
    .replace(/[،,.;:()[\]{}]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function getAreaSearch(query: string) {
  const normalized = normalizeSearchText(query);
  const browseAll = /^(?:بغداد|baghdad|احياء(?: بغداد)?|مناطق(?: بغداد)?|baghdad (?:areas|districts|neighborhoods|neighbourhoods))$/.test(normalized);
  const areaQuery = normalized
    .replace(/^(?:حي|احياء|منطقه|مناطق|محله|قضاء|ناحيه|district|neighborhood|neighbourhood|suburb|area)\s+/, "")
    .replace(/(?:^|\s)(?:بغداد|baghdad)(?=\s|$)/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  return { browseAll, areaQuery };
}

function normalizeNominatimPlace(item: Record<string, unknown>): SearchPlace {
  const displayName = (item.display_name as string) ?? "";
  const addressParts = displayName.split(",");
  const namedetails = (item.namedetails as Record<string, string> | undefined) ?? {};
  const address = (item.address as Record<string, string> | undefined) ?? {};
  return {
    id: item.place_id as number | string,
    name: addressParts[0]?.trim() ?? "",
    nameAr: namedetails["name:ar"] ?? "",
    address: addressParts.slice(1).join(",").trim(),
    city: address.city ?? address.town ?? address.village ?? "",
    governorate: address.state ?? "",
    category: (item.type as string) ?? (item.class as string) ?? "place",
    lat: Number.parseFloat(item.lat as string),
    lng: Number.parseFloat(item.lon as string),
    source: "osm",
    verified: false,
    searchAliases: [namedetails.name, namedetails["name:ar"], namedetails["name:en"]].filter(Boolean),
  };
}

function matchesArea(place: SearchPlace, query: string) {
  const terms = query.split(" ").filter(Boolean);
  if (!terms.length) return false;
  const searchable = normalizeSearchText([
    place.name,
    place.nameAr,
    place.address,
    ...(place.searchAliases ?? []),
  ].join(" "));
  return searchable.includes(query) || terms.every((term) => searchable.includes(term));
}

function relevance(place: SearchPlace, query: string) {
  const normalizedNames = [place.nameAr, place.name, ...(place.searchAliases ?? [])]
    .map((name) => normalizeSearchText(name ?? ""));
  if (normalizedNames.some((name) => name === query)) return 0;
  if (normalizedNames.some((name) => name.startsWith(query))) return 1;
  if (normalizedNames.some((name) => name.includes(query))) return 2;
  return 3;
}

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const query = searchParams.get("q")?.trim() ?? "";
  const requestedLimit = Number.parseInt(searchParams.get("limit") ?? "20", 10);
  const limit = Number.isFinite(requestedLimit) ? Math.min(Math.max(requestedLimit, 1), 40) : 20;
  const normalizedQuery = normalizeSearchText(query);
  const { browseAll, areaQuery } = getAreaSearch(query);

  if (normalizedQuery.length < 2) {
    return NextResponse.json({ places: [], total: 0, query });
  }

  const latitude = Number(searchParams.get("lat"));
  const longitude = Number(searchParams.get("lng"));
  const hasValidLocation = Number.isFinite(latitude) && Number.isFinite(longitude)
    && Math.abs(latitude) <= 90 && Math.abs(longitude) <= 180;
  const nominatimPromise = browseAll
    ? Promise.resolve([] as SearchPlace[])
    : (async () => {
      const params = new URLSearchParams({
        q: query,
        format: "json",
        addressdetails: "1",
        namedetails: "1",
        limit: String(limit),
        "accept-language": "ar,en",
        countrycodes: "iq",
      });
      if (hasValidLocation) {
        const radius = 0.18;
        params.set("viewbox", `${longitude - radius},${latitude + radius},${longitude + radius},${latitude - radius}`);
        params.set("bounded", "0");
      }
      const response = await fetch(`${NOMINATIM_BASE}/search?${params.toString()}`, {
        headers: {
          "User-Agent": "CloudGpsApp/1.0 (+https://wain-navigation-liard.vercel.app)",
          "Accept-Language": "ar,en",
        },
        signal: AbortSignal.timeout(9000),
        next: { revalidate: 60 },
      });
      if (!response.ok) throw new Error(`Nominatim error: ${response.status}`);
      const data = (await response.json()) as Record<string, unknown>[];
      return data.map(normalizeNominatimPlace);
    })();

  try {
    const matchingAreas = browseAll
      ? CURATED_BAGHDAD_AREAS
      : CURATED_BAGHDAD_AREAS.filter((place) => matchesArea(place, areaQuery));
    matchingAreas.sort((a, b) => relevance(a, areaQuery) - relevance(b, areaQuery)
      || (a.nameAr || a.name).localeCompare(b.nameAr || b.name, "ar"));
    let nominatimPlaces: SearchPlace[] = [];
    try {
      nominatimPlaces = await nominatimPromise;
    } catch (error) {
      if (!matchingAreas.length) throw error;
      console.warn("Nominatim unavailable; returning matching Baghdad areas:", error);
    }

    const combined = browseAll ? matchingAreas : [...nominatimPlaces, ...matchingAreas];
    const seen = new Set<string>();
    const places = combined.filter((place) => {
      const keys = [place.nameAr, place.name, ...(place.searchAliases ?? [])]
        .map((name) => normalizeSearchText(name ?? ""))
        .filter(Boolean);
      if (!keys.length || keys.some((key) => seen.has(key))) return false;
      keys.forEach((key) => seen.add(key));
      return true;
    }).slice(0, browseAll ? 150 : limit);

    return NextResponse.json({ places, total: places.length, query });
  } catch (error) {
    console.error("Search error:", error);
    return NextResponse.json(
      { error: "Search service unavailable", places: [], total: 0, query },
      { status: 503 }
    );
  }
}
