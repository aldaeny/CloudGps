import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { notificationPreferences } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const userId = parseInt(searchParams.get("userId") ?? "0");
  if (!userId) return NextResponse.json({ preferences: null });

  try {
    const [prefs] = await db.select().from(notificationPreferences)
      .where(eq(notificationPreferences.userId, userId));
    return NextResponse.json({ preferences: prefs ?? null });
  } catch {
    return NextResponse.json({ preferences: null });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const body = (await req.json()) as {
      userId: number;
      trafficAlerts?: boolean;
      communityReports?: boolean;
      soundEnabled?: boolean;
      language?: string;
    };

    if (!body.userId || typeof body.userId !== "number" || body.userId <= 0) {
      // For session-based users without an account, return success without DB write
      return NextResponse.json({ success: true, note: "Guest user — preferences saved client-side" });
    }

    const [existing] = await db.select().from(notificationPreferences)
      .where(eq(notificationPreferences.userId, body.userId));

    if (existing) {
      await db.update(notificationPreferences)
        .set({
          trafficAlerts: body.trafficAlerts ?? existing.trafficAlerts,
          soundEnabled:  body.soundEnabled  ?? existing.soundEnabled,
          language:      body.language      ?? existing.language,
          updatedAt:     new Date(),
        })
        .where(eq(notificationPreferences.userId, body.userId));
    } else {
      await db.insert(notificationPreferences).values({
        userId:         body.userId,
        trafficAlerts:  body.trafficAlerts  ?? true,
        communityReports: body.communityReports ?? true,
        soundEnabled:   body.soundEnabled   ?? true,
        language:       body.language       ?? "ar",
      });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("User prefs error:", error);
    return NextResponse.json({ error: "Failed to update preferences" }, { status: 500 });
  }
}
