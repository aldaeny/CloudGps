import { NextRequest, NextResponse } from "next/server";
import type { RouteStep, LatLng } from "@/types";

// Using OSRM public demo server for routing
// Production: deploy your own OSRM instance with Iraq OSM data
const OSRM_BASE = "https://router.project-osrm.org";

interface OSRMStep {
  distance: number;
  duration: number;
  name: string;
  maneuver: {
    type: string;
    modifier?: string;
    location: [number, number];
  };
  geometry?: {
    coordinates: [number, number][];
  };
}

interface OSRMLeg {
  distance: number;
  duration: number;
  steps: OSRMStep[];
  summary: string;
}

interface OSRMRoute {
  distance: number;
  duration: number;
  legs: OSRMLeg[];
  geometry: {
    coordinates: [number, number][];
  };
}

interface OSRMResponse {
  code: string;
  routes?: OSRMRoute[];
  waypoints?: Array<{ name: string; location: [number, number] }>;
}

function decodeManeuver(type: string, modifier?: string, lang: "ar" | "en" = "ar"): string {
  const maneuvers: Record<string, Record<string, string>> = {
    ar: {
      "turn-left": "انعطف يساراً",
      "turn-right": "انعطف يميناً",
      "turn-sharp left": "انعطف بحدة يساراً",
      "turn-sharp right": "انعطف بحدة يميناً",
      "turn-slight left": "انعطف قليلاً يساراً",
      "turn-slight right": "انعطف قليلاً يميناً",
      "continue-straight": "واصل السير مستقيماً",
      "roundabout-left": "أدِر في الدوار",
      "roundabout-right": "أدِر في الدوار",
      "merge-left": "ادمج يساراً",
      "merge-right": "ادمج يميناً",
      "arrive-left": "وصلت إلى وجهتك (يساراً)",
      "arrive-right": "وصلت إلى وجهتك (يميناً)",
      "arrive-straight": "وصلت إلى وجهتك",
      "depart-right": "ابدأ السير",
      "depart-left": "ابدأ السير",
      "depart-straight": "ابدأ السير مستقيماً",
    },
    en: {
      "turn-left": "Turn left",
      "turn-right": "Turn right",
      "turn-sharp left": "Turn sharp left",
      "turn-sharp right": "Turn sharp right",
      "turn-slight left": "Turn slight left",
      "turn-slight right": "Turn slight right",
      "continue-straight": "Continue straight",
      "roundabout-left": "Enter roundabout",
      "roundabout-right": "Enter roundabout",
      "merge-left": "Merge left",
      "merge-right": "Merge right",
      "arrive-left": "Arrive at destination (left)",
      "arrive-right": "Arrive at destination (right)",
      "arrive-straight": "Arrive at destination",
      "depart-right": "Head out",
      "depart-left": "Head out",
      "depart-straight": "Head straight",
    },
  };

  const key = modifier ? `${type}-${modifier}` : type;
  return (
    maneuvers[lang][key] ??
    maneuvers[lang][type] ??
    (lang === "ar" ? "واصل السير" : "Continue")
  );
}

function decodePolyline(coordinates: [number, number][]): LatLng[] {
  return coordinates.map(([lng, lat]) => ({ lat, lng }));
}

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const originLat = searchParams.get("originLat");
  const originLng = searchParams.get("originLng");
  const destLat = searchParams.get("destLat");
  const destLng = searchParams.get("destLng");
  const profile = searchParams.get("profile") ?? "car";
  const alternatives = searchParams.get("alternatives") === "true";

  if (!originLat || !originLng || !destLat || !destLng) {
    return NextResponse.json({ error: "Missing coordinates" }, { status: 400 });
  }

  const oLat = parseFloat(originLat);
  const oLng = parseFloat(originLng);
  const dLat = parseFloat(destLat);
  const dLng = parseFloat(destLng);

  if (
    isNaN(oLat) || isNaN(oLng) || isNaN(dLat) || isNaN(dLng) ||
    oLat < -90 || oLat > 90 || dLat < -90 || dLat > 90 ||
    oLng < -180 || oLng > 180 || dLng < -180 || dLng > 180
  ) {
    return NextResponse.json({ error: "Invalid coordinates" }, { status: 400 });
  }

  // The public OSRM demo server is prepared with its driving profile only.
  // Sending `car`, `bike`, or `foot` to it produces an invalid service URL.
  if (profile !== "car" && profile !== "driving") {
    return NextResponse.json(
      { error: "Only car routing is available on this server" },
      { status: 422 }
    );
  }
  const osrmProfile = "driving";
  const coords = `${oLng},${oLat};${dLng},${dLat}`;

  try {
    const params = new URLSearchParams({
      overview: "full",
      geometries: "geojson",
      steps: "true",
      alternatives: alternatives ? "true" : "false",
    });

    const url = `${OSRM_BASE}/route/v1/${osrmProfile}/${coords}?${params}`;

    const response = await fetch(url, {
      headers: { "User-Agent": "CloudGpsApp/1.0" },
      next: { revalidate: 0 },
    });

    if (!response.ok) {
      throw new Error(`OSRM error: ${response.status}`);
    }

    const data = (await response.json()) as OSRMResponse;

    if (data.code !== "Ok" || !data.routes?.length) {
      return NextResponse.json(
        { error: "No route found between these points" },
        { status: 404 }
      );
    }

    const routes = data.routes.map((r, idx) => {
      const allSteps: RouteStep[] = [];

      r.legs.forEach((leg) => {
        leg.steps.forEach((step) => {
          allSteps.push({
            instruction: decodeManeuver(step.maneuver.type, step.maneuver.modifier, "ar"),
            instructionAr: decodeManeuver(step.maneuver.type, step.maneuver.modifier, "ar"),
            distance: step.distance,
            duration: step.duration,
            maneuver: step.maneuver.type,
            name: step.name ?? "",
            coordinates: {
              lat: step.maneuver.location[1],
              lng: step.maneuver.location[0],
            },
          });
        });
      });

      return {
        id: `route_${idx}`,
        distance: r.distance,
        duration: r.duration,
        geometry: decodePolyline(r.geometry.coordinates),
        steps: allSteps,
        summary: r.legs[0]?.summary ?? "",
        profile: profile as "car" | "bicycle" | "foot",
        isAlternative: idx > 0,
      };
    });

    return NextResponse.json({ routes, status: "ok" });
  } catch (error) {
    console.error("Routing error:", error);
    return NextResponse.json(
      { error: "Routing service unavailable. Please try again." },
      { status: 503 }
    );
  }
}
