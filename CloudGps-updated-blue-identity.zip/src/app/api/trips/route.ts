import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { trips } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const sessionId = searchParams.get("sessionId");
  const limit = Math.min(parseInt(searchParams.get("limit") ?? "20"), 50);

  if (!sessionId) {
    return NextResponse.json({ trips: [] });
  }

  try {
    const recent = await db
      .select()
      .from(trips)
      .where(eq(trips.sessionId, sessionId))
      .orderBy(desc(trips.startedAt))
      .limit(limit);

    return NextResponse.json({ trips: recent });
  } catch {
    return NextResponse.json({ trips: [] });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as {
      sessionId: string;
      originName?: string;
      originLat?: number;
      originLng?: number;
      destName?: string;
      destLat?: number;
      destLng?: number;
      distanceKm?: number;
      durationMin?: number;
      status?: string;
    };

    const [trip] = await db
      .insert(trips)
      .values({
        sessionId: body.sessionId,
        originName: body.originName,
        originLat: body.originLat,
        originLng: body.originLng,
        destName: body.destName,
        destLat: body.destLat,
        destLng: body.destLng,
        distanceKm: body.distanceKm,
        durationMin: body.durationMin,
        status: body.status ?? "started",
      })
      .returning();

    return NextResponse.json({ trip, success: true });
  } catch (error) {
    console.error("Trip POST error:", error);
    return NextResponse.json({ error: "Failed to save trip" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const sessionId = searchParams.get("sessionId");

  if (!sessionId) {
    return NextResponse.json({ error: "Session ID required" }, { status: 400 });
  }

  try {
    await db.delete(trips).where(eq(trips.sessionId, sessionId));
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Failed to clear history" }, { status: 500 });
  }
}
