import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { offlineMapRegions } from "@/db/schema";
import { eq, and } from "drizzle-orm";

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as {
      sessionId: string;
      regionName: string;
      minLat: number; minLng: number;
      maxLat: number; maxLng: number;
    };

    if (!body.sessionId || !body.regionName) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }

    // Estimate size based on bounding box
    const latDiff = Math.abs(body.maxLat - body.minLat);
    const lngDiff = Math.abs(body.maxLng - body.minLng);
    const areaDeg  = latDiff * lngDiff;
    const sizeMb   = Math.round(areaDeg * 2000); // rough estimate

    const [region] = await db
      .insert(offlineMapRegions)
      .values({
        sessionId: body.sessionId,
        regionName: body.regionName,
        minLat: body.minLat, minLng: body.minLng,
        maxLat: body.maxLat, maxLng: body.maxLng,
        sizeMb,
        status: "completed",
        metadata: {
          note: "Tile metadata only. Actual tile caching requires Service Worker implementation.",
          minZoom: 8,
          maxZoom: 16,
        },
      })
      .returning();

    return NextResponse.json({ id: region?.id, success: true, sizeMb });
  } catch (error) {
    console.error("Offline map POST error:", error);
    return NextResponse.json({ error: "Failed to register offline region" }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const sessionId = searchParams.get("sessionId");

  if (!sessionId) return NextResponse.json({ regions: [] });

  try {
    const regions = await db
      .select()
      .from(offlineMapRegions)
      .where(eq(offlineMapRegions.sessionId, sessionId));

    return NextResponse.json({ regions });
  } catch {
    return NextResponse.json({ regions: [] });
  }
}
