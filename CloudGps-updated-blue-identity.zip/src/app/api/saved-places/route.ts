import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { savedPlaces } from "@/db/schema";
import { eq, and } from "drizzle-orm";

// GET /api/saved-places?sessionId=
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const sessionId = searchParams.get("sessionId");

  if (!sessionId) {
    return NextResponse.json({ places: [] });
  }

  try {
    // For session-based (unauthenticated) users, we store by session
    // In production with auth, filter by userId
    const places = await db
      .select()
      .from(savedPlaces)
      .where(eq(savedPlaces.userId, -1)) // placeholder for session-based
      .limit(50);

    return NextResponse.json({ places });
  } catch {
    return NextResponse.json({ places: [] });
  }
}

// POST /api/saved-places
export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as {
      name: string;
      nameAr?: string;
      address?: string;
      lat: number;
      lng: number;
      category: string;
    };

    if (!body.name || !body.lat || !body.lng) {
      return NextResponse.json({ error: "name, lat, lng required" }, { status: 400 });
    }

    const [place] = await db
      .insert(savedPlaces)
      .values({
        userId: null,
        name: body.name.slice(0, 200),
        nameAr: body.nameAr?.slice(0, 200),
        address: body.address?.slice(0, 500),
        latitude: body.lat,
        longitude: body.lng,
        category: body.category ?? "custom",
      })
      .returning();

    return NextResponse.json({ place, success: true });
  } catch (error) {
    console.error("Save place error:", error);
    return NextResponse.json({ error: "Failed to save place" }, { status: 500 });
  }
}
