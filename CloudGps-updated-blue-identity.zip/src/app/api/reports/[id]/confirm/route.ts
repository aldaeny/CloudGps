import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { trafficReports, reportConfirmations } from "@/db/schema";
import { eq, and, sql } from "drizzle-orm";

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const reportId = parseInt(id);

  if (isNaN(reportId)) {
    return NextResponse.json({ error: "Invalid report ID" }, { status: 400 });
  }

  try {
    const body = (await req.json()) as { sessionId: string; type: "confirm" | "deny" | "resolve" };

    if (!body.sessionId) {
      return NextResponse.json({ error: "Session ID required" }, { status: 400 });
    }

    // Check if report exists
    const [report] = await db
      .select()
      .from(trafficReports)
      .where(eq(trafficReports.id, reportId));

    if (!report) {
      return NextResponse.json({ error: "Report not found" }, { status: 404 });
    }

    // Check if already confirmed by this session
    const existing = await db
      .select()
      .from(reportConfirmations)
      .where(
        and(
          eq(reportConfirmations.reportId, reportId),
          eq(reportConfirmations.sessionId, body.sessionId)
        )
      );

    if (existing.length > 0) {
      return NextResponse.json({ message: "Already responded to this report" });
    }

    // Add confirmation
    await db.insert(reportConfirmations).values({
      reportId,
      confirmationType: body.type,
      sessionId: body.sessionId,
    });

    // Update report stats
    if (body.type === "confirm") {
      const newConfirmations = (report.confirmations ?? 0) + 1;
      const newConfidence = Math.min(0.5 + newConfirmations * 0.1, 0.99);
      await db
        .update(trafficReports)
        .set({
          confirmations: sql`${trafficReports.confirmations} + 1`,
          confidence: newConfidence,
          reviewStatus: newConfirmations >= 3 ? "verified" : "pending",
          updatedAt: new Date(),
        })
        .where(eq(trafficReports.id, reportId));
    } else if (body.type === "deny") {
      const newDenials = (report.denials ?? 0) + 1;
      await db
        .update(trafficReports)
        .set({
          denials: sql`${trafficReports.denials} + 1`,
          updatedAt: new Date(),
          status: newDenials >= 5 ? "rejected" : report.status,
        })
        .where(eq(trafficReports.id, reportId));
    } else if (body.type === "resolve") {
      await db
        .update(trafficReports)
        .set({
          status: "resolved",
          updatedAt: new Date(),
          expiresAt: new Date(),
        })
        .where(eq(trafficReports.id, reportId));
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Confirmation error:", error);
    return NextResponse.json({ error: "Failed to process confirmation" }, { status: 500 });
  }
}
