import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { trafficReports } from "@/db/schema";
import { and, eq, gte, sql, desc } from "drizzle-orm";
import type { ReportType } from "@/types";

const VALID_TYPES: ReportType[] = [
  "accident", "congestion", "road_closed", "pothole",
  "obstacle", "maintenance", "stopped_vehicle", "road_hazard", "cleared",
];

// GET /api/reports?lat=&lng=&radius=
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const lat = parseFloat(searchParams.get("lat") ?? "0");
  const lng = parseFloat(searchParams.get("lng") ?? "0");
  const radius = Math.min(parseFloat(searchParams.get("radius") ?? "5"), 50); // km, max 50

  if (!lat || !lng) {
    return NextResponse.json({ error: "lat and lng required" }, { status: 400 });
  }

  try {
    // Get active, non-expired reports within radius
    const now = new Date();
    const reports = await db
      .select()
      .from(trafficReports)
      .where(
        and(
          eq(trafficReports.status, "active"),
          gte(trafficReports.expiresAt, now)
        )
      )
      .orderBy(desc(trafficReports.createdAt))
      .limit(100);

    // Filter by distance (approximate using lat/lng delta)
    const nearby = reports.filter((r) => {
      if (r.latitude === null || r.longitude === null) return false;
      const dlat = r.latitude - lat;
      const dlng = r.longitude - lng;
      const dist = Math.sqrt(dlat * dlat + dlng * dlng) * 111; // rough km
      return dist <= radius;
    });

    return NextResponse.json({
      reports: nearby.map((r) => ({
        id: r.id,
        type: r.type,
        lat: r.latitude,
        lng: r.longitude,
        description: r.description,
        descriptionAr: r.descriptionAr,
        source: r.source,
        status: r.status,
        confidence: r.confidence,
        confirmations: r.confirmations,
        denials: r.denials,
        createdAt: r.createdAt?.toISOString(),
        updatedAt: r.updatedAt?.toISOString(),
        expiresAt: r.expiresAt?.toISOString(),
        reviewStatus: r.reviewStatus,
      })),
    });
  } catch (error) {
    console.error("Reports GET error:", error);
    return NextResponse.json({ error: "Failed to fetch reports" }, { status: 500 });
  }
}

// POST /api/reports
export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as {
      type: string;
      lat: number;
      lng: number;
      description?: string;
      sessionId: string;
    };

    // Validation
    if (!VALID_TYPES.includes(body.type as ReportType)) {
      return NextResponse.json({ error: "Invalid report type" }, { status: 400 });
    }

    if (!body.lat || !body.lng || typeof body.lat !== "number" || typeof body.lng !== "number") {
      return NextResponse.json({ error: "Valid coordinates required" }, { status: 400 });
    }

    if (body.lat < 29 || body.lat > 38 || body.lng < 38 || body.lng > 49) {
      return NextResponse.json({ error: "Coordinates must be within Iraq" }, { status: 400 });
    }

    if (!body.sessionId || body.sessionId.length < 5) {
      return NextResponse.json({ error: "Session ID required" }, { status: 400 });
    }

    // Rate limiting: check recent reports from same session (last hour)
    const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
    const recentCount = await db
      .select({ count: sql<number>`count(*)` })
      .from(trafficReports)
      .where(
        and(
          eq(trafficReports.reporterSession, body.sessionId),
          gte(trafficReports.createdAt, oneHourAgo)
        )
      );

    if (recentCount[0] && recentCount[0].count >= 10) {
      return NextResponse.json(
        { error: "Too many reports. Please wait before submitting again." },
        { status: 429 }
      );
    }

    // Duplicate detection: check for similar report within 200m and 30 min
    const thirtyMinAgo = new Date(Date.now() - 30 * 60 * 1000);
    const existing = await db
      .select()
      .from(trafficReports)
      .where(
        and(
          eq(trafficReports.type, body.type),
          eq(trafficReports.status, "active"),
          gte(trafficReports.createdAt, thirtyMinAgo)
        )
      );

    const isDuplicate = existing.some((r) => {
      if (!r.latitude || !r.longitude) return false;
      const dlat = r.latitude - body.lat;
      const dlng = r.longitude - body.lng;
      const dist = Math.sqrt(dlat * dlat + dlng * dlng) * 111000; // meters
      return dist < 200;
    });

    if (isDuplicate) {
      // Return the existing report ID with a note
      const match = existing[0];
      return NextResponse.json({
        id: match?.id,
        duplicate: true,
        message: "A similar report exists nearby. It has been confirmed.",
      });
    }

    // Set expiry based on type
    const expiryHours: Partial<Record<ReportType, number>> = {
      accident: 4,
      congestion: 2,
      road_closed: 24,
      pothole: 72,
      maintenance: 24,
      obstacle: 8,
      stopped_vehicle: 2,
      road_hazard: 6,
      cleared: 1,
    };

    const hours = expiryHours[body.type as ReportType] ?? 4;
    const expiresAt = new Date(Date.now() + hours * 60 * 60 * 1000);

    const [report] = await db
      .insert(trafficReports)
      .values({
        type: body.type,
        latitude: body.lat,
        longitude: body.lng,
        description: body.description?.slice(0, 500),
        source: "community",
        status: "active",
        confidence: 0.5,
        reporterSession: body.sessionId,
        expiresAt,
        reviewStatus: "pending",
      })
      .returning();

    return NextResponse.json({
      id: report?.id,
      success: true,
      expiresAt: expiresAt.toISOString(),
    });
  } catch (error) {
    console.error("Report POST error:", error);
    return NextResponse.json({ error: "Failed to submit report" }, { status: 500 });
  }
}
