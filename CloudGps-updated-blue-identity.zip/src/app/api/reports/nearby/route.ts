import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { trafficReports } from "@/db/schema";
import { and, eq, gte, desc } from "drizzle-orm";

// GET /api/reports/nearby?lat=&lng=&radius=&since=
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const lat    = parseFloat(searchParams.get("lat") ?? "0");
  const lng    = parseFloat(searchParams.get("lng") ?? "0");
  const radius = Math.min(parseFloat(searchParams.get("radius") ?? "10"), 50);
  const since  = searchParams.get("since");

  if (!lat || !lng) {
    return NextResponse.json({ error: "lat and lng required" }, { status: 400 });
  }

  try {
    const conditions = [eq(trafficReports.status, "active")];

    if (since) {
      const sinceDate = new Date(since);
      if (!isNaN(sinceDate.getTime())) {
        conditions.push(gte(trafficReports.updatedAt, sinceDate));
      }
    } else {
      // Default: non-expired
      conditions.push(gte(trafficReports.expiresAt, new Date()));
    }

    const reports = await db
      .select()
      .from(trafficReports)
      .where(and(...conditions))
      .orderBy(desc(trafficReports.createdAt))
      .limit(200);

    // Filter by distance
    const nearby = reports.filter(r => {
      if (!r.latitude || !r.longitude) return false;
      const dlat = r.latitude - lat;
      const dlng = r.longitude - lng;
      return Math.sqrt(dlat*dlat + dlng*dlng) * 111 <= radius;
    });

    return NextResponse.json({
      reports: nearby.map(r => ({
        id: r.id, type: r.type,
        lat: r.latitude, lng: r.longitude,
        description: r.description,
        descriptionAr: r.descriptionAr,
        source: r.source, status: r.status,
        confidence: r.confidence,
        confirmations: r.confirmations,
        denials: r.denials,
        createdAt: r.createdAt?.toISOString(),
        updatedAt: r.updatedAt?.toISOString(),
        expiresAt: r.expiresAt?.toISOString(),
        reviewStatus: r.reviewStatus,
      })),
      count: nearby.length,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Nearby reports error:", error);
    return NextResponse.json({ error: "Failed to fetch nearby reports" }, { status: 500 });
  }
}
