"use client";

import { useEffect, useState } from "react";
import dynamic from "next/dynamic";
import { WainLogo } from "@/components/ui/WainLogo";
import { t } from "@/lib/translations";
import { useAppStore } from "@/store/useAppStore";

const HomeMapScreen = dynamic(
  () => import("@/components/map/HomeMapScreen").then((module) => module.HomeMapScreen),
  {
    ssr: false,
    loading: () => <SplashScreen />,
  }
);

export default function AppPage() {
  const [showSplash, setShowSplash] = useState(true);

  useEffect(() => {
    const timer = window.setTimeout(() => setShowSplash(false), 1800);
    return () => window.clearTimeout(timer);
  }, []);

  if (showSplash) return <SplashScreen />;
  return <HomeMapScreen />;
}

function SplashScreen() {
  const language = useAppStore((state) => state.language);

  return (
    <div
      className="fixed inset-0 z-[9999] flex flex-col items-center justify-center"
      style={{ background: "linear-gradient(160deg, #0A6AD6 0%, #0B1F3A 100%)" }}
    >
      <WainLogo showText className="mb-5 w-[min(84vw,340px)] shadow-xl" />
      <p className="text-sm text-white/70" style={{ fontFamily: "'Tajawal',sans-serif" }}>
        {t("appSlogan", language)}
      </p>
    </div>
  );
}
