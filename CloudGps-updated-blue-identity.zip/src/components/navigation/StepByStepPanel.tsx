"use client";
import { X, Navigation, MapPin, Clock, ChevronLeft, ChevronRight } from "lucide-react";
import { useAppStore } from "@/store/useAppStore";
import { t } from "@/lib/translations";
import { formatDistance, formatDuration } from "@/lib/utils";

export function StepByStepPanel() {
  const { language, navigation, setActivePanel } = useAppStore();
  const lang = language;
  const dir  = lang === "ar" ? "rtl" : "ltr";

  if (!navigation.route) return null;
  const { steps } = navigation.route;

  const maneuverEmoji: Record<string, string> = {
    "turn-left":"↰","turn-right":"↱","turn-sharp left":"⬅","turn-sharp right":"➡",
    "turn-slight left":"↖","turn-slight right":"↗",
    "straight":"⬆","continue":"⬆","arrive":"📍","depart":"🚗",
    "roundabout":"🔄","merge":"↗","uturn":"↩",
  };

  function getEmoji(type: string) {
    const key = Object.keys(maneuverEmoji).find(k => type?.toLowerCase().includes(k));
    return maneuverEmoji[key ?? "straight"] ?? "⬆";
  }

  return (
    <div className="bg-[#F7FAFF] rounded-t-3xl shadow-2xl max-h-[85vh] flex flex-col" dir={dir}>
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-[#D9E4F2] flex-shrink-0">
        <h2 className="text-lg font-black text-[#0B1F3A]" style={{ fontFamily:"'Tajawal',sans-serif" }}>
          {lang==="ar"?"تفاصيل المسار":"Route Details"}
        </h2>
        <button onClick={() => setActivePanel("navigation")}
                className="p-2 rounded-full hover:bg-[#F7FAFF]">
          <X size={20} color="#61738B"/>
        </button>
      </div>

      {/* Summary */}
      <div className="flex gap-4 px-5 py-3 bg-[#0A6AD6]/5 border-b border-[#D9E4F2] flex-shrink-0">
        <div className="flex items-center gap-1.5">
          <Clock size={15} color="#0A6AD6" />
          <span className="font-black text-[#0A6AD6]" style={{ fontFamily:"'Tajawal',sans-serif" }}>
            {formatDuration(navigation.route.duration, lang)}
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          <MapPin size={15} color="#61738B" />
          <span className="text-[#61738B]" style={{ fontFamily:"'Tajawal',sans-serif" }}>
            {formatDistance(navigation.route.distance, lang)}
          </span>
        </div>
        <div className="flex items-center gap-1.5 text-xs text-[#61738B]" style={{ fontFamily:"'Tajawal',sans-serif" }}>
          {steps.length} {lang==="ar"?"خطوة":"steps"}
        </div>
      </div>

      {/* Steps */}
      <div className="overflow-y-auto flex-1 scrollbar-thin">
        {steps.map((step, i) => (
          <div key={i}
               className={`flex items-start gap-3 px-5 py-3 border-b border-[#D9E4F2] last:border-0 transition-colors ${
                 i === navigation.currentStepIndex ? "bg-[#0A6AD6]/5" : "hover:bg-[#F7FAFF]"
               }`}
               dir={dir}>
            {/* Step number / emoji */}
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 text-xl ${
              i === navigation.currentStepIndex ? "bg-[#0A6AD6]" : "bg-[#F7FAFF]"
            }`}>
              {i === navigation.currentStepIndex
                ? <span className="text-white text-sm">{getEmoji(step.maneuver)}</span>
                : <span>{getEmoji(step.maneuver)}</span>}
            </div>

            <div className="flex-1 min-w-0">
              <p className={`text-sm leading-snug ${
                i === navigation.currentStepIndex ? "font-black text-[#0A6AD6]" : "font-bold text-[#0B1F3A]"
              }`} style={{ fontFamily:"'Tajawal',sans-serif" }}>
                {lang==="ar" ? step.instructionAr : step.instruction}
              </p>
              {step.name && (
                <p className="text-xs text-[#61738B] mt-0.5" style={{ fontFamily:"'Tajawal',sans-serif" }}>
                  {step.name}
                </p>
              )}
            </div>

            <div className="text-right flex-shrink-0">
              <p className="text-xs font-bold text-[#61738B]"
                 style={{ fontFamily:"'Tajawal',sans-serif" }}>
                {formatDistance(step.distance, lang)}
              </p>
            </div>
          </div>
        ))}
      </div>
      <div className="safe-bottom" />
    </div>
  );
}
