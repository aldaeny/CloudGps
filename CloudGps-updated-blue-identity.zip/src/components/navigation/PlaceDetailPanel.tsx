"use client";
import { useState } from "react";
import {
  ArrowRight,
  MapPin,
  Navigation,
  Phone,
  Globe,
  Clock,
  Star,
  Home,
  Briefcase,
  X,
  Share2,
} from "lucide-react";
import { useAppStore } from "@/store/useAppStore";
import { t } from "@/lib/translations";

export function PlaceDetailPanel() {
  const {
    language,
    selectedPlace,
    setActivePanel,
    setSelectedPlace,
    setDestination,
    origin,
    userLocation,
    savedPlaces,
    addSavedPlace,
    removeSavedPlace,
  } = useAppStore();

  const lang = language;
  const dir = lang === "ar" ? "rtl" : "ltr";
  const [saving, setSaving] = useState(false);

  if (!selectedPlace) return null;

  const savedForCategory = (category: "home" | "work" | "favorite") => savedPlaces.find(
    (p) => p.category === category
      && Math.abs(p.lat - selectedPlace.lat) < 0.001
      && Math.abs(p.lng - selectedPlace.lng) < 0.001
  );

  async function handleNavigate() {
    if (!selectedPlace) return;
    setDestination({
      name: selectedPlace.nameAr ?? selectedPlace.name,
      location: { lat: selectedPlace.lat, lng: selectedPlace.lng },
    });
    if (!origin && userLocation) {
      useAppStore.getState().setOrigin({
        name: t("myLocation", lang),
        location: userLocation,
      });
    }
    setActivePanel("route-preview");
  }

  async function handleSave(category: "home" | "work" | "favorite") {
    if (!selectedPlace) return;
    setSaving(true);
    try {
      const existing = savedForCategory(category);
      if (existing) {
        removeSavedPlace(existing.id);
        return;
      }
      addSavedPlace({
        id: Date.now(),
        name: selectedPlace.name,
        nameAr: selectedPlace.nameAr,
        address: selectedPlace.address,
        lat: selectedPlace.lat,
        lng: selectedPlace.lng,
        category,
        createdAt: new Date().toISOString(),
      });
    } finally {
      setSaving(false);
    }
  }

  function handleClose() {
    setSelectedPlace(null);
    setActivePanel("home");
  }

  const name = lang === "ar" ? (selectedPlace.nameAr || selectedPlace.name) : selectedPlace.name;

  return (
    <div
      className="bg-[#F7FAFF] rounded-t-3xl shadow-2xl p-5 pb-8 max-h-[70vh] overflow-y-auto"
      dir={dir}
    >
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1 min-w-0">
          <h2
            className="text-xl font-bold text-[#0B1F3A] leading-snug"
            style={{ fontFamily: "'Tajawal', sans-serif" }}
          >
            {name}
          </h2>
          {selectedPlace.category && (
            <span className="inline-block bg-[#F7FAFF] text-[#61738B] text-xs px-2 py-1 rounded-full mt-1"
              style={{ fontFamily: "'Tajawal', sans-serif" }}>
              {selectedPlace.category}
            </span>
          )}
        </div>
        <button
          onClick={handleClose}
          className="p-2 rounded-full hover:bg-[#F7FAFF] transition-colors flex-shrink-0"
          aria-label={t("close", lang)}
        >
          <X size={20} color="#61738B" />
        </button>
      </div>

      {/* Address */}
      {selectedPlace.address && (
        <div className="flex items-start gap-2 mb-4">
          <MapPin size={16} color="#61738B" className="flex-shrink-0 mt-0.5" />
          <p className="text-sm text-[#61738B]" style={{ fontFamily: "'Tajawal', sans-serif" }}>
            {selectedPlace.address.split(",").slice(0, 4).join("، ")}
          </p>
        </div>
      )}

      {/* Contact info */}
      {selectedPlace.phone && (
        <a
          href={`tel:${selectedPlace.phone}`}
          className="flex items-center gap-2 mb-3 text-[#0A6AD6] hover:underline"
        >
          <Phone size={16} />
          <span className="text-sm" style={{ fontFamily: "'Tajawal', sans-serif" }}>
            {selectedPlace.phone}
          </span>
        </a>
      )}
      {selectedPlace.website && (
        <a
          href={selectedPlace.website}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 mb-3 text-[#0A6AD6] hover:underline"
        >
          <Globe size={16} />
          <span className="text-sm truncate" style={{ fontFamily: "'Tajawal', sans-serif" }}>
            {selectedPlace.website}
          </span>
        </a>
      )}
      {selectedPlace.openingHours && (
        <div className="flex items-center gap-2 mb-4">
          <Clock size={16} color="#61738B" />
          <span className="text-sm text-[#61738B]" style={{ fontFamily: "'Tajawal', sans-serif" }}>
            {selectedPlace.openingHours}
          </span>
        </div>
      )}

      {/* Primary action - Navigate */}
      <button
        onClick={handleNavigate}
        className="w-full bg-[#0A6AD6] text-white py-4 rounded-2xl font-bold text-lg flex items-center justify-center gap-2 shadow-lg hover:bg-[#074BA4] transition-colors mb-3"
        style={{ fontFamily: "'Tajawal', sans-serif" }}
      >
        <Navigation size={20} />
        {t("startNavigation", lang)}
      </button>

      {/* Secondary actions */}
      <div className="grid grid-cols-3 gap-2 mb-4">
        <button
          onClick={() => handleSave("home")}
          disabled={saving}
          className="flex flex-col items-center gap-1 bg-[#F7FAFF] rounded-xl py-3 hover:bg-[#D9E4F2] transition-colors disabled:opacity-50"
        >
          <Home size={18} color={savedForCategory("home") ? "#0A6AD6" : "#61738B"} fill={savedForCategory("home") ? "#0A6AD6" : "none"} />
          <span className="text-xs text-[#0B1F3A]" style={{ fontFamily: "'Tajawal', sans-serif" }}>
            {t("setAsHome", lang)}
          </span>
        </button>
        <button
          onClick={() => handleSave("work")}
          disabled={saving}
          className="flex flex-col items-center gap-1 bg-[#F7FAFF] rounded-xl py-3 hover:bg-[#D9E4F2] transition-colors disabled:opacity-50"
        >
          <Briefcase size={18} color={savedForCategory("work") ? "#0A6AD6" : "#61738B"} fill={savedForCategory("work") ? "#0A6AD6" : "none"} />
          <span className="text-xs text-[#0B1F3A]" style={{ fontFamily: "'Tajawal', sans-serif" }}>
            {t("setAsWork", lang)}
          </span>
        </button>
        <button
          onClick={() => handleSave("favorite")}
          disabled={saving}
          className="flex flex-col items-center gap-1 bg-[#F7FAFF] rounded-xl py-3 hover:bg-[#D9E4F2] transition-colors disabled:opacity-50"
        >
          <Star size={18} color={savedForCategory("favorite") ? "#D62828" : "#0A6AD6"} fill={savedForCategory("favorite") ? "#D62828" : "none"} />
          <span className="text-xs text-[#0B1F3A]" style={{ fontFamily: "'Tajawal', sans-serif" }}>
            {savedForCategory("favorite") ? t("removePlace", lang) : t("addToFavorites", lang)}
          </span>
        </button>
      </div>

      {/* Coordinates */}
      <p className="text-xs text-center text-[#61738B]" style={{ fontFamily: "'Tajawal', sans-serif" }}>
        {selectedPlace.lat.toFixed(5)}, {selectedPlace.lng.toFixed(5)}
      </p>
    </div>
  );
}
