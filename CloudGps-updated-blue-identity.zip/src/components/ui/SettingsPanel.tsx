"use client";
import { useState } from "react";
import {
  X, Moon, Sun, Volume2, Shield, Info,
  ChevronRight, Trash2, Download, Map, HelpCircle,
  User, Navigation, AlertTriangle, Star,
} from "lucide-react";
import { useAppStore } from "@/store/useAppStore";
import { t } from "@/lib/translations";
import { WainLogoCompact } from "./WainLogo";
import { waenToast } from "@/lib/toast";

export function SettingsPanel() {
  const {
    language, theme, isDarkMap, voiceMuted, showReportsLayer, showTrafficLayer,
    setLanguage, setTheme, setIsDarkMap, setVoiceMuted,
    setShowReportsLayer, setShowTrafficLayer,
    setActivePanel, clearRecentDestinations,
  } = useAppStore();

  const lang = language;
  const dir  = lang === "ar" ? "rtl" : "ltr";
  const [confirmClear, setConfirmClear] = useState(false);

  function handleClearHistory() {
    if (confirmClear) {
      clearRecentDestinations();
      setConfirmClear(false);
      waenToast.success(lang === "ar" ? "تم مسح السجل" : "History cleared");
    } else {
      setConfirmClear(true);
      setTimeout(() => setConfirmClear(false), 3000);
    }
  }

  return (
    <div className="settings-panel w-full rounded-t-3xl shadow-2xl max-h-[85dvh] flex flex-col border" dir={dir}>
      {/* Header */}
      <div className="settings-header flex items-center justify-between px-5 py-4 border-b sticky top-0 rounded-t-3xl z-10 flex-shrink-0">
        <h2 className="text-lg font-black text-[#0B1F3A]" style={{ fontFamily:"'Tajawal',sans-serif" }}>
          {t("settings", lang)}
        </h2>
        <button onClick={() => setActivePanel("home")} className="p-2 rounded-full hover:bg-[#F7FAFF]">
          <X size={20} color="#61738B" />
        </button>
      </div>

      <div className="overflow-y-auto flex-1 scrollbar-thin">
        {/* Language */}
        <Section title={t("language", lang)}>
          <div className="settings-segment flex gap-2 p-1 rounded-2xl">
            <LangBtn active={language==="ar"} onClick={() => setLanguage("ar")}
                     font="'Tajawal',sans-serif" label="العربية 🇮🇶" />
            <LangBtn active={language==="en"} onClick={() => setLanguage("en")}
                     font="'Montserrat',sans-serif" label="English" />
          </div>
        </Section>

        {/* Appearance */}
        <Section title={t("theme", lang)}>
          <div className="settings-segment flex gap-2 p-1 rounded-2xl">
            <ThemeBtn
              active={theme==="light"}
              icon={<Sun size={16} />}
              label={t("light", lang)}
              onClick={() => { setTheme("light"); setIsDarkMap(false); }}
            />
            <ThemeBtn
              active={theme==="dark"}
              icon={<Moon size={16} />}
              label={t("dark", lang)}
              onClick={() => { setTheme("dark"); setIsDarkMap(true); }}
            />
          </div>
        </Section>

        {/* Sound & Navigation */}
        <Section title={`${t("sound", lang)} & ${lang==="ar"?"الملاحة":"Navigation"}`}>
          <Toggle icon={<Volume2 size={18} color="#0A6AD6"/>}
                  label={lang==="ar"?"التوجيه الصوتي العربي":"Arabic voice guidance"}
                  value={!voiceMuted} onChange={v=>setVoiceMuted(!v)} dir={dir} />
        </Section>

        {/* Map layers */}
        <Section title={t("mapLayers", lang)}>
          <Toggle icon={<AlertTriangle size={18} color="#D62828"/>}
                  label={t("reports", lang)}
                  value={showReportsLayer} onChange={setShowReportsLayer} dir={dir} />
          <Toggle icon={<Navigation size={18} color="#0A6AD6"/>}
                  label={t("trafficLayer", lang)}
                  value={showTrafficLayer} onChange={setShowTrafficLayer} dir={dir} />
          <Toggle icon={<Moon size={18} color="#0A6AD6"/>}
                  label={t("nightMode", lang)}
                  value={isDarkMap} onChange={setIsDarkMap} dir={dir} />
        </Section>

        {/* Privacy */}
        <Section title={t("privacy", lang)}>
          <NavRow icon={<Shield size={18} color="#0A6AD6"/>}
                  label={lang==="ar"?"مركز الخصوصية":"Privacy Center"}
                  onClick={()=>setActivePanel("privacy")} lang={lang} />
          <button onClick={handleClearHistory}
                  className="flex items-center gap-3 w-full px-3 py-3 rounded-2xl hover:bg-[#F7FAFF] transition-colors"
                  dir={dir}>
            <Trash2 size={18} color={confirmClear?"#D62828":"#61738B"} />
            <span className="flex-1 text-sm"
                  style={{ fontFamily:"'Tajawal',sans-serif",
                           color: confirmClear?"#D62828":"#0B1F3A" }}>
              {confirmClear
                ? (lang==="ar"?"اضغط مجدداً للتأكيد":"Tap again to confirm")
                : t("clearHistory", lang)}
            </span>
          </button>
        </Section>

        {/* Maps & Data */}
        <Section title={lang==="ar"?"الخرائط والبيانات":"Maps & Data"}>
          <NavRow icon={<Download size={18} color="#0A6AD6"/>}
                  label={t("offlineMaps", lang)}
                  onClick={()=>setActivePanel("offline")} lang={lang} />
          <NavRow icon={<User size={18} color="#0A6AD6"/>}
                  label={t("profile", lang)}
                  onClick={()=>setActivePanel("profile")} lang={lang} />
        </Section>

        {/* Support */}
        <Section title={lang==="ar"?"الدعم والمعلومات":"Support & Info"}>
          <NavRow icon={<HelpCircle size={18} color="#0A6AD6"/>}
                  label={t("help", lang)}
                  onClick={()=>setActivePanel("help")} lang={lang} />
          <NavRow icon={<Info size={18} color="#0A6AD6"/>}
                  label={t("aboutApp", lang)}
                  onClick={()=>setActivePanel("about")} lang={lang} />
          <NavRow icon={<Star size={18} color="#0A6AD6"/>}
                  label={t("rateApp", lang)}
                  onClick={()=>waenToast.info(lang==="ar"?"شكراً! التقييم قريباً":"Thanks! Rating coming soon")}
                  lang={lang} />
        </Section>

        {/* Version */}
        <div className="text-center py-6 px-5">
          <WainLogoCompact size={32} className="mx-auto mb-2" />
          <p className="text-xs text-[#61738B]" style={{ fontFamily:"'Montserrat',sans-serif" }}>
            السحاب | CloudGps  •  v1.0.0
          </p>
          <p className="text-xs text-[#61738B] mt-0.5" style={{ fontFamily:"'Tajawal',sans-serif" }}>
            {t("madeInIraq", lang)}
          </p>
        </div>
      </div>

      <div className="safe-bottom" />
    </div>
  );
}

/* ─── Sub-components ─── */
function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="settings-section px-5 py-3 border-b">
      <p className="text-[11px] font-bold text-[#61738B] uppercase tracking-widest mb-2"
         style={{ fontFamily:"'Montserrat',sans-serif" }}>
        {title}
      </p>
      <div className="space-y-1">{children}</div>
    </div>
  );
}

function LangBtn({ active, onClick, font, label }: {
  active: boolean; onClick: () => void; font: string; label: string;
}) {
  return (
    <button onClick={onClick}
            className={`flex-1 py-2.5 rounded-xl text-sm font-bold transition-all ${
              active ? "settings-option-active shadow text-[#0A6AD6]" : "text-[#61738B]"
            }`}
            style={{ fontFamily: font }}>
      {label}
    </button>
  );
}

function ThemeBtn({ active, icon, label, onClick }: {
  active: boolean; icon: React.ReactNode; label: string; onClick: () => void;
}) {
  return (
    <button onClick={onClick}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-bold transition-all ${
              active ? "settings-option-active shadow text-[#0A6AD6]" : "text-[#61738B]"
            }`}
            style={{ fontFamily:"'Tajawal',sans-serif" }}>
      {icon}{label}
    </button>
  );
}

function Toggle({ icon, label, value, onChange, dir }: {
  icon: React.ReactNode; label: string;
  value: boolean; onChange: (v: boolean) => void; dir: string;
}) {
  return (
    <div className="flex items-center gap-3 px-2 py-2.5" dir={dir}>
      {icon}
      <span className="flex-1 text-sm text-[#0B1F3A]"
            style={{ fontFamily:"'Tajawal',sans-serif" }}>
        {label}
      </span>
      <button onClick={() => onChange(!value)} role="switch" aria-label={label} aria-checked={value}
              className={`w-12 h-6 rounded-full transition-all relative flex-shrink-0 ${
                value ? "bg-[#0A6AD6]" : "bg-[#D9E4F2]"
              }`}>
        <div className={`w-5 h-5 bg-[#F7FAFF] rounded-full shadow transition-all absolute top-0.5 ${
          value
            ? (dir==="rtl" ? "left-0.5" : "right-0.5")
            : (dir==="rtl" ? "right-0.5" : "left-0.5")
        }`} />
      </button>
    </div>
  );
}

function NavRow({ icon, label, onClick, lang }: {
  icon: React.ReactNode; label: string; onClick: () => void; lang: "ar" | "en";
}) {
  return (
    <button onClick={onClick}
            className="flex items-center gap-3 w-full px-2 py-3 rounded-2xl hover:bg-[#F7FAFF] transition-colors"
            dir={lang==="ar"?"rtl":"ltr"}>
      {icon}
      <span className="flex-1 text-sm text-[#0B1F3A] text-right"
            style={{ fontFamily:"'Tajawal',sans-serif" }}>
        {label}
      </span>
      <ChevronRight size={16} color="#61738B"
                   className={lang==="ar"?"rotate-180":""} />
    </button>
  );
}
