"use client";

import Image from "next/image";
import { cn } from "@/lib/utils";

interface WainLogoProps {
  size?: number;
  className?: string;
  showText?: boolean;
  variant?: "dark" | "light";
}

export function WainLogo({
  size = 48,
  className,
  showText = false,
}: WainLogoProps) {
  if (showText) {
    return (
      <span className={cn("inline-flex rounded-2xl bg-[#F7FAFF] p-2", className)}>
        <Image
          src="/cloudgps-lockup.png"
          alt="السحاب CloudGps"
          width={692}
          height={215}
          unoptimized
          className="h-auto w-full object-contain"
        />
      </span>
    );
  }

  return <WainLogoCompact size={size} className={className} />;
}

export function WainLogoCompact({
  size = 32,
  className,
}: {
  size?: number;
  className?: string;
}) {
  return (
    <Image
      src="/cloudgps-mark.png"
      alt="شعار السحاب CloudGps"
      width={size}
      height={size}
      unoptimized
      className={cn("shrink-0 rounded-xl object-contain", className)}
    />
  );
}
