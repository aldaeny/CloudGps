"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import {
  ArrowLeft,
  Cloud,
  Compass,
  Download,
  Mail,
  MapPin,
  Menu,
  Navigation,
  Smartphone,
  X,
} from "lucide-react";

const features = [
  {
    icon: Navigation,
    title: "ملاحة ذكية",
    description: "توجيه واضح ومسارات تساعدك على الوصول إلى وجهتك.",
  },
  {
    icon: Cloud,
    title: "تنبيهات الطريق",
    description: "تابع بلاغات المجتمع عن الحوادث ومخاطر الطريق.",
  },
  {
    icon: MapPin,
    title: "أماكن حولك",
    description: "اعثر على المطاعم ومحطات الوقود والخدمات القريبة.",
  },
  {
    icon: Smartphone,
    title: "واجهة عربية سهلة",
    description: "تجربة واضحة باللغة العربية على الهاتف والكمبيوتر.",
  },
];

const quickLinks = [
  { href: "#features", label: "المميزات" },
  { href: "#experience", label: "التطبيق" },
  { href: "#about", label: "من نحن" },
];

export function CloudGpsLandingPage() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <main className="cloudgps-landing" dir="rtl">
      <header className="cg-header">
        <div className="cg-container cg-header-inner">
          <Link href="/" aria-label="السحاب CloudGps - الصفحة الرئيسية" className="cg-brand">
            <Image
              src="/cloudgps-lockup.png"
              alt="السحاب CloudGps"
              width={692}
              height={215}
              priority
              className="cg-brand-image"
            />
          </Link>

          <nav className="cg-desktop-nav" aria-label="التنقل الرئيسي">
            {quickLinks.map((item) => (
              <a key={item.href} href={item.href} className="cg-nav-link">
                {item.label}
              </a>
            ))}
          </nav>

          <Link href="/app" className="cg-button cg-button-small cg-header-cta">
            <span>افتح التطبيق</span>
            <Download size={17} aria-hidden="true" />
          </Link>

          <button
            type="button"
            className="cg-menu-toggle"
            aria-label={menuOpen ? "إغلاق القائمة" : "فتح القائمة"}
            aria-expanded={menuOpen}
            aria-controls="cg-mobile-nav"
            onClick={() => setMenuOpen((open) => !open)}
          >
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
        {menuOpen && (
          <nav id="cg-mobile-nav" className="cg-mobile-nav" aria-label="التنقل الرئيسي">
            {quickLinks.map((item) => (
              <a key={item.href} href={item.href} onClick={() => setMenuOpen(false)}>
                {item.label}
              </a>
            ))}
            <Link href="/app" onClick={() => setMenuOpen(false)}>
              افتح التطبيق
            </Link>
          </nav>
        )}
      </header>

      <section className="cg-hero">
        <div className="cg-container cg-hero-grid">
          <div className="cg-hero-copy">
            <p className="cg-eyebrow"><Compass size={17} /> ملاحتك في العراق</p>
            <h1>
              دليلك في <span>كل طريق</span>
              <br />
              العراق بين يديك
            </h1>
            <p className="cg-hero-description">
              تطبيق خرائط وملاحة يساعدك على اكتشاف الأماكن والتخطيط لرحلتك، مع تنبيهات الطريق من مجتمع السائقين.
            </p>
            <div className="cg-hero-actions">
              <Link href="/app" className="cg-button">
                <span>ابدأ رحلتك الآن</span>
                <ArrowLeft size={18} aria-hidden="true" />
              </Link>
              <a href="#experience" className="cg-button cg-button-outline">
                شاهد التطبيق
              </a>
            </div>
            <div className="cg-hero-note">
              <span className="cg-note-dot" />
              <span>افتح السحاب مباشرة من المتصفح</span>
            </div>
          </div>

          <div className="cg-hero-visual" aria-label="خريطة توضح مسارات بين مدن العراق">
            <Image
              src="/cloudgps-route-map.png"
              alt="مسار ملاحي يربط بغداد وأربيل والموصل وكربلاء والنجف والبصرة"
              width={585}
              height={438}
              priority
              className="cg-route-map-image"
            />
          </div>
        </div>
      </section>

      <section id="features" className="cg-features-section">
        <div className="cg-container">
          <div className="cg-features-grid">
            {features.map(({ icon: Icon, title, description }) => (
              <article className="cg-feature-card" key={title}>
                <span className="cg-feature-icon"><Icon size={25} strokeWidth={2.2} /></span>
                <h3>{title}</h3>
                <p>{description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="experience" className="cg-experience-section">
        <div className="cg-container cg-experience-grid">
          <div className="cg-experience-copy">
            <p className="cg-eyebrow">السحاب CloudGps</p>
            <h2>رفيقك في <span>كل رحلة</span></h2>
            <p>
              ابحث عن وجهتك، استعرض الطريق، وابدأ الملاحة من واجهة عربية بسيطة. جرّب التطبيق الآن من المتصفح.
            </p>
            <Link href="/app" className="cg-button">
              <span>افتح الخريطة</span>
              <ArrowLeft size={18} aria-hidden="true" />
            </Link>
          </div>
          <div className="cg-phone-showcase">
            <Image
              src="/cloudgps-app-phones.png"
              alt="ثلاث شاشات من تطبيق السحاب للملاحة والبحث عن الأماكن"
              width={544}
              height={358}
              className="cg-phone-image"
            />
          </div>
        </div>
      </section>

      <footer className="cg-footer">
        <div className="cg-container cg-footer-grid">
          <div id="about" className="cg-footer-brand-block">
            <Link href="/" className="cg-footer-brand" aria-label="السحاب CloudGps">
              <Image
                src="/cloudgps-lockup.png"
                alt="السحاب CloudGps"
                width={692}
                height={215}
                className="cg-footer-logo"
              />
            </Link>
            <p>تطبيق ملاحة ذكي يساعدك على اكتشاف الطرق والأماكن في العراق.</p>
          </div>

          <div className="cg-footer-column">
            <h3>روابط سريعة</h3>
            <a href="#features">المميزات</a>
            <a href="#experience">التطبيق</a>
            <a href="#about">من نحن</a>
          </div>

          <div className="cg-footer-column">
            <h3>خدمات السحاب</h3>
            <a href="#features">الملاحة الذكية</a>
            <a href="#features">البحث عن الأماكن</a>
            <a href="#features">تنبيهات الطريق</a>
          </div>

          <div className="cg-footer-column cg-contact-column">
            <h3>تواصل معنا</h3>
            <a href="mailto:aldaeny60@gmail.com" className="cg-contact-link">
              <Mail size={16} />
              aldaeny60@gmail.com
            </a>
            <span className="cg-contact-link"><MapPin size={16} /> بغداد، العراق</span>
          </div>
        </div>
        <div className="cg-container cg-footer-bottom">
          <span>© {new Date().getFullYear()} السحاب CloudGps — جميع الحقوق محفوظة</span>
          <Link href="/app">افتح التطبيق <ArrowLeft size={15} /></Link>
        </div>
      </footer>
    </main>
  );
}
