"use client";
import { X, Shield, Eye, MapPin, Database, Trash2, FileText, ChevronDown } from "lucide-react";
import { useState } from "react";
import { useAppStore } from "@/store/useAppStore";
import { t } from "@/lib/translations";
import { getSessionId } from "@/lib/utils";
import { waenToast } from "@/lib/toast";

interface FAQItem { q: string; a: string; }

export function PrivacyPanel() {
  const { language, setActivePanel, clearRecentDestinations } = useAppStore();
  const lang = language;
  const dir  = lang === "ar" ? "rtl" : "ltr";

  const [openFAQ, setOpenFAQ] = useState<number | null>(null);
  const [deleting, setDeleting] = useState(false);

  const faqs: FAQItem[] = lang === "ar" ? [
    { q:"هل يتتبع السحاب تحركاتي باستمرار؟",
      a:"لا. يُستخدم GPS فقط أثناء الملاحة النشطة. لا يُخزَّن تاريخ حركتك التفصيلي على خوادمنا." },
    { q:"من يرى بلاغاتي المرورية؟",
      a:"البلاغات مجهولة تماماً. لا يظهر اسمك أو موقعك الدقيق لأي مستخدم آخر." },
    { q:"هل تُشارَك بياناتي مع جهات خارجية؟",
      a:"لا نبيع بيانات المستخدمين. نستخدم خدمات OpenStreetMap وOSRM المفتوحة المصدر لبيانات الخرائط والتوجيه." },
    { q:"كيف أحذف بياناتي كاملاً؟",
      a:"اضغط على 'حذف جميع بياناتي' أدناه. سيُحذف سجل رحلاتك وبلاغاتك وأماكنك المحفوظة فوراً." },
    { q:"ما البيانات المخزّنة محلياً على جهازي؟",
      a:"يتم حفظ إعداداتك والأماكن المفضلة وسجل الوجهات الأخيرة في ذاكرة المتصفح المحلية." },
  ] : [
    { q:"Does CloudGps track my movements continuously?",
      a:"No. GPS is only used during active navigation. Your detailed movement history is not stored on our servers." },
    { q:"Who sees my traffic reports?",
      a:"Reports are fully anonymous. Your name or exact location is never shown to other users." },
    { q:"Is my data shared with third parties?",
      a:"We do not sell user data. We use open-source OpenStreetMap and OSRM services for map and routing data." },
    { q:"How do I delete all my data?",
      a:"Tap 'Delete All My Data' below. Your trip history, reports, and saved places will be deleted immediately." },
    { q:"What data is stored locally on my device?",
      a:"Your settings, favorite places, and recent destinations are saved in local browser storage." },
  ];

  async function deleteAllData() {
    setDeleting(true);
    try {
      const sid = getSessionId();
      await fetch(`/api/trips?sessionId=${sid}`, { method: "DELETE" });
      clearRecentDestinations();
      useAppStore.getState().setSavedPlaces([]);
      localStorage.removeItem("waen_display_name");
      localStorage.removeItem("waen_offline_regions");
      waenToast.success(lang === "ar" ? "تم حذف جميع بياناتك" : "All your data has been deleted");
      setActivePanel("home");
    } catch {
      waenToast.error(t("serverError", lang));
    } finally { setDeleting(false); }
  }

  return (
    <div className="bg-[#F7FAFF] rounded-t-3xl shadow-2xl max-h-[88vh] flex flex-col" dir={dir}>
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-[#D9E4F2] flex-shrink-0">
        <h2 className="text-lg font-black text-[#0B1F3A]" style={{ fontFamily:"'Tajawal',sans-serif" }}>
          {t("privacy", lang)}
        </h2>
        <button onClick={() => setActivePanel("settings")}
                className="p-2 rounded-full hover:bg-[#F7FAFF]">
          <X size={20} color="#61738B" />
        </button>
      </div>

      <div className="overflow-y-auto flex-1 scrollbar-thin">
        {/* Hero */}
        <div className="bg-gradient-to-b from-[#0A6AD6]/5 to-white px-5 py-6 text-center">
          <div className="w-16 h-16 rounded-full bg-[#0A6AD6]/10 flex items-center justify-center mx-auto mb-3">
            <Shield size={32} color="#0A6AD6" />
          </div>
          <p className="font-black text-lg text-[#0B1F3A]" style={{ fontFamily:"'Tajawal',sans-serif" }}>
            {lang === "ar" ? "خصوصيتك أولويتنا" : "Your privacy is our priority"}
          </p>
          <p className="text-sm text-[#61738B] mt-1 max-w-xs mx-auto" style={{ fontFamily:"'Tajawal',sans-serif" }}>
            {lang === "ar"
              ? "السحاب يطبّق مبدأ الحد الأدنى من جمع البيانات"
              : "CloudGps applies data minimization principles"}
          </p>
        </div>

        {/* Data items */}
        <div className="px-5 space-y-3 mb-4">
          <p className="text-xs font-bold text-[#61738B] uppercase tracking-wider"
             style={{ fontFamily:"'Montserrat',sans-serif" }}>
            {lang === "ar" ? "البيانات التي نجمعها" : "Data we collect"}
          </p>
          {[
            { icon:<MapPin size={16} color="#0A6AD6"/>, label: lang==="ar"?"موقع GPS (فقط أثناء الملاحة)":"GPS location (only during navigation)", safe:true },
            { icon:<FileText size={16} color="#0A6AD6"/>, label: lang==="ar"?"بلاغات مرورية مجهولة":"Anonymous traffic reports", safe:true },
            { icon:<Database size={16} color="#0A6AD6"/>, label: lang==="ar"?"أماكن محفوظة وسجل وجهات (محلي)":"Saved places & history (local only)", safe:true },
            { icon:<Eye size={16} color="#61738B"/>, label: lang==="ar"?"لا نجمع: الاسم، البريد، أو سجل حركة مستمر":"NOT collected: name, email, or continuous tracking", safe:false },
          ].map((item, i) => (
            <div key={i} className="flex items-center gap-3 bg-[#F7FAFF] rounded-xl p-3">
              {item.icon}
              <span className="text-sm flex-1"
                    style={{ fontFamily:"'Tajawal',sans-serif",
                             color: item.safe ? "#0B1F3A" : "#61738B" }}>
                {item.label}
              </span>
              {item.safe
                ? <span className="text-blue-500 text-lg">✓</span>
                : <span className="text-[#D62828] text-lg">✗</span>}
            </div>
          ))}
        </div>

        {/* FAQ */}
        <div className="px-5 mb-4">
          <p className="text-xs font-bold text-[#61738B] uppercase tracking-wider mb-3"
             style={{ fontFamily:"'Montserrat',sans-serif" }}>
            {lang === "ar" ? "أسئلة شائعة" : "FAQ"}
          </p>
          <div className="space-y-2">
            {faqs.map((faq, i) => (
              <div key={i} className="card overflow-hidden">
                <button className="flex items-center justify-between w-full px-4 py-3 text-right"
                        dir={dir}
                        onClick={() => setOpenFAQ(openFAQ === i ? null : i)}>
                  <span className="font-bold text-sm text-[#0B1F3A] flex-1"
                        style={{ fontFamily:"'Tajawal',sans-serif" }}>
                    {faq.q}
                  </span>
                  <ChevronDown size={16} color="#61738B"
                               style={{ transform: openFAQ === i ? "rotate(180deg)" : "none",
                                        transition:"transform 0.2s" }} />
                </button>
                {openFAQ === i && (
                  <div className="px-4 pb-3 border-t border-[#D9E4F2]">
                    <p className="text-sm text-[#61738B] mt-2 leading-relaxed"
                       style={{ fontFamily:"'Tajawal',sans-serif" }}>
                      {faq.a}
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Delete all */}
        <div className="px-5 mb-6">
          <div className="bg-red-50 border border-red-200 rounded-2xl p-4">
            <p className="font-bold text-[#D62828] mb-1" style={{ fontFamily:"'Tajawal',sans-serif" }}>
              {t("deleteAccount", lang)}
            </p>
            <p className="text-xs text-red-400 mb-3" style={{ fontFamily:"'Tajawal',sans-serif" }}>
              {lang === "ar"
                ? "سيتم حذف جميع بياناتك المخزّنة على الخادم وجهازك. هذا الإجراء لا يمكن التراجع عنه."
                : "All your data stored on the server and device will be deleted. This action cannot be undone."}
            </p>
            <button onClick={deleteAllData} disabled={deleting}
                    className="btn btn-danger w-full text-sm">
              {deleting
                ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                : <><Trash2 size={16} /> {lang === "ar" ? "حذف جميع بياناتي" : "Delete All My Data"}</>}
            </button>
          </div>
        </div>
      </div>
      <div className="safe-bottom" />
    </div>
  );
}
