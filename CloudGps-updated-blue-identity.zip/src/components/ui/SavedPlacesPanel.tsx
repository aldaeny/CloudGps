"use client";
import { Home, Briefcase, Star, Trash2, MapPin, X, Navigation, Plus } from "lucide-react";
import { useAppStore } from "@/store/useAppStore";
import { t } from "@/lib/translations";

export function SavedPlacesPanel() {
  const {
    language,
    savedPlaces,
    removeSavedPlace,
    setActivePanel,
    setDestination,
    userLocation,
    setOrigin,
  } = useAppStore();

  const lang = language;
  const dir = lang === "ar" ? "rtl" : "ltr";

  const categoryIcons = {
    home: <Home size={18} color="#0A6AD6" />,
    work: <Briefcase size={18} color="#0A6AD6" />,
    favorite: <Star size={18} color="#D62828" />,
    custom: <MapPin size={18} color="#0A6AD6" />,
  };

  const categoryColors = {
    home: "#0A6AD6",
    work: "#0A6AD6",
    favorite: "#D62828",
    custom: "#61738B",
  };

  function handleNavigateTo(place: { name: string; nameAr?: string; lat: number; lng: number }) {
    setDestination({
      name: lang === "ar" ? (place.nameAr ?? place.name) : place.name,
      location: { lat: place.lat, lng: place.lng },
    });
    if (userLocation) {
      setOrigin({ name: t("myLocation", lang), location: userLocation });
    }
    setActivePanel("route-preview");
  }

  return (
    <div className="bg-[#F7FAFF] rounded-t-3xl shadow-2xl pb-8 max-h-[80vh] overflow-y-auto" dir={dir}>
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-[#D9E4F2] sticky top-0 bg-[#F7FAFF] rounded-t-3xl z-10">
        <h2 className="text-lg font-bold text-[#0B1F3A]" style={{ fontFamily: "'Tajawal', sans-serif" }}>
          {t("savedPlaces", lang)}
        </h2>
        <button onClick={() => setActivePanel("home")} className="p-2 rounded-full hover:bg-[#F7FAFF] transition-colors">
          <X size={20} color="#61738B" />
        </button>
      </div>

      {/* Empty state */}
      {savedPlaces.length === 0 && (
        <div className="flex flex-col items-center py-12 px-4">
          <div className="text-6xl mb-4">📍</div>
          <p className="text-lg font-bold text-[#0B1F3A] mb-2" style={{ fontFamily: "'Tajawal', sans-serif" }}>
            {lang === "ar" ? "لا توجد أماكن محفوظة" : "No saved places"}
          </p>
          <p className="text-sm text-[#61738B] text-center" style={{ fontFamily: "'Tajawal', sans-serif" }}>
            {lang === "ar"
              ? "ابحث عن مكان وأضفه للمفضلة"
              : "Search for a place and add it to favorites"}
          </p>
        </div>
      )}

      {/* Places list */}
      <div>
        {savedPlaces.map((place) => (
          <div
            key={place.id}
            className="flex items-center gap-3 px-5 py-4 border-b border-[#D9E4F2] last:border-0"
            dir={dir}
          >
            <div
              className="w-10 h-10 rounded-2xl flex items-center justify-center flex-shrink-0"
              style={{ backgroundColor: (categoryColors[place.category as keyof typeof categoryColors] ?? "#61738B") + "20" }}
            >
              {categoryIcons[place.category as keyof typeof categoryIcons] ?? categoryIcons.custom}
            </div>

            <div className="flex-1 min-w-0">
              <p className="font-bold text-sm text-[#0B1F3A] truncate" style={{ fontFamily: "'Tajawal', sans-serif" }}>
                {lang === "ar" ? (place.nameAr ?? place.name) : place.name}
              </p>
              {place.address && (
                <p className="text-xs text-[#61738B] truncate" style={{ fontFamily: "'Tajawal', sans-serif" }}>
                  {place.address.split(",").slice(0, 2).join("، ")}
                </p>
              )}
            </div>

            <div className="flex items-center gap-1 flex-shrink-0">
              <button
                onClick={() => handleNavigateTo(place)}
                className="p-2 hover:bg-[#F7FAFF] rounded-xl transition-colors"
                aria-label={t("directions", lang)}
              >
                <Navigation size={18} color="#0A6AD6" />
              </button>
              <button
                onClick={() => removeSavedPlace(place.id)}
                className="p-2 hover:bg-red-50 rounded-xl transition-colors"
                aria-label={t("delete", lang)}
              >
                <Trash2 size={18} color="#D62828" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Tip */}
      {savedPlaces.length > 0 && (
        <p className="text-xs text-center text-[#61738B] py-4 px-5" style={{ fontFamily: "'Tajawal', sans-serif" }}>
          {lang === "ar" ? "اضغط على 🧭 للانتقال إلى المكان" : "Tap 🧭 to navigate to a place"}
        </p>
      )}
    </div>
  );
}
