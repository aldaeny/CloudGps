"use client";
import { useState, useEffect, useRef } from "react";
import { Search, X, Clock, MapPin, Home, Briefcase, Mic, Navigation2 } from "lucide-react";
import { useAppStore } from "@/store/useAppStore";
import { t } from "@/lib/translations";
import type { Place } from "@/types";
import { cn } from "@/lib/utils";

const CATS = [
  { key: "hospitals", icon: "🏥", q: "مستشفى" },
  { key: "fuelStations", icon: "⛽", q: "محطة وقود" },
  { key: "restaurants", icon: "🍽️", q: "مطعم" },
  { key: "pharmacies", icon: "💊", q: "صيدلية" },
  { key: "mosques", icon: "🕌", q: "مسجد" },
  { key: "atm", icon: "🏧", q: "صراف" },
  { key: "baghdadAreas", icon: "🗺️", q: "أحياء بغداد" },
];

export function SearchPanel() {
  const {
    language, searchQuery, searchResults, isSearching,
    recentDestinations, savedPlaces, userLocation,
    setSearchQuery, setSearchResults, setIsSearching,
    setSelectedPlace, setActivePanel, setDestination, setOrigin,
  } = useAppStore();

  const [focused, setFocused] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const lang = language;

  useEffect(() => {
    const controller = new AbortController();
    const timer = window.setTimeout(async () => {
      const query = searchQuery.trim();
      if (query.length < 2) {
        setSearchResults([]);
        setIsSearching(false);
        return;
      }
      setIsSearching(true);
      try {
        const params = new URLSearchParams({ q: query, limit: "20" });
        if (userLocation) {
          params.set("lat", String(userLocation.lat));
          params.set("lng", String(userLocation.lng));
        }
        const response = await fetch(`/api/places/search?${params}`, { signal: controller.signal });
        if (!response.ok) throw new Error("Search failed");
        const data = await response.json();
        setSearchResults(data.places ?? []);
      } catch (error) {
        if (!(error instanceof DOMException && error.name === "AbortError")) setSearchResults([]);
      } finally {
        if (!controller.signal.aborted) setIsSearching(false);
      }
    }, 350);
    return () => { window.clearTimeout(timer); controller.abort(); };
  }, [searchQuery, userLocation, setSearchResults, setIsSearching]);

  function pick(place: Place) {
    setSelectedPlace(place);
    setDestination({ name: place.nameAr ?? place.name, location: { lat: place.lat, lng: place.lng } });
    setSearchQuery(place.nameAr ?? place.name);
    setFocused(false);
    inputRef.current?.blur();
    setActivePanel("place");
  }

  function pickRecent(d: { name: string; location: { lat: number; lng: number } }) {
    setDestination(d);
    if (userLocation) setOrigin({ name: t("myLocation", lang), location: userLocation });
    setActivePanel("route-preview");
  }

  function voiceSearch() {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) return;
    const r = new SR();
    r.lang = lang === "ar" ? "ar-IQ" : "en-US";
    r.onresult = (e: any) => { const txt = e.results[0]?.[0]?.transcript; if (txt) { setSearchQuery(txt); inputRef.current?.focus(); } };
    r.start();
  }

  const showDrop = focused && (
    searchResults.length > 0 || isSearching ||
    (searchQuery.length === 0 && (recentDestinations.length > 0 || savedPlaces.length > 0))
  );

  return (
    <div className="relative w-full">
      {/* ── Search Bar ── */}
      <div className={cn(
        "flex items-center gap-3 px-4 h-[52px] rounded-[18px] transition-all duration-300",
        focused ? "bg-[#F7FAFF] shadow-xl ring-2 ring-[#0A6AD6]/15" : "glass shadow-lg"
      )}>
        <Search size={20} color={focused ? "#0A6AD6" : "#61738B"} className="flex-shrink-0" strokeWidth={2} />

        <input
          ref={inputRef}
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          onFocus={() => setFocused(true)}
          onBlur={() => setTimeout(() => setFocused(false), 250)}
          placeholder={t("searchPlaceholder", lang)}
          className="flex-1 bg-transparent outline-none text-[15px] font-bold text-[#0B1F3A] placeholder:text-[#61738B] placeholder:font-medium"
          autoComplete="off"
        />

        <div className="flex items-center gap-1.5">
          {isSearching ? (
            <div className="w-5 h-5 border-2 border-[#0A6AD6] border-t-transparent rounded-full animate-spin" />
          ) : searchQuery ? (
            <button onClick={() => { setSearchQuery(""); setSearchResults([]); inputRef.current?.focus(); }}
                    className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-black/5 transition-colors">
              <X size={18} color="#61738B" strokeWidth={2} />
            </button>
          ) : (
            <button onClick={voiceSearch}
                    className="w-8 h-8 rounded-full flex items-center justify-center bg-[#0A6AD6]/8 hover:bg-[#0A6AD6]/15 transition-colors">
              <Mic size={17} color="#0A6AD6" strokeWidth={2} />
            </button>
          )}
        </div>
      </div>

      {/* ── Dropdown ── */}
      {showDrop && (
        <div className="absolute top-full mt-2 left-0 right-0 z-50 rounded-[22px] overflow-hidden shadow-2xl animate-fade-in glass-heavy"
             style={{ maxHeight:"55vh", overflowY:"auto" }}>

          {/* Categories */}
          {searchQuery.length === 0 && (
            <div className="flex gap-2 p-3 overflow-x-auto scrollbar-hide border-b border-black/5">
              {CATS.map(c => (
                <button key={c.key}
                        onClick={() => setSearchQuery(c.q)}
                        className="flex items-center gap-2 flex-shrink-0 px-4 py-2 rounded-full active:scale-95 transition-all"
                        style={{ background:"rgba(10,106,214,0.07)" }}>
                  <span className="text-sm leading-none">{c.icon}</span>
                  <span className="text-[13px] font-bold text-[#0A6AD6] leading-none">
                    {t(c.key as Parameters<typeof t>[0], lang)}
                  </span>
                </button>
              ))}
            </div>
          )}

          {/* Results */}
          {searchQuery.length >= 2 && searchResults.map(p => (
            <button key={p.id} onClick={() => pick(p)}
                    className="flex items-center gap-3 w-full px-4 py-3.5 hover:bg-[#0A6AD6]/5 border-b border-black/[0.03] last:border-0 transition-colors"
                    dir="rtl">
              <div className="w-11 h-11 rounded-2xl bg-[#0A6AD6]/8 flex items-center justify-center flex-shrink-0">
                <MapPin size={18} color="#0A6AD6" strokeWidth={2} />
              </div>
              <div className="flex-1 min-w-0 text-right">
                <p className="font-extrabold text-[14px] text-[#0B1F3A] truncate leading-snug">
                  {p.nameAr || p.name}
                </p>
                {p.address && (
                  <p className="text-[12px] text-[#61738B] truncate mt-0.5 font-medium leading-snug">
                    {p.address.split(",").slice(0, 3).join("، ")}
                  </p>
                )}
              </div>
              <Navigation2 size={14} color="#D9E4F2" className="flex-shrink-0" />
            </button>
          ))}

          {/* No results */}
          {searchQuery.length >= 2 && !isSearching && searchResults.length === 0 && (
            <div className="py-10 text-center">
              <p className="text-3xl mb-2">🔍</p>
              <p className="text-[#61738B] text-[14px] font-bold">{t("noResults", lang)}</p>
              <p className="text-[12px] text-[#D9E4F2] mt-1 font-medium">
                {lang === "ar" ? "جرّب كلمات مختلفة أو اضغط على الخريطة" : "Try different words or tap the map"}
              </p>
            </div>
          )}

          {/* Saved + Recent */}
          {searchQuery.length === 0 && savedPlaces.filter(p => ["home","work"].includes(p.category)).map(pl => (
            <button key={pl.id} onClick={() => pickRecent({ name: pl.nameAr ?? pl.name, location: { lat: pl.lat, lng: pl.lng } })}
                    className="flex items-center gap-3 w-full px-4 py-3.5 hover:bg-[#0A6AD6]/5 border-b border-black/[0.03] transition-colors" dir="rtl">
              <div className="w-11 h-11 rounded-2xl bg-[#0A6AD6] flex items-center justify-center flex-shrink-0 shadow-md">
                {pl.category === "home" ? <Home size={17} color="white" strokeWidth={2} /> : <Briefcase size={17} color="white" strokeWidth={2} />}
              </div>
              <div className="flex-1 text-right">
                <p className="font-extrabold text-[14px] text-[#0B1F3A] leading-snug">
                  {pl.category === "home" ? t("home", lang) : t("work", lang)}
                </p>
                <p className="text-[12px] text-[#61738B] font-medium mt-0.5 leading-snug">{pl.nameAr || pl.name}</p>
              </div>
            </button>
          ))}
          {searchQuery.length === 0 && recentDestinations.slice(0, 4).map((d, i) => (
            <button key={i} onClick={() => pickRecent(d)}
                    className="flex items-center gap-3 w-full px-4 py-3.5 hover:bg-[#0A6AD6]/5 border-b border-black/[0.03] last:border-0 transition-colors" dir="rtl">
              <div className="w-11 h-11 rounded-2xl bg-[#F7FAFF] flex items-center justify-center flex-shrink-0 border border-[#D9E4F2]">
                <Clock size={17} color="#61738B" strokeWidth={2} />
              </div>
              <div className="flex-1 text-right min-w-0">
                <p className="font-extrabold text-[14px] text-[#0B1F3A] truncate leading-snug">{d.name}</p>
              </div>
              <Navigation2 size={14} color="#D9E4F2" className="flex-shrink-0" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
