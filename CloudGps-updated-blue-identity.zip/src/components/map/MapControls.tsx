"use client";
import { useState } from "react";
import { Layers, Moon, Sun, AlertTriangle, Plus, ZoomIn, ZoomOut, Crosshair, X } from "lucide-react";
import { useAppStore } from "@/store/useAppStore";
import { t } from "@/lib/translations";

interface Props { onZoomIn?: () => void; onZoomOut?: () => void; onCenterUser?: () => void; }

export function MapControls({ onZoomIn, onZoomOut, onCenterUser }: Props) {
  const {
    language, isDarkMap, showReportsLayer, locationStatus, navigation,
    setIsDarkMap, setShowReportsLayer, setActivePanel,
  } = useAppStore();
  const [layers, setLayers] = useState(false);
  const lang = language;

  if (navigation.status === "active" || navigation.status === "rerouting") return null;

  return (
    <div className="flex flex-col gap-3">
      {/* Zoom — Glass */}
      <div className="glass rounded-[18px] overflow-hidden shadow-lg">
        <button onClick={onZoomIn}
                className="flex items-center justify-center w-12 h-12 hover:bg-black/5 border-b border-black/5 transition-colors active:scale-90">
          <ZoomIn size={20} color="#0B1F3A" strokeWidth={2} />
        </button>
        <button onClick={onZoomOut}
                className="flex items-center justify-center w-12 h-12 hover:bg-black/5 transition-colors active:scale-90">
          <ZoomOut size={20} color="#0B1F3A" strokeWidth={2} />
        </button>
      </div>

      {/* Location */}
      <button onClick={onCenterUser}
              className="glass w-12 h-12 rounded-[18px] flex items-center justify-center shadow-lg active:scale-90 transition-transform">
        <Crosshair size={20} color={locationStatus === "success" ? "#0A6AD6" : "#61738B"} strokeWidth={2} />
      </button>

      {/* Layers */}
      <div className="relative">
        <button onClick={() => setLayers(!layers)}
                className="w-12 h-12 rounded-[18px] flex items-center justify-center shadow-lg active:scale-90 transition-transform"
                style={layers
                  ? { background: "#0A6AD6" }
                  : { background: "rgba(255,255,255,0.72)", backdropFilter: "blur(20px) saturate(180%)", WebkitBackdropFilter: "blur(20px) saturate(180%)", border: "1px solid rgba(255,255,255,0.45)" }
                }>
          <Layers size={20} color={layers ? "white" : "#0B1F3A"} strokeWidth={2} />
        </button>

        {layers && (
          <div className="absolute bottom-0 rounded-[18px] p-3 w-52 z-50 shadow-2xl animate-fade-in glass-heavy"
               style={{ [lang === "ar" ? "right" : "left"]: "calc(100% + 12px)" }}>
            <div className="flex items-center justify-between mb-2 px-1">
              <span className="label-text">{t("mapLayers", lang)}</span>
              <button onClick={() => setLayers(false)} className="active:scale-90 transition-transform">
                <X size={14} color="#61738B" strokeWidth={3} />
              </button>
            </div>
            <LayerRow icon={isDarkMap ? <Sun size={18} strokeWidth={2} /> : <Moon size={18} strokeWidth={2} />}
                      label={isDarkMap ? t("dayMode", lang) : t("nightMode", lang)}
                      active={isDarkMap} onClick={() => setIsDarkMap(!isDarkMap)} />
            <LayerRow icon={<AlertTriangle size={18} strokeWidth={2} />}
                      label={t("reports", lang)}
                      active={showReportsLayer} onClick={() => setShowReportsLayer(!showReportsLayer)} red />
          </div>
        )}
      </div>

      {/* Report */}
      <button onClick={() => { setLayers(false); setActivePanel("create-report"); }}
              className="w-12 h-12 rounded-full flex items-center justify-center shadow-xl active:scale-90 transition-transform"
              style={{ background: "linear-gradient(135deg, #D62828 0%, #c03838 100%)" }}>
        <Plus size={22} color="white" strokeWidth={3} />
      </button>
    </div>
  );
}

function LayerRow({ icon, label, active, onClick, red }: {
  icon: React.ReactNode; label: string; active: boolean; onClick: () => void; red?: boolean;
}) {
  const color = red ? (active ? "#D62828" : "#61738B") : "#0A6AD6";
  return (
    <button onClick={onClick}
            className="flex items-center gap-3 w-full px-2 py-2.5 rounded-xl hover:bg-black/5 transition-colors active:scale-[0.98]"
            dir="rtl">
      <div style={{ color }}>{icon}</div>
      <span className="text-[13px] font-bold flex-1 text-right" style={{ color: active ? color : "#61738B" }}>
        {label}
      </span>
      <div className={`w-9 h-5 rounded-full transition-all relative ${active ? "bg-[#0A6AD6]" : "bg-[#D9E4F2]"}`}>
        <div className={`w-4 h-4 bg-[#F7FAFF] rounded-full shadow-sm absolute top-0.5 transition-all ${active ? "right-0.5" : "left-0.5"}`} />
      </div>
    </button>
  );
}
