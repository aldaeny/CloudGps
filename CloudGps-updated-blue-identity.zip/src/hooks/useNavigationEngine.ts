"use client";
import { useEffect, useRef, useCallback } from "react";
import { useAppStore } from "@/store/useAppStore";
import { haversineDistance, formatDistance } from "@/lib/utils";
import { t } from "@/lib/translations";

const OFF_ROUTE_METERS = 60;
const REROUTE_METERS   = 120;
const ARRIVAL_METERS   = 35;
const ANNOUNCE_METERS  = 250;
const ANNOUNCE_NEAR    = 80;

export function useNavigationEngine() {
  const {
    language,
    navigation,
    userLocation,
    destination,
    voiceMuted,
    setNavigation,
    resetNavigation,
  } = useAppStore();

  const lang = language;
  const lastAnnouncedStep = useRef<number>(-1);
  const rerouting = useRef(false);
  const synthRef   = useRef<SpeechSynthesisUtterance | null>(null);

  /* ── Voice ── */
  const speak = useCallback(
    (text: string, force = false) => {
      if (voiceMuted && !force) return;
      if (!("speechSynthesis" in window)) return;
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang  = lang === "ar" ? "ar-SA" : "en-US";
      u.rate  = 0.92;
      u.pitch = 1.05;
      u.volume = 1;
      synthRef.current = u;
      window.speechSynthesis.speak(u);
    },
    [voiceMuted, lang]
  );

  /* ── Main tracking loop ── */
  useEffect(() => {
    if (!userLocation) return;
    if (navigation.status !== "active" && navigation.status !== "rerouting") return;
    if (!navigation.route) return;

    const { route, currentStepIndex } = navigation;
    const steps = route.steps;
    const geom  = route.geometry;

    /* arrival check */
    const destPt = destination?.location ?? geom[geom.length - 1];
    if (!destPt) return;
    const distToDest = haversineDistance(
      userLocation.lat, userLocation.lng,
      destPt.lat, destPt.lng
    );
    if (distToDest < ARRIVAL_METERS) {
      setNavigation({ status: "arrived", distanceRemaining: 0, timeRemaining: 0 });
      speak(t("arrived", lang), true);
      return;
    }

    /* closest geometry point */
    let closestDist = Infinity;
    let closestIdx  = 0;
    for (let i = 0; i < geom.length; i++) {
      const d = haversineDistance(userLocation.lat, userLocation.lng, geom[i]!.lat, geom[i]!.lng);
      if (d < closestDist) { closestDist = d; closestIdx = i; }
    }

    /* off-route / reroute */
    if (closestDist > REROUTE_METERS && !rerouting.current) {
      rerouting.current = true;
      setNavigation({ isOffRoute: true, status: "rerouting" });
      speak(t("recalculating", lang));

      /* Try to recalculate from current position */
      const origin = { lat: userLocation.lat, lng: userLocation.lng };
      const dest   = destination?.location ?? destPt;
      fetch(`/api/routing?originLat=${origin.lat}&originLng=${origin.lng}&destLat=${dest.lat}&destLng=${dest.lng}&alternatives=false`)
        .then(r => r.json())
        .then(data => {
          if (data.routes?.[0]) {
            const newRoute = data.routes[0];
            setNavigation({
              route: newRoute,
              currentStepIndex: 0,
              distanceToNextStep: newRoute.steps[0]?.distance ?? 0,
              distanceRemaining: newRoute.distance,
              timeRemaining: newRoute.duration,
              currentStreetName: newRoute.steps[0]?.name ?? "",
              isOffRoute: false,
              status: "active",
              eta: new Date(Date.now() + newRoute.duration * 1000),
            });
            lastAnnouncedStep.current = -1;
          } else {
            setNavigation({ status: "active", isOffRoute: true });
          }
        })
        .catch(() => setNavigation({ status: "active", isOffRoute: false }))
        .finally(() => { rerouting.current = false; });
      return;
    }

    if (closestDist <= OFF_ROUTE_METERS && navigation.isOffRoute) {
      setNavigation({ isOffRoute: false, status: "active" });
    }

    /* find current step */
    let bestStep = currentStepIndex;
    let bestDist = Infinity;
    const maxLook = Math.min(steps.length, currentStepIndex + 5);
    for (let i = currentStepIndex; i < maxLook; i++) {
      const s = steps[i];
      if (!s) continue;
      const d = haversineDistance(userLocation.lat, userLocation.lng, s.coordinates.lat, s.coordinates.lng);
      if (d < bestDist) { bestDist = d; bestStep = i; }
    }

    const currentStep = steps[bestStep];
    if (!currentStep) return;

    const distToStep = haversineDistance(
      userLocation.lat, userLocation.lng,
      currentStep.coordinates.lat, currentStep.coordinates.lng
    );

    /* announce */
    if (bestStep !== lastAnnouncedStep.current) {
      if (distToStep < ANNOUNCE_METERS) {
        const instrAr = currentStep.instructionAr || currentStep.instruction;
        const dist    = formatDistance(distToStep, "ar");
        if (distToStep < ANNOUNCE_NEAR) {
          speak(instrAr);
        } else {
          speak(`${instrAr}، بعد ${dist}`);
        }
        lastAnnouncedStep.current = bestStep;
      }
    }

    /* remaining distance (sum from closest geom point) */
    let distRemaining = 0;
    for (let i = closestIdx; i < geom.length - 1; i++) {
      distRemaining += haversineDistance(
        geom[i]!.lat, geom[i]!.lng,
        geom[i + 1]!.lat, geom[i + 1]!.lng
      );
    }
    const speedMs = 11.1; // ~40 km/h city
    const timeRem = distRemaining / speedMs;

    setNavigation({
      currentStepIndex: bestStep,
      distanceToNextStep: distToStep,
      distanceRemaining: distRemaining,
      timeRemaining: timeRem,
      currentStreetName: currentStep.name || steps[bestStep + 1]?.name || "",
      eta: new Date(Date.now() + timeRem * 1000),
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userLocation]);

  const stopNavigation = useCallback(() => {
    window.speechSynthesis?.cancel();
    lastAnnouncedStep.current = -1;
    rerouting.current = false;
    resetNavigation();
  }, [resetNavigation]);

  return { speak, stopNavigation };
}
