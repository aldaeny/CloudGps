"use client";
import { useEffect, useRef, useCallback } from "react";
import { useAppStore } from "@/store/useAppStore";
import { t } from "@/lib/translations";
import { waenToast } from "@/lib/toast";

export function useLocation() {
  const {
    language,
    setUserLocation,
    setLocationStatus,
    locationStatus,
  } = useAppStore();

  const watchIdRef = useRef<number | null>(null);
  const lang = language;

  const startWatching = useCallback(() => {
    if (!navigator.geolocation) {
      setLocationStatus("error");
      waenToast.error(t("locationUnavailable", lang));
      return;
    }

    setLocationStatus("loading");

    watchIdRef.current = navigator.geolocation.watchPosition(
      (pos) => {
        setUserLocation(
          { lat: pos.coords.latitude, lng: pos.coords.longitude },
          pos.coords.accuracy
        );
      },
      (err) => {
        if (err.code === err.PERMISSION_DENIED) {
          setLocationStatus("denied");
        } else if (err.code === err.POSITION_UNAVAILABLE) {
          setLocationStatus("error");
        } else {
          setLocationStatus("error");
        }
      },
      { enableHighAccuracy: true, timeout: 20000, maximumAge: 5000 }
    );
  }, [lang, setUserLocation, setLocationStatus]);

  const stopWatching = useCallback(() => {
    if (watchIdRef.current !== null) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }
  }, []);

  const requestOnce = useCallback(() => {
    if (!navigator.geolocation) return;
    setLocationStatus("loading");
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setUserLocation(
          { lat: pos.coords.latitude, lng: pos.coords.longitude },
          pos.coords.accuracy
        );
      },
      () => setLocationStatus("denied"),
      { enableHighAccuracy: true, timeout: 10000 }
    );
  }, [setUserLocation, setLocationStatus]);

  useEffect(() => {
    startWatching();
    return () => stopWatching();
  }, [startWatching, stopWatching]);

  return { startWatching, stopWatching, requestOnce, locationStatus };
}
