// Waen Toast notification helpers
import toast from "react-hot-toast";

export const waenToast = {
  success: (msg: string) =>
    toast.success(msg, {
      style: {
        background: "#0A6AD6",
        color: "white",
        fontFamily: "'Tajawal','Noto Sans Arabic',sans-serif",
        borderRadius: "16px",
        fontSize: "14px",
        direction: "rtl",
      },
      iconTheme: { primary: "white", secondary: "#0A6AD6" },
      duration: 3000,
    }),

  error: (msg: string) =>
    toast.error(msg, {
      style: {
        background: "#D62828",
        color: "white",
        fontFamily: "'Tajawal','Noto Sans Arabic',sans-serif",
        borderRadius: "16px",
        fontSize: "14px",
        direction: "rtl",
      },
      iconTheme: { primary: "white", secondary: "#D62828" },
      duration: 4000,
    }),

  info: (msg: string) =>
    toast(msg, {
      style: {
        background: "#0B1F3A",
        color: "white",
        fontFamily: "'Tajawal','Noto Sans Arabic',sans-serif",
        borderRadius: "16px",
        fontSize: "14px",
        direction: "rtl",
      },
      duration: 3000,
    }),

  warn: (msg: string) =>
    toast(msg, {
      icon: "⚠️",
      style: {
        background: "#FEF3C7",
        color: "#92400E",
        fontFamily: "'Tajawal','Noto Sans Arabic',sans-serif",
        borderRadius: "16px",
        fontSize: "14px",
        direction: "rtl",
        border: "1px solid #FCD34D",
      },
      duration: 4000,
    }),

  loading: (msg: string) =>
    toast.loading(msg, {
      style: {
        background: "#0A6AD6",
        color: "white",
        fontFamily: "'Tajawal','Noto Sans Arabic',sans-serif",
        borderRadius: "16px",
        fontSize: "14px",
        direction: "rtl",
      },
    }),

  dismiss: (id?: string) => toast.dismiss(id),
};
