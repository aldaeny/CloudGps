import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import type { Language } from "@/types";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Format distance for display
export function formatDistance(meters: number, lang: Language = "ar"): string {
  if (meters < 1000) {
    return lang === "ar" ? `${Math.round(meters)} م` : `${Math.round(meters)} m`;
  }
  const km = (meters / 1000).toFixed(1);
  return lang === "ar" ? `${km} كم` : `${km} km`;
}

// Format duration for display
export function formatDuration(seconds: number, lang: Language = "ar"): string {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);

  if (lang === "ar") {
    if (hours > 0) {
      return `${hours} س ${minutes} د`;
    }
    return `${minutes} دقيقة`;
  } else {
    if (hours > 0) {
      return `${hours}h ${minutes}m`;
    }
    return `${minutes} min`;
  }
}

// Calculate distance between two lat/lng points (Haversine)
export function haversineDistance(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number {
  const R = 6371000; // meters
  const φ1 = (lat1 * Math.PI) / 180;
  const φ2 = (lat2 * Math.PI) / 180;
  const Δφ = ((lat2 - lat1) * Math.PI) / 180;
  const Δλ = ((lng2 - lng1) * Math.PI) / 180;

  const a =
    Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
    Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return R * c;
}

// Format ETA
export function formatETA(seconds: number): string {
  const now = new Date();
  const eta = new Date(now.getTime() + seconds * 1000);
  return eta.toLocaleTimeString("ar-IQ", { hour: "2-digit", minute: "2-digit" });
}

// Get session ID (stored in localStorage)
export function getSessionId(): string {
  if (typeof window === "undefined") return "server";
  let sessionId = localStorage.getItem("waen_session_id");
  if (!sessionId) {
    sessionId = `s_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    localStorage.setItem("waen_session_id", sessionId);
  }
  return sessionId;
}

// Debounce function
export function debounce<T extends (...args: any[]) => any>(
  fn: T,
  delay: number
): (...args: Parameters<T>) => void {
  let timer: ReturnType<typeof setTimeout>;
  return (...args: Parameters<T>) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}

// Truncate text
export function truncate(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength) + "...";
}

// Report type expired check
export function isReportExpired(expiresAt?: string | null): boolean {
  if (!expiresAt) return false;
  return new Date(expiresAt) < new Date();
}

// Get bearing between two points
export function getBearing(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number {
  const φ1 = (lat1 * Math.PI) / 180;
  const φ2 = (lat2 * Math.PI) / 180;
  const Δλ = ((lng2 - lng1) * Math.PI) / 180;

  const y = Math.sin(Δλ) * Math.cos(φ2);
  const x =
    Math.cos(φ1) * Math.sin(φ2) - Math.sin(φ1) * Math.cos(φ2) * Math.cos(Δλ);

  const θ = Math.atan2(y, x);
  return ((θ * 180) / Math.PI + 360) % 360;
}
