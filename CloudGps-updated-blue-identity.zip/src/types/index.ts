// ============================================================
// CloudGps | السحاب — Core Type Definitions
// ============================================================

export type Language = "ar" | "en";
export type Theme = "light" | "dark";

export interface LatLng {
  lat: number;
  lng: number;
}

export interface LatLngBounds {
  minLat: number;
  minLng: number;
  maxLat: number;
  maxLng: number;
}

// ---- Location ----
export interface LocationState {
  position: LatLng | null;
  accuracy: number | null;
  heading: number | null;
  speed: number | null;
  timestamp: number | null;
  status: "idle" | "loading" | "success" | "error" | "denied" | "unavailable";
  error: string | null;
}

// ---- Places / POI ----
export interface Place {
  id: number | string;
  name: string;
  nameAr?: string;
  address?: string;
  addressAr?: string;
  city?: string;
  governorate?: string;
  category?: string;
  subcategory?: string;
  lat: number;
  lng: number;
  phone?: string;
  website?: string;
  openingHours?: string;
  source?: string;
  verified?: boolean;
}

export interface SearchResult {
  places: Place[];
  total: number;
  query: string;
}

// ---- Routing ----
export type RouteProfile = "car" | "bicycle" | "foot";

export interface RouteStep {
  instruction: string;
  instructionAr: string;
  distance: number; // meters
  duration: number; // seconds
  maneuver: string;
  name: string;
  coordinates: LatLng;
}

export interface Route {
  id: string;
  distance: number; // meters
  duration: number; // seconds
  geometry: LatLng[];
  steps: RouteStep[];
  summary: string;
  profile: RouteProfile;
  isAlternative?: boolean;
}

export interface RouteRequest {
  origin: LatLng;
  destination: LatLng;
  profile?: RouteProfile;
  alternatives?: boolean;
}

export interface RoutingState {
  status: "idle" | "loading" | "success" | "error";
  routes: Route[];
  selectedRouteIndex: number;
  error: string | null;
}

// ---- Navigation ----
export type NavigationStatus =
  | "idle"
  | "preview"
  | "active"
  | "paused"
  | "rerouting"
  | "arrived"
  | "cancelled";

export interface NavigationState {
  status: NavigationStatus;
  route: Route | null;
  currentStepIndex: number;
  distanceToNextStep: number;
  distanceRemaining: number;
  timeRemaining: number;
  currentStreetName: string;
  isOffRoute: boolean;
  voiceMuted: boolean;
  eta: Date | null;
}

// ---- Traffic Reports ----
export type ReportType =
  | "accident"
  | "congestion"
  | "road_closed"
  | "pothole"
  | "obstacle"
  | "maintenance"
  | "stopped_vehicle"
  | "road_hazard"
  | "cleared";

export type ReportStatus = "active" | "confirmed" | "resolved" | "expired" | "rejected";
export type ReportSource = "community" | "official" | "system" | "local";

export interface TrafficReport {
  id: number;
  type: ReportType;
  lat: number;
  lng: number;
  description?: string;
  descriptionAr?: string;
  source: ReportSource;
  status: ReportStatus;
  confidence: number;
  confirmations: number;
  denials: number;
  createdAt: string;
  updatedAt: string;
  expiresAt?: string;
  reviewStatus: string;
}

export interface CreateReportPayload {
  type: ReportType;
  lat: number;
  lng: number;
  description?: string;
  sessionId: string;
}

// ---- Saved Places ----
export interface SavedPlace {
  id: number;
  name: string;
  nameAr?: string;
  address?: string;
  lat: number;
  lng: number;
  category: "home" | "work" | "favorite" | "custom";
  icon?: string;
  createdAt: string;
}

// ---- App State ----
export interface AppState {
  language: Language;
  theme: Theme;
  isOnline: boolean;
  activeScreen:
    | "map"
    | "search"
    | "place-detail"
    | "route-preview"
    | "navigation"
    | "reports"
    | "saved"
    | "settings"
    | "offline-maps"
    | "profile";
}

// ---- Governorates ----
export interface Governorate {
  id: string;
  nameAr: string;
  nameEn: string;
  lat: number;
  lng: number;
  zoom: number;
}

export const IRAQ_GOVERNORATES: Governorate[] = [
  { id: "baghdad", nameAr: "بغداد", nameEn: "Baghdad", lat: 33.3152, lng: 44.3661, zoom: 12 },
  { id: "basra", nameAr: "البصرة", nameEn: "Basra", lat: 30.5085, lng: 47.7804, zoom: 12 },
  { id: "nineveh", nameAr: "نينوى - الموصل", nameEn: "Nineveh - Mosul", lat: 36.3489, lng: 43.1574, zoom: 12 },
  { id: "erbil", nameAr: "أربيل", nameEn: "Erbil", lat: 36.1911, lng: 44.0091, zoom: 12 },
  { id: "najaf", nameAr: "النجف", nameEn: "Najaf", lat: 31.9922, lng: 44.3461, zoom: 12 },
  { id: "karbala", nameAr: "كربلاء", nameEn: "Karbala", lat: 32.6158, lng: 44.0241, zoom: 12 },
  { id: "babylon", nameAr: "بابل", nameEn: "Babylon", lat: 32.4727, lng: 44.4219, zoom: 11 },
  { id: "kirkuk", nameAr: "كركوك", nameEn: "Kirkuk", lat: 35.4681, lng: 44.3922, zoom: 12 },
  { id: "anbar", nameAr: "الأنبار", nameEn: "Anbar", lat: 33.3906, lng: 43.2853, zoom: 10 },
  { id: "diyala", nameAr: "ديالى", nameEn: "Diyala", lat: 33.7614, lng: 44.9419, zoom: 11 },
  { id: "wasit", nameAr: "واسط", nameEn: "Wasit", lat: 32.6014, lng: 45.8144, zoom: 11 },
  { id: "dhiqar", nameAr: "ذي قار", nameEn: "Dhi Qar", lat: 31.0461, lng: 46.2756, zoom: 11 },
  { id: "maysan", nameAr: "ميسان", nameEn: "Maysan", lat: 31.8372, lng: 47.1519, zoom: 11 },
  { id: "qadisiyyah", nameAr: "القادسية", nameEn: "Al-Qadisiyyah", lat: 31.9982, lng: 44.9278, zoom: 11 },
  { id: "muthanna", nameAr: "المثنى", nameEn: "Al-Muthanna", lat: 31.3288, lng: 45.2694, zoom: 10 },
  { id: "saladin", nameAr: "صلاح الدين", nameEn: "Saladin", lat: 34.5333, lng: 43.4833, zoom: 11 },
  { id: "dohuk", nameAr: "دهوك", nameEn: "Dohuk", lat: 36.8669, lng: 43.0017, zoom: 12 },
  { id: "sulaymaniyah", nameAr: "السليمانية", nameEn: "Sulaymaniyah", lat: 35.5577, lng: 45.4329, zoom: 12 },
];

// ---- Report type labels ----
export const REPORT_TYPE_LABELS: Record<ReportType, { ar: string; en: string; icon: string; color: string }> = {
  accident: { ar: "حادث", en: "Accident", icon: "🚨", color: "#D62828" },
  congestion: { ar: "ازدحام", en: "Congestion", icon: "🚦", color: "#F97316" },
  road_closed: { ar: "طريق مغلق", en: "Road Closed", icon: "🚧", color: "#D62828" },
  pothole: { ar: "حفرة", en: "Pothole", icon: "⚠️", color: "#F97316" },
  obstacle: { ar: "عائق", en: "Obstacle", icon: "🪨", color: "#F97316" },
  maintenance: { ar: "أعمال صيانة", en: "Maintenance", icon: "🔧", color: "#6366F1" },
  stopped_vehicle: { ar: "مركبة متوقفة", en: "Stopped Vehicle", icon: "🚗", color: "#F97316" },
  road_hazard: { ar: "خطر على الطريق", en: "Road Hazard", icon: "⛔", color: "#D62828" },
  cleared: { ar: "تم التخليص", en: "Cleared", icon: "✅", color: "#10B981" },
};
